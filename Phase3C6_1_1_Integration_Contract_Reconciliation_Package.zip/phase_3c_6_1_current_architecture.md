# FieldWise — Phase 3C.6.1.1: Current Application Architecture and Baseline Audit

**Document Reference**: `FieldWise_main/model/ml_pipeline/reports/phase_3c_6_1_current_architecture.md`  
**Phase**: 3C.6.1.1 Integration Contract and Safety Reconciliation  
**Execution Mode**: READ-ONLY Audit & Architectural Specification  
**Date**: November 2026  
**Status**: APPROVED RECONCILED BASELINE AUDIT  

---

## 1. Executive Summary & Verification Provenance

This document establishes the verified architectural baseline of the FieldWise application and the frozen Phase 3C.5 rule-based crop recommendation engine. In accordance with the Phase 3C.6.1.1 mandate, this audit explicitly distinguishes between **verified source code facts** and **architectural assumptions**.

### Verification Provenance Status
- **Verified from Source**:
  - Express backend routing (`FieldWise_main/backend/src/routes/predict.js`, lines 1–29).
  - Express controller logic and input parsing (`FieldWise_main/backend/src/controllers/predictController.js`, lines 1–55).
  - Legacy in-process predictor Gaussian formulas and 35% confidence cut-off (`FieldWise_main/model/predictor.js`, lines 1–151).
  - 16-crop legacy database (`FieldWise_main/model/cropDatabase.js`, lines 1–261).
  - Static fertilizer recipes (`FieldWise_main/model/fertilizerDatabase.js`, lines 1–92).
  - Client-side Axios interceptors and silent offline 5xx fallback (`FieldWise_main/src/lib/api.ts`, lines 52–83).
  - Client-side TypeScript Gaussian clone (`FieldWise_main/src/lib/predictorEngine.ts`, lines 1–490).
  - Frontend form state, bounds, and pre-fills (`FieldWise_main/src/components/modules/CropRecommendation.tsx`, lines 48–125; `PredictionForm.tsx`, lines 10–84).
  - Frontend results presentation: `${result.confidence.toFixed(1)}%` with progress bar (`FieldWise_main/src/components/PredictionResults.tsx`, lines 142–153).
  - Supabase persistence schema writing to `crop_predictions` (`FieldWise_main/src/lib/supabase.ts`, lines 201–222).
  - Frozen Phase 3C.5 Python dataclasses, types, defaults, and validation rules (`FieldWise_main/model/ml_pipeline/recommendation_engine/schemas.py`, lines 1–377; `input_validator.py`, lines 1–179).
  - Frozen Phase 3C.5 STCR registry containing **zero** approved records (`FieldWise_main/model/ml_pipeline/recommendation_engine/stcr_registry.py`, lines 30–33).
  - Frozen Phase 3C.5 provenance registry requiring cryptographically signed `TrustedVerificationRecord` for independent verification (`FieldWise_main/model/ml_pipeline/recommendation_engine/dci_confidence.py`, lines 14–24; `provenance_registry.py`, lines 1–65).
- **Assumptions (Documented for Review)**:
  - Assumption A: Production deployment environments will have `python3` (version $\ge$ 3.9) available on system `$PATH` unless containerized without Python.
  - Assumption B: Farmers interacting with the planned sowing month selector are willing to explicitly select their planned sowing month (1–12) rather than having it inferred.

---

## 2. Component Topology and System Context

```mermaid
flowchart TD
    subgraph Client["Frontend Client (Browser / Vite + React + TypeScript)"]
        Form["PredictionForm.tsx / CropRecommendation.tsx\n(Captures 9 Inputs)"]
        ProfServ["farmProfileService.ts\n(Profile Data)"]
        WeathCtx["WeatherContext.tsx\n(Live Weather Data)"]
        ApiTS["lib/api.ts (predictApi.predict)\nAxios Client"]
        OfflineEngine["lib/predictorEngine.ts\n(Client-side TS Legacy Predictor)"]
        ResComp["PredictionResults.tsx\n(Renders Results)"]
        FarmIntel["FarmIntelligence.tsx\n(Reads localStorage Cache)"]
        LocStor[("localStorage:\ncropswild_crop_recommendation_last")]
    end

    subgraph Backend["Express.js Backend (Node.js / Port 3001)"]
        ServerJS["server.js\nCORS, Routing, Port 3001"]
        RoutePredict["routes/predict.js\nexpress-validator (8 rules)"]
        CtrlPredict["controllers/predictController.js\npredict(req, res)"]
        LegacyModel["model/predictor.js\npredictCrops(inputs)"]
        CropDB["model/cropDatabase.js\n(16 Crops)"]
        FertDB["model/fertilizerDatabase.js\n(Static Recipes)"]
    end

    subgraph Database["Cloud Persistence (Supabase)"]
        SupaClient["lib/supabase.ts\nsavePredictionToSupabase()"]
        SupaTable[("Supabase DB:\ncrop_predictions")]
    end

    subgraph Phase3C5["Frozen Python Recommendation Engine (model/ml_pipeline/)"]
        EnginePy["recommendation_engine/engine.py\nCropRecommendationEngine.recommend()"]
        SchemasPy["recommendation_engine/schemas.py\nRecommendationQuery"]
        ValidatorPy["recommendation_engine/input_validator.py\nValidation & Adequacy Gating"]
        CatPy["recommendation_engine/catalogue.py\n(19 Canonical Crops)"]
        WaterPy["recommendation_engine/water_assessment.py\nUSDA-SCS Effective Rainfall"]
        Tier1Py["recommendation_engine/tier1_eligibility.py\nHard Exclusion Gating"]
        Tier2Py["recommendation_engine/tier2_scoring.py\nLiebig Non-Compensatory Scoring"]
        DCIPy["recommendation_engine/dci_confidence.py\n6-Domain Provenance & DCI"]
        RankPy["recommendation_engine/ranking.py\nDeterministic Viability (>= 40.0)"]
        ExplPy["recommendation_engine/explanations.py\nStoichiometric DAP Prescriptions"]
    end

    Form -->|1. Submit Inputs| ApiTS
    ProfServ -.->|User Data| Form
    WeathCtx -.->|Live Data| Form
    ApiTS -->|2. HTTP POST /api/predict| RoutePredict
    ApiTS -.->|2a. Offline Disconnection ONLY| OfflineEngine
    OfflineEngine -.->|Return Local Predictions| ApiTS
    RoutePredict --> CtrlPredict
    CtrlPredict --> LegacyModel
    LegacyModel --> CropDB
    LegacyModel --> FertDB
    CtrlPredict -->|3. JSON Response| ApiTS
    ApiTS -->|4. Update State| ResComp
    Form -->|5. Write Cache| LocStor
    Form -->|6. Async Sync| SupaClient
    SupaClient --> SupaTable
    LocStor -.->|Read Cache| FarmIntel
```

---

## 3. Existing Application Architecture Inspection

### 3.1 Frontend: `FieldWise_main/src/components/modules/CropRecommendation.tsx`
- **Source Inspection Reference**: Lines 48–125, 220–309.
- **Model Inputs State**: Captures exactly 9 continuous/categorical values: `rainfall`, `temperature`, `humidity`, `soilType`, `nitrogen`, `phosphorus`, `potassium`, `ph`, `state`.
- **Pre-filling Behavior**: Pre-fills NPK sliders with arbitrary default integers (`nitrogen: 80`, `phosphorus: 50`, `potassium: 50`, `ph: 6.5`, `rainfall: 150`) if profile or localStorage is empty.
- **Defect Identified**: Pre-filled sliders currently create the illusion of measured soil data. Under Phase 3C.6.1.1, user declarations must be strictly distinguished from laboratory tests.
- **Persistence Handling**: Saves top prediction to `localStorage['cropswild_crop_recommendation_last']` and invokes `savePredictionToSupabase` in `src/lib/supabase.ts`.

### 3.2 Frontend: `FieldWise_main/src/components/PredictionResults.tsx`
- **Source Inspection Reference**: Lines 17–50, 142–153.
- **Current Rendering**: Renders `${result.confidence.toFixed(1)}%` with an emerald/amber/rose horizontal progress bar.
- **Defect Identified**: Labels a heuristic mathematical score as a probabilistic "confidence" percentage. Violates agronomic safety rules.

### 3.3 Frontend API Client: `FieldWise_main/src/lib/api.ts`
- **Source Inspection Reference**: Lines 52–83.
- **Current Behavior**:
  ```typescript
  try {
      const res = await api.post('/api/predict', data);
      return res;
  } catch (err: any) {
      if (err?.response && err.response.status >= 400 && err.response.status < 500) {
          throw err;
      }
      // When backend is not running or unreachable, run the local Gaussian prediction engine
      const localPredictions = predictCropsEngine(data);
      return { data: { success: true, mode: 'offline_ml_engine', predictions: localPredictions } };
  }
  ```
- **Defect Identified**: Catches backend HTTP 5xx errors and silently executes the client-side legacy engine (`offline_ml_engine`). This masks server crashes, validation bugs, and internal exceptions.

### 3.4 Backend: `FieldWise_main/backend/src/routes/predict.js` & `controllers/predictController.js`
- **Source Inspection Reference**: `routes/predict.js` lines 13–27; `controllers/predictController.js` lines 9–53.
- **Validation**: Enforces strict bounds on 8 numeric fields via `express-validator`. Does not validate `state` or `sowing_month`.
- **Invocation**: Unconditionally calls `predictCrops()` from `model/predictor.js`.
- **Response Format**: `{ success: true, count: results.length, state: state || 'Not specified', predictions: results }`.

---

## 4. Frozen Phase 3C.5 Canonical Input Contract (`RecommendationQuery`)

Inspection of `FieldWise_main/model/ml_pipeline/recommendation_engine/schemas.py` lines 105–218 reveals the exact schema structure of `RecommendationQuery`.

### 4.1 Schema Definitions and Types

```python
@dataclass
class LocationInput:
    state: str                                    # REQUIRED: Canonical state name
    district: Optional[str] = None                # OPTIONAL: Administrative district
    agro_climatic_zone: Optional[str] = None      # OPTIONAL: Planning commission zone

@dataclass
class TemporalInput:
    sowing_month: int                             # REQUIRED: Integer 1 to 12 inclusive
    sowing_date: Optional[str] = None             # OPTIONAL: ISO date YYYY-MM-DD
    cultivation_season: Optional[str] = None      # OPTIONAL: Kharif, Rabi, Zaid, etc.
    planting_system: Optional[str] = None         # OPTIONAL: Timely_Sown, Late_Sown, etc.

@dataclass
class ClimateWaterInput:
    seasonal_rainfall_amount: Optional[float] = None       # Gross mm (required for rainfed)
    rainfall_period_type: Optional[str] = None             # Crop_Season_Measured, etc.
    rainfall_source: Optional[str] = None                  # IMD_Station_Gridded, etc.
    monthly_rainfall: Optional[List[float]] = None         # 12 monthly gross rainfall values
    irrigation_access: Optional[str] = "None_Rainfed"      # IrrigationAccess enum
    irrigation_water_quantity_mm: Optional[float] = None   # Gross applied mm
    irrigation_quantity_basis: Optional[str] = None        # Measured_Flow_Meter, etc.
    irrigation_type: Optional[str] = None                  # Drip, Sprinkler, etc.
    irrigation_period_days: Optional[int] = None           # Measurement duration
    rainfall_period_days: Optional[int] = None             # Measurement duration
    temperature_mean: Optional[float] = None               # Mean temperature in °C
    temperature_min_night: Optional[float] = None          # Minimum night temperature in °C
    temperature_max_day: Optional[float] = None            # Maximum day temperature in °C
    relative_humidity: Optional[float] = None              # Relative humidity (0-100%)
    soil_moisture_tier: Optional[str] = "UNKNOWN"          # Epistemic tier
    soil_moisture_mm: Optional[float] = None               # Root-zone moisture in mm
    awc_mm_m: Optional[float] = None                       # Available Water Capacity (mm/m)
    rooting_depth_m: Optional[float] = None                # Rooting depth in meters
    station_id: Optional[str] = None                       # Audit station ID
    measurement_date_start: Optional[str] = None           # Audit period start
    measurement_date_end: Optional[str] = None             # Audit period end
    irrigation_meter_id: Optional[str] = None              # Audit flow-meter ID
    source_reference: Optional[str] = None                 # Audit source citation

@dataclass
class EdaphicInput:
    soil_texture: Optional[str] = None                     # Soil texture class
    texture_measurement_method: Optional[str] = None       # Measurement method
    soil_ph: Optional[float] = None                        # 1:2.5 potentiometric pH
    ph_measurement_method: Optional[str] = None            # Measurement method
    has_soil_test: bool = False                            # Accredited lab test flag
    soil_test_source: Optional[str] = None                 # Source of soil test
    nutrient_basis: Optional[str] = None                   # SHC_Available_kg_ha, etc.
    soil_nitrogen: Optional[float] = None                  # Available N (kg/ha)
    soil_phosphorus: Optional[float] = None                # Available P2O5 (kg/ha)
    soil_potassium: Optional[float] = None                 # Available K2O (kg/ha)
    organic_carbon_pct: Optional[float] = None             # Organic carbon (%)
    lab_accreditation_number: Optional[str] = None         # NABL/ICAR lab code
    sample_id: Optional[str] = None                        # Laboratory sample ID
    test_date: Optional[str] = None                        # Date of testing
    source_reference: Optional[str] = None                 # Portal / record citation

@dataclass
class RecommendationQuery:
    location: LocationInput                                # REQUIRED
    temporal: TemporalInput                                # REQUIRED
    climate_and_water: ClimateWaterInput                   # REQUIRED
    edaphic: EdaphicInput                                  # REQUIRED
    stcr_calibration_id: Optional[str] = None              # OPTIONAL
    stcr_calibration: Optional[STCRCalibrationRecord] = None # OPTIONAL
    target_yield_t_ha: Optional[float] = None              # OPTIONAL
    has_stcr_calibration: bool = False                    # OPTIONAL
    verification_records: List[TrustedVerificationRecord] = field(default_factory=list)
```

---

## 5. Input Validation and Adequacy Gating Rules

Inspection of `FieldWise_main/model/ml_pipeline/recommendation_engine/input_validator.py` reveals two distinct validation phases:

### Phase 1: Physical and Syntactic Validation (`validate_and_normalize`)
- `location.state`: Non-empty string; normalized against `STATE_NORMALIZATION_MAP`.
- `temporal.sowing_month`: **Mandatory integer between 1 and 12**. If missing or out-of-range, raises `InputValidationError`.
- `climate_and_water.seasonal_rainfall_amount`: Must be $\ge 0.0$ and $\le 12,000.0$ mm.
- `climate_and_water.temperature_mean`: Must be between $-20.0^\circ\text{C}$ and $60.0^\circ\text{C}$.
- `climate_and_water.relative_humidity`: Must be between $0.0\%$ and $100.0\%$.
- `edaphic.soil_ph`: Must be between $2.0$ and $12.0$.
- `edaphic.soil_texture`: Normalized against `SOIL_TEXTURE_NORMALIZATION`.
- `edaphic.has_soil_test`: If `True`, N, P, K must be non-negative.

### Phase 2: Biological Data Adequacy Gating (`check_data_adequacy`)
Lines 167–179 of `input_validator.py`:
```python
@classmethod
def check_data_adequacy(cls, query: RecommendationQuery) -> Tuple[bool, Optional[str]]:
    if query.temporal.sowing_month is None:
        return False, "Sowing month omitted. Biological feasibility cannot be established without temporal context."

    cw = query.climate_and_water
    if cw.seasonal_rainfall_amount is None and (cw.irrigation_access is None or cw.irrigation_access == "None_Rainfed"):
        return False, "Rainfall amount is omitted for rainfed cultivation. Water sufficiency cannot be calculated."

    return True, None
```

---

## 6. Provenance and STCR Calibration Limitations

### 6.1 Epistemic Provenance Rules (`dci_confidence.py`)
- Source reference: Lines 14–24.
- A user declaration (such as checking a checkbox in the UI) sets `has_soil_test=True`, but its epistemic tier remains **`USER_DECLARED`** or **`PROVISIONAL`**.
- It is **NEVER** promoted to `INDEPENDENTLY_VERIFIED` unless accompanied by a cryptographically signed `TrustedVerificationRecord` issued by an authorized registry authority (e.g. `AUTH-ICAR-SHC-REGISTRY`).
- `lastTestedDate` in farm profile does **NOT** imply laboratory verification.

### 6.2 STCR Calibration Registry (`stcr_registry.py`)
- Source reference: Lines 30–33.
- `_APPROVED_CALIBRATIONS: Dict[str, STCRCalibrationRecord] = {}`
- In accordance with Phase 3C.5.2.2.1 safety mandates, all unverified local calibration records were purged. Until official audited calibration sets are formally reviewed, the registry contains **zero approved calibrations**.
- Consequently, the engine will **NEVER** return `status: "VERIFIED_STCR_GENERATED"`. When `has_soil_test=True`, it returns `status: "BASELINE_RDF_ARITHMETIC"` with stoichiometric DAP Nitrogen credit. When `has_soil_test=False`, it returns `status: "WITHHELD_MISSING_SOIL_TEST"`.
