"""
FieldWise Phase 3C.5: Explanation & Warning Generation Module
============================================================
Generates transparent, evidence-backed agronomic justifications,
Liebig limiting-factor diagnostics, risk advisories, and safe
fertilizer guidance adhering strictly to Phase 3C.4 specifications.

Key Safety Mandates:
  - Commercial fertilizer bag quantities are strictly WITHHELD when
    laboratory soil-test data is unavailable.
  - When soil test is available, stoichiometric DAP nitrogen credit (18%)
    is deducted before computing supplementary Urea.
  - Transparently discloses limiting factors that depress suitability scores.
"""

from typing import List, Dict, Optional, Tuple
from .schemas import (
    CropCatalogueEntry,
    RecommendationQuery,
    PlantingWindowDefinition,
    WaterAssessmentResult,
    Tier2Components,
    FertilizerPrescription,
    WaterGatingStatus,
)


class ExplanationGenerator:
    """
    Produces plain-language agronomic rationales, warnings, and fertilizer schedules.
    """

    @classmethod
    def identify_limiting_factor(cls, components: Tier2Components) -> Tuple[str, float]:
        """Identifies the minimum physical factor depressing suitability via Liebig rule."""
        factors = {
            "Water adequacy": components.water_score,
            "Climate / temperature": components.climate_score,
            "Soil texture": components.soil_score,
            "Soil pH reaction": components.ph_score,
        }
        min_factor = min(factors, key=factors.get)
        return min_factor, factors[min_factor]

    @classmethod
    def generate_advisory(
        cls,
        crop: CropCatalogueEntry,
        query: RecommendationQuery,
        components: Tier2Components,
        water_result: WaterAssessmentResult,
        active_window: Optional[PlantingWindowDefinition],
    ) -> List[str]:
        advisory: List[str] = []

        # 1. Window advisory
        if active_window:
            advisory.append(
                f"Optimal {active_window.planting_system} sowing window ({active_window.sowing_date_range}) "
                f"active in {active_window.region_or_zone}."
            )

        # 2. Liebig limiting factor diagnostic
        min_fac, min_val = cls.identify_limiting_factor(components)
        if min_val < 75.0:
            advisory.append(
                f"Liebig Limiting Factor: {min_fac} (sub-score {min_val}/100) is the primary constraint depressing overall yield potential."
            )

        # 3. Water management advisory
        if water_result.water_gating_status == WaterGatingStatus.SCREENING_THRESHOLD_MET:
            advisory.append("Gross seasonal rainfall meets rainfed screening threshold. Maintain field bunds to conserve soil moisture.")
        elif water_result.water_gating_status == WaterGatingStatus.CONDITIONALLY_ELIGIBLE_WITH_HIGH_WATER_RISK:
            advisory.append("Acute water deficit flagged. Recommend protective supplemental irrigation or drought-tolerant cultivar selection.")
        elif water_result.water_gating_status == WaterGatingStatus.CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK:
            advisory.append("Irrigation volume is unmeasured. Verify tubewell / canal flow rate prior to input procurement.")

        # 4. Soil texture advisory
        if query.edaphic.soil_texture:
            if query.edaphic.soil_texture in crop.preferred_soil_textures:
                advisory.append(f"{query.edaphic.soil_texture} soil provides optimal drainage and aeration for root proliferation.")

        return advisory

    @classmethod
    def generate_risk_warnings(
        cls,
        crop: CropCatalogueEntry,
        query: RecommendationQuery,
        components: Tier2Components,
        water_result: WaterAssessmentResult,
    ) -> List[str]:
        warnings: List[str] = list(water_result.warnings)
        t_mean = query.climate_and_water.temperature_mean
        ph = query.edaphic.soil_ph

        # Temperature warnings
        if t_mean is not None:
            if t_mean > 35.0:
                warnings.append(
                    f"Thermal Stress Notice: Mean temperature ({t_mean}°C) approaches upper heat threshold. "
                    "Risk of flower shedding, anthesis desiccation, and reduced grain fill."
                )
            elif t_mean < 15.0 and crop.sowing_temp_min_c > 12.0:
                warnings.append(
                    f"Cold Stress Notice: Low temperature ({t_mean}°C) may retard vegetative emergence."
                )

        # Soil pH warnings
        if ph is not None:
            if ph > crop.soil_ph_max:
                warnings.append(
                    f"Alkalinity/Sodicity Warning: Soil pH ({ph}) exceeds preferred maximum ({crop.soil_ph_max}). "
                    "Zinc, iron, and phosphorus availability may be restricted."
                )
            elif ph < crop.soil_ph_min:
                warnings.append(
                    f"Soil Acidity Warning: Soil pH ({ph}) below preferred minimum ({crop.soil_ph_min}). "
                    "Lime application recommended to neutralize potential aluminum toxicity."
                )

        return warnings

    @classmethod
    def generate_fertilizer_prescription(
        cls,
        crop: CropCatalogueEntry,
        query: RecommendationQuery,
    ) -> FertilizerPrescription:
        """
        Enforces Phase 3C.4 Fertilizer Safety Mandates:
          1. Withholds commercial bag prescriptions when soil test is unavailable.
          2. When soil test is available, credits 18% DAP nitrogen to prevent over-application.
        """
        ed = query.edaphic
        rdf = crop.rdf_n_p2o5_k2o_kg_ha

        # Baseline RDF: [N, P2O5, K2O]
        if len(rdf) >= 3:
            dose_n, dose_p, dose_k = rdf[0], rdf[1], rdf[2]
        else:
            dose_n, dose_p, dose_k = 100.0, 50.0, 50.0

        if not ed.has_soil_test or ed.soil_nitrogen is None:
            # Mandate: Withhold commercial quantities when soil test is missing!
            return FertilizerPrescription(
                status="WITHHELD_MISSING_SOIL_TEST",
                rdf_n_p2o5_k2o_kg_ha=[dose_n, dose_p, dose_k],
                adjusted_dose_kg_ha=None,
                commercial_products={},
                stoichiometric_notes=(
                    "Commercial fertilizer product quantities are withheld because verified laboratory Soil Health Card "
                    "readings are unavailable. Prescribing physical fertilizer bags without soil testing risks severe "
                    "vegetative lodging, blast disease, and nitrate pollution."
                ),
                disclaimers=[
                    "Advisory Only: Baseline state Package of Practices (POP) RDF shown in kg/ha.",
                    "Obtain a certified laboratory soil test or consult your local Krishi Vigyan Kendra (KVK) for customized dosing."
                ]
            )

        # Soil test is available: Perform verified stoichiometric calculation
        # 1. DAP applied from phosphate target
        dap = round(dose_p / 0.46, 1) if dose_p > 0 else 0.0

        # 2. Nitrogen delivered by DAP (18%)
        n_dap = round(dap * 0.18, 1)

        # 3. Net supplementary Nitrogen required from Urea
        n_supp = max(0.0, dose_n - n_dap)

        # 4. Supplementary Urea (46% N)
        urea = round(n_supp / 0.46, 1)

        # 5. MOP from Potash target (60% K2O)
        mop = round(dose_k / 0.60, 1) if dose_k > 0 else 0.0

        return FertilizerPrescription(
            status="VERIFIED_STCR_GENERATED",
            rdf_n_p2o5_k2o_kg_ha=[dose_n, dose_p, dose_k],
            adjusted_dose_kg_ha=[dose_n, dose_p, dose_k],
            commercial_products={
                "dap_kg_ha": dap,
                "dap_nitrogen_credit_kg_ha": n_dap,
                "urea_supplementary_kg_ha": urea,
                "mop_kg_ha": mop,
            },
            stoichiometric_notes=(
                f"Supplementary Urea quantity ({urea} kg/ha) reflects net elemental nitrogen required after deducting "
                f"{n_dap} kg/ha N supplied by {dap} kg/ha DAP. Avoids {round((dose_n/0.46) - urea, 1)} kg/ha physical Urea over-application."
            ),
            disclaimers=[
                "Stoichiometrically balanced for DAP basal application.",
                "Split Urea into 2-3 top dressings according to crop physiological stages (e.g. CRI and tillering)."
            ]
        )
