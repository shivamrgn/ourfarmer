# FieldWise — Phase 3C.4: Recommendation Engine Safety Redesign Specification

**Phase**: Phase 3C.4 (Recommendation Engine Safety Redesign Specification)  
**Execution Timestamp**: 2026-11-19T13:50:00Z  
**Directory**: `FieldWise_main/model/ml_pipeline/data/processed/recommendation/`  
**Application Preservation Status**: Complete Isolation. Live frontend, backend APIs, Supabase database, `model/predictor.js`, `model/cropDatabase.js`, `model/fertilizerDatabase.js`, and `src/lib/predictorEngine.ts` strictly **UNTOUCHED / READ-ONLY**.

---

## 1. Overview & Objective

Phase 3C.4 converts the critical agronomic vulnerabilities identified in Phase 3C.3 into an implementable, evidence-conscious technical design specification.

This phase establishes:
1. A **Canonical Input Contract** resolving rainfall period and soil test ambiguities.
2. A **100-Rule Agronomic Eligibility Layer** running prior to ranking.
3. A **Two-Tier Hybrid Scoring Architecture** (Boolean Gating -> Liebig-Weighted Geometric Multi-Criteria Ranking).
4. A **Unified 19-Crop Master Catalogue (SSOT)** eliminating dual-engine split-brain.
5. A **Fertilizer & Soil-Nutrient Safety Specification** using Soil-Test Crop Response (STCR).
6. A **Fallback & Uncertainty Specification** guaranteeing 100% backend/frontend parity.
7. A **15-Case Acceptance Test Matrix** providing regression test assertions.

**THIS IS A DESIGN-ONLY PHASE. NO PRODUCTION CODE WAS MODIFIED.**

---

## 2. Deliverables Manifest

| Artifact Path | Format | Description |
| :--- | :---: | :--- |
| `reports/phase_3c_4_input_contract.md` | Markdown | Canonical contract specifying all 20 input fields, units, and missing-data policies. |
| `reports/phase_3c_4_eligibility_rules.csv` | CSV (100 rules) | 100 evidence-backed Boolean gating rules across 7 biological dimensions for all 19 crops. |
| `reports/phase_3c_4_scoring_architecture.md` | Markdown | Mathematical specification of Two-Tier Hybrid Architecture and Liebig scoring formulas. |
| `reports/phase_3c_4_canonical_crop_catalogue.csv` | CSV (19 crops) | Unified master crop catalogue establishing Single Source of Truth for backend and frontend. |
| `reports/phase_3c_4_fertilizer_safety_spec.md` | Markdown | Decoupled soil test evaluation, STCR adjustments, and commercial bag split application rules. |
| `reports/phase_3c_4_fallback_and_uncertainty_spec.md` | Markdown | Dual-engine parity guarantee, conservative missing-data fallbacks, and zero-recommendation rules. |
| `reports/phase_3c_4_acceptance_test_matrix.csv` | CSV (15 tests) | Regression tests for Scenarios S1-S5 and 10 edge/boundary test cases with pass criteria. |
| `reports/phase_3c_4_source_evidence_gaps.csv` | CSV (10 gaps) | Catalog of 10 evidence gaps, resolution status, and source citations. |
| `reports/phase_3c_4_redesign_decision.md` | Markdown | Comprehensive final technical report and Phase 3C.5 implementation roadmap. |
| `reports/phase_3c_4_metrics.json` | JSON | Machine-readable specification metrics and inventory counts. |
| `reports/phase_3c_4_checksums.txt` | Text | SHA-256 verification manifest. |
| `scripts/validate_phase_3c_4_spec.py` | Python | Standalone specification validator engine. |
| `data/processed/recommendation/phase_3c_4_README.md` | Markdown | This documentation and reproduction guide. |

---

## 3. Reproduction Instructions

To execute the specification validation suite and verify all 12 deliverables:

```bash
cd /Users/shivamkumar/farmingFinal/FieldWise_main/model/ml_pipeline
python3 scripts/validate_phase_3c_4_spec.py
```

Expected output:
- Verifies deliverable existence and minimum non-zero byte size.
- Asserts 100% coverage of all 19 canonical crops in catalogue and rules.
- Validates 100 eligibility rules and source citations.
- Validates canonical input contract fields and missing-data policies.
- Validates all 15 acceptance test payloads and pass criteria.
- Emits exit code 0.

---

## 4. SHA-256 Verification Manifest

```
fc7cd88950e0643a1a7b37794ead6349561338db66e567c3232974beff85bf3d  reports/phase_3c_4_input_contract.md
94afcf97b75328ebf47895d8374e29119565aabe9a3b7616ffa167f94eaaae4a  reports/phase_3c_4_eligibility_rules.csv
ba97b7beaa3cba2d8d24948047300a5eb9aaa14bbffe3308e06f8fdfee905dc2  reports/phase_3c_4_scoring_architecture.md
4e866c8307a5713ba47a98e57c3068f1a7ac69787d84acc9efd97663b5ade2d3  reports/phase_3c_4_canonical_crop_catalogue.csv
3afb083a82e425d81cac58629611af68257ecb2245d69beb8fc60f105c29d247  reports/phase_3c_4_fertilizer_safety_spec.md
75e2164b92651ae305bf05e8939498cf962825efeb6e44e703cae6957eeb4571  reports/phase_3c_4_fallback_and_uncertainty_spec.md
2b9d2df495b4fdee1583736dfc75b4a7bdbe683aff5fe60d69aceed3f765c61e  reports/phase_3c_4_acceptance_test_matrix.csv
79f3afc658df6883e5c71ebe989775d7e5a9c63348a2e8d8f0057543f8efa931  reports/phase_3c_4_source_evidence_gaps.csv
a7bff95805232af125eeb4dbe124c7cf83894fc74bd8a4a60afc3b257299e89f  reports/phase_3c_4_redesign_decision.md
a6270f6e85b58af9fe461018f1902950a2b44a982e686ac870e129383ace7ab1  reports/phase_3c_4_metrics.json
98fe2485405e79edef644bb1179be21c23d992b3364bdb4ec53652d4b070f06d  scripts/validate_phase_3c_4_spec.py
```
