# FieldWise — Phase 3C.4 / Phase 3C.4.1: Recommendation Engine Safety Redesign Specification

**Phase**: Phase 3C.4 / Phase 3C.4.1 (Consolidated Safety Specification Corrections)  
**Execution Timestamp**: 2026-11-19T14:20:00Z  
**Directory**: `FieldWise_main/model/ml_pipeline/data/processed/recommendation/`  
**Application Preservation Status**: Complete Isolation. Live frontend, backend APIs, Supabase database, `model/predictor.js`, `model/cropDatabase.js`, `model/fertilizerDatabase.js`, and `src/lib/predictorEngine.ts` strictly **UNTOUCHED / READ-ONLY**.

---

## 1. Overview & Objective

Phase 3C.4 converts the critical agronomic vulnerabilities identified in Phase 3C.3 into an implementable technical redesign specification. Following independent expert review, Phase 3C.4.1 consolidates all safety, agronomic, and evidence corrections.

Key Achievements:
1. **Decoupled Water Model**: Removed fixed 120 mm / 600 mm assumptions and flat 75% monsoon fractions; unmeasured water evaluates to UNKNOWN.
2. **100-Rule Eligibility Layer**: Reviewed individually with strict statuses (`HARD_EXCLUSION`, `SOFT_PENALTY`, `WARNING_ONLY`, `UNKNOWN`, `NOT_APPLICABLE`); removed flowering heat from sowing exclusions; eliminated universal rainfall exclusions.
3. **Fertilizer Safety**: Removed blanket 125%/75% multipliers; deducted DAP Nitrogen ($N_{\text{from\_DAP}} = \text{DAP} \times 0.18$); restricted bags to verified regional STCR.
4. **Canonical Catalogue**: 19 crops with explicit recommendation-readiness tiers; Millets standardized to Pearl Millet (*Pennisetum glaucum*) vs Jowar (*Sorghum bicolor*); Mango classified as orchard perennial.
5. **Scoring Architecture**: Formalized UNKNOWN gating, Data Completeness Index, score non-comparability, 2D display, and deterministic failure boundaries (`NO_RECOMMENDATION_SUITABLE` vs `INSUFFICIENT_DATA`).
6. **15 Acceptance Tests**: Comprehensive regression of Scenarios S1-S5 and boundary edge cases without unverified assumptions.

**THIS IS A SPECIFICATION-ONLY PHASE. NO PRODUCTION CODE WAS MODIFIED.**

---

## 2. Deliverables Manifest

| Artifact Path | Format | Description |
| :--- | :---: | :--- |
| `reports/phase_3c_4_input_contract.md` | Markdown | Canonical contract specifying all input fields, units, region-aware windows, and decoupled water accounting. |
| `reports/phase_3c_4_eligibility_rules.csv` | CSV (100 rules) | 100 evidence-backed Boolean gating rules individually reviewed across 7 biological dimensions for all 19 crops. |
| `reports/phase_3c_4_scoring_architecture.md` | Markdown | Mathematical specification of Two-Tier Hybrid Architecture, Liebig formulas, and DCI non-comparability. |
| `reports/phase_3c_4_canonical_crop_catalogue.csv` | CSV (19 crops) | Unified master crop catalogue establishing Single Source of Truth with recommendation-readiness tiers. |
| `reports/phase_3c_4_fertilizer_safety_spec.md` | Markdown | Decoupled soil test evaluation, DAP nitrogen credits, stoichiometry, and STCR target yield rules. |
| `reports/phase_3c_4_fallback_and_uncertainty_spec.md` | Markdown | Dual-engine parity guarantee, unmeasured water handling, and zero-recommendation rules. |
| `reports/phase_3c_4_acceptance_test_matrix.csv` | CSV (15 tests) | Regression tests for Scenarios S1-S5 and 10 edge/boundary test cases with corrected expectations. |
| `reports/phase_3c_4_source_evidence_gaps.csv` | CSV (10 gaps) | Catalog of 10 evidence gaps, resolution status, and source citations. |
| `reports/phase_3c_4_redesign_decision.md` | Markdown | Comprehensive final technical report and Phase 3C.5 implementation roadmap. |
| `reports/phase_3c_4_1_correction_log.md` | Markdown | Item-by-item audit log detailing all corrections from the independent review. |
| `reports/phase_3c_4_1_final_decision.md` | Markdown | Executive decision report consolidating all Phase 3C.4.1 corrections. |
| `reports/phase_3c_4_1_metrics.json` | JSON | Machine-readable Phase 3C.4.1 specification metrics and inventory counts. |
| `reports/phase_3c_4_1_checksums.txt` | Text | SHA-256 verification manifest of all specification deliverables. |
| `scripts/generate_phase_3c_4_artifacts.py` | Python | Dynamic, portable specification CSV generator engine. |
| `scripts/validate_phase_3c_4_spec.py` | Python | Standalone portable specification validator engine. |
| `data/processed/recommendation/phase_3c_4_README.md` | Markdown | This documentation and reproduction guide. |

---

## 3. Reproduction & Portability Instructions

To execute the validator engine from any working directory:

```bash
# Example 1: Run from pipeline root
cd FieldWise_main/model/ml_pipeline
python3 scripts/validate_phase_3c_4_spec.py

# Example 2: Run from /tmp to demonstrate full portability
cd /tmp
python3 <absolute_path_to>/FieldWise_main/model/ml_pipeline/scripts/validate_phase_3c_4_spec.py
```

Expected output:
- Verifies deliverable existence and minimum byte size.
- Asserts 100% coverage of all 19 canonical crops and readiness tiers.
- Validates 100 eligibility rules, status vocabulary, and traceable evidence.
- Verifies decoupled water model and absence of fixed water constants.
- Verifies fertilizer safety, absence of blanket multipliers, and DAP nitrogen credit.
- Validates all 15 acceptance tests and edge-case handling.
- Emits exit code 0.

---

## 4. SHA-256 Verification Manifest

```
30fb9c4133a26dd5872405fe84e271567fd1bd93a328060690d0c8dbe09f9d07  reports/phase_3c_4_input_contract.md
19a493a9a464cca3207e2a2d1eed3165e621687fcba7cbd2185a4c91d7301d42  reports/phase_3c_4_eligibility_rules.csv
6b8616860acc396e46471a2067cefd2ddef7a8c6cd768f0413ccea4e9b3f2dca  reports/phase_3c_4_scoring_architecture.md
1fbe5670ec886d095b362b6077c7179b3fd0b13647fa7fd9aeb574cdc3ca4315  reports/phase_3c_4_canonical_crop_catalogue.csv
d096a7b815cc6706ae083533f4ffabdbdcf72258b9ba8d5b80f7ec9d3c09efeb  reports/phase_3c_4_fertilizer_safety_spec.md
215e1edc88846fe917f1353e568da6cbaad23378cbce804e72f7620f11e43e22  reports/phase_3c_4_fallback_and_uncertainty_spec.md
5138043d204efb4d5255efcd75b232379a1babb7b062e8aaa29ee554d612c97b  reports/phase_3c_4_acceptance_test_matrix.csv
e7b250155ce40df969d5b1628b92565d847fb1bddbd71371787ba5bc103c8336  reports/phase_3c_4_source_evidence_gaps.csv
2e9ba76d8d09035c3499b692e9f5c31242ef4b13e925c37cb1103272a3da0bf3  reports/phase_3c_4_redesign_decision.md
64bd08689fb725447314be7523ab4e169f39e93fb66f87b8019d65f0f850acbe  reports/phase_3c_4_metrics.json
138a06cf23746fca6f0687f14ea199f9723003e35d951c3edd02f2ace854ee29  reports/phase_3c_4_1_correction_log.md
baa41c24934493cd49d07f13a0bd8b41816eadf4d79ccf87c6c641bc800b1ca7  reports/phase_3c_4_1_final_decision.md
64bd08689fb725447314be7523ab4e169f39e93fb66f87b8019d65f0f850acbe  reports/phase_3c_4_1_metrics.json
```
