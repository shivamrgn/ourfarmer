# FieldWise — Phase 3C.4: Recommendation Engine Redesign Decision & Technical Report

**Specification Version**: 1.0.0-PROPOSED  
**Phase**: Phase 3C.4 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  
**Governing Authority**: FieldWise ML Pipeline Architecture & Agronomic Validation Team  

---

## 1. Executive Summary & Purpose

Phase 3C.3 identified profound vulnerabilities in FieldWise's legacy recommendation engines (`model/predictor.js` and `src/lib/predictorEngine.ts`):
- **Additive Scoring Failure**: Overriding fatal constraints with unrelated positive scores, resulting in lethal recommendations (winter pulses recommended in 38°C desert summer; wheat recommended in 1200 mm submerged wetland).
- **Omission of Cultivation Season**: Zero checking of sowing season or calendar timing.
- **Water Semantics Distortion**: Compressing seasonal water requirements (350–2500 mm) into 30–300 mm monthly brackets.
- **NPK Measurement Confusion**: Conflating Soil Health Card soil test availability with fertilizer application rates.
- **Architectural Split-Brain**: Disjoint catalogs between online backend (16 crops) and offline frontend (16 crops) with divergent yields (+75% delta) and conflicting fertilizer prescriptions.

**Phase 3C.4 converts these critical audit findings into an implementable technical redesign specification**. In strict compliance with the Phase 3C.4 mandate, **zero application code was modified**. All artifacts represent technical specifications, data contracts, rule matrices, and test suites prepared for independent review before Phase 3C.5 implementation.

---

## 2. Summary of Redesign Specification Deliverables

| Deliverable Path | Document Title | Primary Contribution |
| :--- | :--- | :--- |
| `reports/phase_3c_4_input_contract.md` | Canonical Input Contract Specification | Defines structured contract for location, timing, irrigation tiers, climate, and soil test units. |
| `reports/phase_3c_4_eligibility_rules.csv` | Agronomic Eligibility Rules Matrix | 100 evidence-backed Boolean gating rules across 7 biological dimensions for all 19 crops. |
| `reports/phase_3c_4_scoring_architecture.md` | Scoring Architecture Specification | Replaces additive scoring with Two-Tier Hybrid Architecture (Boolean Gating $\to$ Liebig Geometric Ranking). |
| `reports/phase_3c_4_canonical_crop_catalogue.csv` | Canonical 19-Crop Master Catalogue | Single Source of Truth (SSOT) defining all 19 crops, eliminating backend/frontend asymmetry. |
| `reports/phase_3c_4_fertilizer_safety_spec.md` | Fertilizer & Soil-Nutrient Safety Spec | Decouples soil test ratings from RDF; defines STCR adjustments and commercial fertilizer bag splits. |
| `reports/phase_3c_4_fallback_and_uncertainty_spec.md` | Fallback & Uncertainty Handling Spec | Establishes 100% dual-engine parity, missing-data fallbacks, and zero-recommendation conditions. |
| `reports/phase_3c_4_acceptance_test_matrix.csv` | Mandatory Acceptance Test Matrix | 15 deterministic test cases (including regression of Scenarios S1–S5) with explicit pass criteria. |
| `reports/phase_3c_4_source_evidence_gaps.csv` | Source Evidence & Gaps Registry | Catalogs 10 major evidence gaps, citing ICAR, SAU, Govt, and FAO benchmarks with resolution status. |
| `reports/phase_3c_4_metrics.json` | Redesign Specification Metrics | Machine-readable inventory of all rules, contract fields, catalogue entries, and test definitions. |
| `scripts/validate_phase_3c_4_spec.py` | Specification Validation Engine | Standalone Python validation script verifying contract integrity and test assertions. |
| `data/processed/recommendation/phase_3c_4_README.md` | Documentation & Checksum Manifest | Directory overview, reproduction instructions, and SHA-256 verification manifest. |

---

## 3. Categorization of Engineering Decisions

### 3.1 Decisions Ready for Implementation (Phase 3C.5)
The following specifications are fully supported by peer-reviewed agronomic evidence and are ready for code implementation:
1. **Two-Tier Hybrid Architecture**: Implementation of Tier 1 Boolean Eligibility Gates followed by Tier 2 Liebig-Weighted Geometric Suitability Ranking.
2. **Canonical 19-Crop Single Source of Truth**: Consolidation of `model/cropDatabase.js` and `src/lib/predictorEngine.ts` into a single shared JSON asset (`canonical_crop_catalogue.json`).
3. **Cultivation Season Gating**: Strict enforcement of season compatibility (`Kharif`, `Rabi`, `Zaid`, `Annual`) before ranking.
4. **Water Availability Recalibration**: Replacing distorted 30–300 mm brackets with Total Effective Water ($W_{\text{eff}} = R_{\text{seasonal}} + I_{\text{capacity}}$) matched against true seasonal crop evapotranspiration ($ET_c$).
5. **Decoupled Soil Test Scoring**: Scoring farmer soil tests against standard Soil Health Card (DAC&FW) Low/Medium/High rating boundaries rather than raw fertilizer application doses.
6. **STCR Fertilizer Prescriptions**: Calculating commercial fertilizer bag requirements (Urea, DAP, SSP, MOP) via Soil-Test Crop Response formulas with split application schedules.
7. **Absolute pH Survival Bounds**: Hard exclusion of crops outside physiological survival limits ($[pH_{\min}-0.5, pH_{\max}+0.5]$).
8. **Explicit Rejection Output**: Returning `STATUS: NO_RECOMMENDATION_SUITABLE` when all crops are excluded or highest suitability $< 40/100$.

### 3.2 Decisions Requiring Agronomic Expert Review
The following design decisions are soundly grounded but should be reviewed by an ICAR or SAU agronomist before final field deployment:
1. **Diurnal Temperature Estimations**: When farmers only supply daily mean temperature, the engine estimates $T_{\min} = T_{\text{mean}} - 8°C$ and $T_{\max} = T_{\text{mean}} + 8°C$. This heuristic should be calibrated against IMD gridded daily data for specific agro-climatic zones.
2. **Soil Health Card Rating Tier Thresholds for Acid / Calcareous Soils**: Standard rating limits assume neutral alluvial/vertisol soils. Alkaline soils in Rajasthan or acid soils in Kerala may require modified available P extraction interpretations (Olsen vs Bray).
3. **Protective Irrigation Water Equivalence**: Defining `Partially_Irrigated_Protective` as $120\text{ mm}$ of effective water (two 60 mm irrigations). Expert review should confirm whether 120 mm is universally conservative across coarse sands.

### 3.3 Decisions Blocked by Missing Evidence
The following areas lack sufficient public granular data and are held back from hard constraint enforcement:
1. **District-Level Varietal Maturity Classes**: Wheat varieties in North India differ between timely-sown (135–140 days) and late-sown (110–115 days). Without varietal input, the engine applies general species-level thermal limits.
2. **Micro-Nutrient Threshold Gating**: While Zinc, Sulphur, and Boron are vital for specific crops (Rice, Mustard, Sunflower), soil test data for micronutrients is rarely available from smallholders. Micronutrient deficits trigger advisory notes rather than hard exclusions.
3. **Intercropping & Agro-Forestry Systems**: Current specification focuses strictly on sole-crop recommendations. Multi-crop intercropping models require separate agronomic competition matrices.

---

## 4. UI and Backend API Changes Required in Phase 3C.5

Transitioning to the redesigned engine requires the following non-breaking, structured interface enhancements:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          REQUIRED UI ENHANCEMENTS                           │
├─────────────────────────┬───────────────────────────────────────────────────┤
│ 1. Sowing Timing        │ Add "Intended Sowing Month" dropdown (Jan–Dec).   │
│                         │ Derive "Cultivation Season" automatically.        │
├─────────────────────────┼───────────────────────────────────────────────────┤
│ 2. Water Security       │ Add "Irrigation Availability" radio selector:     │
│                         │  [ ] Rainfed (Zero Irrigation)                    │
│                         │  [ ] Partially Irrigated (1–2 Life-Saving Cycles) │
│                         │  [ ] Assured Irrigation (Canal / Tubewell / Drip) │
├─────────────────────────┼───────────────────────────────────────────────────┤
│ 3. Rainfall Duration    │ Add "Rainfall Period" selector:                   │
│                         │  (•) Total Seasonal   ( ) Monthly Average         │
├─────────────────────────┼───────────────────────────────────────────────────┤
│ 4. Soil Test Toggle     │ Add "I have a Soil Health Card test" toggle.      │
│                         │ If enabled: prompt for N, P, K with kg/ha units.  │
│                         │ If disabled: prompt for qualitative fertility.    │
├─────────────────────────┼───────────────────────────────────────────────────┤
│ 5. Transparency Drawer  │ Add "Why were other crops excluded?" tab showing  │
│                         │ exact failing constraints for ineligible crops.   │
└─────────────────────────┴───────────────────────────────────────────────────┘
```

---

## 5. Remaining Production Risks & Mitigations

| Residual Risk | Severity | Engineered Mitigation in Redesign |
| :--- | :---: | :--- |
| **User Input Typo (e.g. pH 70 instead of 7.0)** | High | **Schema Range Validation**: Strict boundary checks reject out-of-bounds physical values ($3.0 \le \text{pH} \le 11.0$) with immediate form feedback. |
| **Farmer Inputs Unirrigated in Arid Zone** | High | **Hard Gating**: Arid rainfed conditions exclude high-water crops (Rice, Sugarcane, Banana) and promote drought-hardy Millets/Jowar. |
| **Offline Browser Disconnect** | Medium | **Dual-Engine SSOT Parity**: Frontend imports identical JSON catalogue and executes identical Tier 1/2 algorithms; zero output variance. |
| **Over-Reliance on Suitability Scores** | Medium | **Display Decoupling**: Scores are displayed as "Agronomic Match Index (0–100)" accompanied by explicit Data Completeness and Limiting Factor badges. |

---

## 6. Proposed Phase 3C.5 Implementation Sequence

Upon formal review and approval of this specification, implementation should proceed in four sequential, isolated work packages:

```
[Phase 3C.5 Implementation Sequence]
  │
  ├─► Work Package 1: Single Source of Truth (SSOT) Asset Generation
  │     - Compile canonical_crop_catalogue.json from phase_3c_4_canonical_crop_catalogue.csv.
  │     - Bundle shared JSON asset for both backend and frontend build pipelines.
  │
  ├─► Work Package 2: Backend Engine Refactoring (model/predictor.js)
  │     - Implement Tier 1 Boolean Eligibility Gate.
  │     - Implement Tier 2 Liebig-Weighted Geometric Suitability Ranker.
  │     - Refactor fertilizerDatabase.js to implement STCR adjustment formulas.
  │
  ├─► Work Package 3: Frontend Fallback Engine Refactoring (src/lib/predictorEngine.ts)
  │     - Mirror exact Tier 1 and Tier 2 algorithms in TypeScript.
  │     - Wire updated PredictionInputs interface in src/lib/api.ts.
  │
  └─► Work Package 4: Acceptance Regression Verification
        - Execute all 15 acceptance tests from phase_3c_4_acceptance_test_matrix.csv.
        - Verify 100% bitwise parity between backend API response and offline fallback.
```

---

## 7. Stop Condition & Governance Assurance

In accordance with Phase 3C.4 instructions:
- This phase is **STRICTLY A DESIGN SPECIFICATION**.
- **Zero changes have been made to live application files or database models.**
- The specification validator (`scripts/validate_phase_3c_4_spec.py`) was executed and passed with exit code 0.
- All 12 deliverables exist, have verified non-zero sizes, and are cataloged with SHA-256 checksums.

We now halt execution and submit this specification package for independent review. **Implementation will not begin until explicit approval is granted.**
