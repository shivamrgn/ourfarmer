"""
FieldWise Phase 3C.5: Data Completeness Index (DCI) & Confidence Evaluator
========================================================================
Formalizes the six orthogonal measurement domains, calculates the DCI score,
and classifies evidence into rigorous, uncalibrated confidence tiers.

Weights:
  w_temporal   = 0.15
  w_climate    = 0.20
  w_water      = 0.25
  w_soil       = 0.15
  w_ph         = 0.10
  w_nutrients  = 0.15
  Sum          = 1.000

Rejection Boundary:
  DCI < 0.500 triggers INSUFFICIENT_DATA rejection before biological scoring.
"""

from typing import Dict, List, Tuple
from .schemas import (
    RecommendationQuery,
    DCIResult,
    ConfidenceTier,
)


class DCIConfidenceEvaluator:
    """
    Evaluates query evidence completeness across the 6 orthogonal domains.
    """

    WEIGHTS = {
        "temporal": 0.15,
        "climate": 0.20,
        "water": 0.25,
        "soil": 0.15,
        "ph": 0.10,
        "nutrients": 0.15,
    }

    @classmethod
    def evaluate(cls, query: RecommendationQuery) -> DCIResult:
        """
        Calculates domain scores c_k, weighted DCI, and confidence tier.
        """
        c: Dict[str, float] = {}
        measured: List[str] = []
        imputed: List[str] = []

        # 1. Temporal (w1 = 0.15)
        # 1.00 for exact sowing date (YYYY-MM-DD); 0.60 for broad season/month only; 0.00 if omitted
        if query.temporal.sowing_date and len(query.temporal.sowing_date.split("-")) == 3:
            c["temporal"] = 1.00
            measured.append("sowing_date")
        elif query.temporal.sowing_month is not None:
            c["temporal"] = 0.60
            imputed.append("broad_temporal_month_only")
        else:
            c["temporal"] = 0.00
            imputed.append("temporal_omitted")

        # 2. Climate (w2 = 0.20)
        # 1.00 for measured temp and humidity; 0.50 for single parameter; 0.00 if omitted
        t_present = query.climate_and_water.temperature_mean is not None
        h_present = query.climate_and_water.relative_humidity is not None
        if t_present and h_present:
            c["climate"] = 1.00
            measured.append("temperature_and_humidity")
        elif t_present or h_present:
            c["climate"] = 0.50
            imputed.append("single_climate_parameter")
        else:
            c["climate"] = 0.00
            imputed.append("climate_omitted")

        # 3. Water (w3 = 0.25)
        # Strict Phase 3C.5.1 Evidence Provenance:
        # 1.00 for verified gauged rain + measured flow-meter irrigation (or gauged rainfed)
        # 0.75 for measured irrigation with estimated hours / uncalibrated pump rating
        # 0.60 for estimated / unverified rainfall
        # 0.40 for confirmed irrigation access but unmeasured volumetric depth
        # 0.00 if omitted
        cw = query.climate_and_water
        is_rainfed = (
            cw.irrigation_access is None
            or cw.irrigation_access.lower() in ["none_rainfed", "rainfed", "none"]
        ) and (cw.irrigation_water_quantity_mm is None or cw.irrigation_water_quantity_mm <= 0.0)

        rain_is_measured = cw.rainfall_source in ["IMD_Station_Gridded", "On_Farm_Rain_Gauge", "Gauged", "User_Gauge"] or (
            cw.rainfall_period_type == "Crop_Season_Measured" and cw.seasonal_rainfall_amount is not None
        )

        if is_rainfed:
            if cw.seasonal_rainfall_amount is not None:
                if rain_is_measured or getattr(query.climate_and_water, "is_gauged", True):
                    # Check if explicitly unverified/farmer estimated
                    if cw.rainfall_source in ["Farmer_Estimated", "Unverified_Estimate"]:
                        c["water"] = 0.60
                        imputed.append("estimated_unverified_rainfall")
                    else:
                        c["water"] = 1.00
                        measured.append("seasonal_rain_gauged")
                else:
                    c["water"] = 0.60
                    imputed.append("estimated_unverified_rainfall")
            else:
                c["water"] = 0.00
                imputed.append("water_omitted")
        else:
            if cw.irrigation_water_quantity_mm is not None and cw.irrigation_water_quantity_mm > 0.0:
                # Check measurement basis
                if cw.irrigation_quantity_basis in ["Estimated_Hours_Pump_Capacity", "Farmer_Estimated", "Uncalibrated_Estimate"]:
                    c["water"] = 0.75
                    imputed.append("estimated_irrigation_hours")
                else:
                    c["water"] = 1.00
                    measured.append("measured_irrigation_depth")
            elif cw.irrigation_access and cw.irrigation_access.lower() not in ["none_rainfed", "rainfed", "none"]:
                c["water"] = 0.40
                imputed.append("unmeasured_irrigation_volume")
            else:
                c["water"] = 0.00
                imputed.append("water_omitted")

        # 4. Soil Texture (w4 = 0.15)
        # Strict Phase 3C.5.1 Evidence Provenance:
        # Presence of texture does NOT prove laboratory mechanical analysis.
        # 1.00 for lab mechanical analysis (or lab accredited SHC test)
        # 0.50 for field feel method or regional map estimate
        # 0.00 if omitted
        if query.edaphic.soil_texture:
            tex_method = getattr(query.edaphic, "texture_measurement_method", None)
            is_reg = getattr(query.edaphic, "is_regional_estimate", False)
            if is_reg or tex_method in ["Regional_Map_Estimate", "Field_Feel_Method", "Farmer_Stated"]:
                c["soil"] = 0.50
                imputed.append("field_or_regional_soil_texture")
            elif tex_method in ["Lab_Mechanical_Analysis", "Hydrometer_Pipette"] or query.edaphic.has_soil_test or tex_method is None:
                c["soil"] = 1.00
                measured.append("soil_texture_measured")
            else:
                c["soil"] = 0.50
                imputed.append("soil_texture_unstated_method")
        else:
            c["soil"] = 0.00
            imputed.append("soil_texture_omitted")

        # 5. Soil pH (w5 = 0.10)
        # Strict Phase 3C.5.1 Evidence Provenance:
        # Presence of pH does NOT prove potentiometric laboratory analysis.
        # 1.00 for lab potentiometric analysis (1:2.5 soil-water suspension) or lab SHC
        # 0.50 for field colorimetric strip, portable meter, or unstated field reading
        # 0.00 if omitted
        if query.edaphic.soil_ph is not None:
            ph_method = getattr(query.edaphic, "ph_measurement_method", None)
            if ph_method in ["Field_Colorimetric_Strip", "Portable_Pocket_Pen", "Litmus_Paper", "Farmer_Stated"]:
                c["ph"] = 0.50
                imputed.append("field_strip_ph")
            elif ph_method in ["Lab_Potentiometric_1_2_5", "Certified_Lab"] or query.edaphic.has_soil_test or ph_method is None:
                c["ph"] = 1.00
                measured.append("soil_ph_potentiometric_lab")
            else:
                c["ph"] = 0.50
                imputed.append("soil_ph_unstated_method")
        else:
            c["ph"] = 0.00
            imputed.append("soil_ph_omitted")

        # 6. Nutrients (w6 = 0.15)
        # Strict Phase 3C.5.1 Evidence Provenance:
        # 1.00 for complete quantitative SHC test (all 3 N, P, K on SHC_Available_kg_ha basis)
        # 0.50 for qualitative fertility class or partial nutrients (1 or 2 nutrients provided)
        # 0.00 if omitted
        has_n = query.edaphic.soil_nitrogen is not None
        has_p = query.edaphic.soil_phosphorus is not None
        has_k = query.edaphic.soil_potassium is not None
        all_npk = has_n and has_p and has_k
        any_npk = has_n or has_p or has_k

        if query.edaphic.has_soil_test and all_npk:
            c["nutrients"] = 1.00
            measured.append("shc_quantitative_npk_complete")
        elif query.edaphic.has_soil_test and any_npk:
            c["nutrients"] = 0.50
            imputed.append("shc_partial_nutrients_incomplete")
        elif query.edaphic.nutrient_basis == "Qualitative_Fertility_Class":
            c["nutrients"] = 0.50
            imputed.append("qualitative_fertility")
        else:
            c["nutrients"] = 0.00
            imputed.append("nutrients_imputed_baseline")

        # Compute DCI = sum(w_k * c_k)
        dci_score = sum(cls.WEIGHTS[k] * c[k] for k in cls.WEIGHTS)
        dci_score = round(dci_score, 3)

        # Classify Confidence Tier
        if dci_score < 0.500:
            tier = ConfidenceTier.INSUFFICIENT_DATA
        elif dci_score >= 0.90:
            tier = ConfidenceTier.HIGH_CONFIDENCE
        elif dci_score >= 0.80 and c["nutrients"] == 0.0:
            tier = ConfidenceTier.HIGH_CONFIDENCE_ESTIMATED_FERTILITY
        elif dci_score >= 0.70:
            tier = ConfidenceTier.MODERATE_ESTIMATED
        else:
            tier = ConfidenceTier.PROVISIONAL_EVALUATION

        return DCIResult(
            dci_score=dci_score,
            domain_completeness=c,
            confidence_tier=tier,
            measured_dimensions=measured,
            imputed_dimensions=imputed,
        )
