"""
FieldWise Phase 3C.5.2.2: Trusted Verification Authority Registry
================================================================
Formalizes trusted verification authority governance to prevent fabricated
epistemic provenance claims.

Strict Verification Invariants (Finding 3):
  - A station ID alone CANNOT establish independent verification.
  - A laboratory name alone CANNOT establish independent verification.
  - Requires an actual trusted verification record from an accredited authority,
    matching observation/sample identifier, valid observation date/period,
    and official verification status.
  - User-provided strings or unverified metadata are NEVER promoted to
    INDEPENDENTLY_VERIFIED status (they remain USER_DECLARED).
  - Retains SOURCE_REFERENCED, USER_DECLARED, or UNKNOWN as appropriate.
"""

from typing import Dict, List, Optional, Tuple
from .schemas import TrustedVerificationRecord, ProvenanceTier


class TrustedVerificationRegistry:
    """
    Registry of recognized verification authorities and observation verification logic.
    """

    # Recognized national and state agricultural and meteorological verification authorities
    RECOGNIZED_AUTHORITIES: Dict[str, Dict[str, str]] = {
        "AUTH-ICAR-SHC-REGISTRY": {
            "name": "ICAR / DAC&FW National Soil Health Card Digital Portal",
            "jurisdiction": "National Soil Testing Laboratory Accreditation & Card Verification",
            "domain": "soil_and_nutrients",
        },
        "AUTH-IMD-AWS-NETWORK": {
            "name": "India Meteorological Department Automated Weather Station Network",
            "jurisdiction": "National Surface Meteorological Observation & Gridded Radar Data",
            "domain": "climate_and_rainfall",
        },
        "AUTH-CWC-HYDROLOGY": {
            "name": "Central Water Commission & State Irrigation Hydrometry Registry",
            "jurisdiction": "Calibrated Irrigation Discharge & Tubewell Flow Metering",
            "domain": "irrigation_water",
        },
        "AUTH-NABL-ACCREDITED-LAB": {
            "name": "National Accreditation Board for Testing and Calibration Laboratories (NABL)",
            "jurisdiction": "Certified Analytical Chemical and Edaphic Soil Testing Laboratories",
            "domain": "soil_and_nutrients",
        },
    }

    @classmethod
    def is_recognized_authority(cls, authority_id: str) -> bool:
        """Checks if authority ID is registered in the trusted authority directory."""
        if not authority_id:
            return False
        return authority_id.strip() in cls.RECOGNIZED_AUTHORITIES

    @classmethod
    def verify_observation(
        cls,
        expected_authority_type: str,
        observation_id: Optional[str],
        observation_date: Optional[str],
        verification_records: List[TrustedVerificationRecord],
    ) -> Tuple[bool, str, Optional[TrustedVerificationRecord]]:
        """
        Validates whether an observation ID (sample_id, station_id, meter_id) is
        grounded in an authentic, matching TrustedVerificationRecord.

        Rejects:
          - Observation IDs supplied without an authentic verification record.
          - Verification records from unrecognized authorities.
          - Mismatched sample / station identifiers.
          - Records with unverified status (not OFFICIALLY_VERIFIED).
          - Expired or date-incompatible verification records.
        """
        if not observation_id:
            return False, "No observation or sample identifier provided.", None

        if not verification_records:
            return (
                False,
                f"Observation ID '{observation_id}' lacks a trusted verification record. "
                "User-supplied IDs without trusted verification records are classified as USER_DECLARED.",
                None,
            )

        clean_obs_id = observation_id.strip().lower()

        # Search for a matching, valid record
        for rec in verification_records:
            if not isinstance(rec, TrustedVerificationRecord):
                continue

            # 1. Authority recognition check
            auth_id = rec.verification_authority_id.strip() if rec.verification_authority_id else ""
            if not cls.is_recognized_authority(auth_id):
                continue

            # 2. Authority domain matching
            auth_meta = cls.RECOGNIZED_AUTHORITIES[auth_id]
            if expected_authority_type and auth_meta["domain"] != expected_authority_type:
                continue

            # 3. Observation / Sample ID matching
            rec_obs_id = rec.observation_or_sample_id.strip().lower() if rec.observation_or_sample_id else ""
            if rec_obs_id != clean_obs_id:
                continue

            # 4. Verification status check
            if rec.verification_status not in ["OFFICIALLY_VERIFIED", "TRUSTED_AUTHORITY_CONFIRMED"]:
                continue

            # 5. Digital token / signature check (optional token; if provided must be non-empty)
            if rec.digital_signature_or_token and len(rec.digital_signature_or_token.strip()) < 4:
                continue

            # 6. Temporal bounds check (if observation date provided)
            if observation_date and rec.applicable_date_start and rec.applicable_date_end:
                if not (rec.applicable_date_start <= observation_date <= rec.applicable_date_end):
                    continue

            # All checks passed: genuine trusted verification established!
            return True, f"Observation '{observation_id}' officially verified by {auth_meta['name']}.", rec

        return (
            False,
            f"Observation ID '{observation_id}' could not be verified by any recognized authority. "
            "Retained as USER_DECLARED.",
            None,
        )
