import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import { api, predictApi, V2ApiError, V2NetworkError } from '../lib/api';
import PredictionFormV2 from '../components/v2/PredictionFormV2';
import PredictionResultsV2 from '../components/v2/PredictionResultsV2';
import CropRecommendation from '../components/modules/CropRecommendation';
import type { V2PredictRequest, V2PredictResponse } from '../types/v2Prediction';

// ── 1. Stabilize Authentication & Context Mocks ──────────────────────────────
const { MOCK_USER } = vi.hoisted(() => ({
  MOCK_USER: {
    id: 'test_farmer_1',
    username: 'farmer1',
    email: 'farmer@test.com',
    full_name: 'Test Farmer',
    location: 'Punjab',
    farm_size: '10 Acres',
  },
}));

vi.mock('@/context/AuthContext', () => ({
  useAuth: () => ({ user: MOCK_USER }),
}));

vi.mock('@/components/dashboard/WeatherContext', () => ({
  useWeather: () => ({
    weatherData: null,
    loading: false,
    error: null,
    refreshWeather: vi.fn(),
  }),
}));

// ── 2. Authoritative V2 Response Envelope Fixtures ───────────────────────────
const sampleSuccessResponse: V2PredictResponse = {
  success: true,
  version: '2.2.0-CLOSURE',
  status: 'SUCCESS',
  data: {
    status: 'SUCCESS',
    engine_version: '3.6.2.2',
    execution_timestamp: '2026-11-21T12:00:00Z',
    query_summary: {
      location: 'Punjab',
      season: 'Rabi',
      planting_system_evaluated: 'Sole_Crop',
      water_regime_evaluated: 'Irrigated',
      data_completeness_index: 85,
      evidence_confidence_tier: 'FARMER_DECLARED',
    },
    recommendations: [
      {
        crop_id: 'wheat',
        canonical_name: 'Wheat',
        suitability_score: 88.5,
        rank: 1,
        tier1_status: 'PASS',
        yield_range: [3.5, 5.0],
        water_assessment: {
          crop_water_demand_mm: 450,
          effective_water_available_mm: 300,
          water_balance_ratio: 0.67,
          irrigation_requirement_net_mm: 150,
          irrigation_access_considered: 'Canal',
        },
        fertilizer_prescription: {
          status: 'BASELINE_RDF_ARITHMETIC',
          evidence_level: 'USER_DECLARED',
          nitrogen_kg_ha: 120,
          phosphorus_kg_ha: 60,
          potassium_kg_ha: 40,
        },
        risk_warnings: ['Monitor soil moisture during flowering stage.'],
      },
    ],
    excluded_candidates: [
      {
        crop_id: 'rice',
        canonical_name: 'Rice',
        tier1_status: 'FAIL',
        failing_rules: [
          {
            rule: 'WATER_BALANCE_GATE',
            reason: 'Water requirement (1200 mm) exceeds available water (300 mm)',
          },
        ],
      },
    ],
  },
};

const sampleInsufficientDataResponse: V2PredictResponse = {
  success: true,
  version: '2.2.0-CLOSURE',
  status: 'INSUFFICIENT_DATA',
  data: {
    status: 'INSUFFICIENT_DATA',
    engine_version: '3.6.2.2',
    execution_timestamp: '2026-11-21T12:00:00Z',
    query_summary: {
      location: 'Punjab',
      season: 'Unknown',
      planting_system_evaluated: 'Sole_Crop',
      water_regime_evaluated: 'Unknown',
      data_completeness_index: 25,
      evidence_confidence_tier: 'INSUFFICIENT_DATA',
    },
    recommendations: [],
    excluded_candidates: [],
    diagnostics: {
      reason: 'Sowing month and regional climate context are required to assess seasonal viability.',
      missing_critical_parameters: ['sowing_month', 'temperature_celsius'],
      recommendation_suggestions: [
        'Select the planned sowing month.',
        'Provide temperature or location coordinates.',
      ],
    },
  },
};

const sampleNoRecommendationResponse: V2PredictResponse = {
  success: true,
  version: '2.2.0-CLOSURE',
  status: 'NO_RECOMMENDATION_SUITABLE',
  data: {
    status: 'NO_RECOMMENDATION_SUITABLE',
    engine_version: '3.6.2.2',
    execution_timestamp: '2026-11-21T12:00:00Z',
    query_summary: {
      location: 'Punjab',
      season: 'Rabi',
      planting_system_evaluated: 'Sole_Crop',
      water_regime_evaluated: 'Irrigated',
      data_completeness_index: 80,
      evidence_confidence_tier: 'FARMER_DECLARED',
    },
    recommendations: [],
    excluded_candidates: [],
    land_reclamation_advisory:
      'Severe soil acidity (pH 4.0) inhibits nutrient uptake across all regional crops. Apply agricultural lime (calcium carbonate) at 2.5 t/ha before next cultivation.',
  },
};

describe('Phase 3C.6.3: Frontend V2 Integration Tests', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  // ─────────────────────────────────────────────────────────────
  // 1. API Client (`predictApi.predictV2`)
  // ─────────────────────────────────────────────────────────────
  describe('predictApi.predictV2 API Client', () => {
    it('successfully calls POST /api/v2/predict and returns V2PredictResponse', async () => {
      const postSpy = vi.spyOn(api, 'post').mockResolvedValueOnce({
        status: 200,
        data: sampleSuccessResponse,
      } as any);

      const payload: V2PredictRequest = {
        state: 'Punjab',
        soil_texture: 'Loam',
        nitrogen: 100,
        phosphorus: 50,
        potassium: 40,
        soil_ph: 6.8,
        temperature: 22,
        humidity: 65,
        sowing_month: 11,
      };

      const result = await predictApi.predictV2(payload);
      expect(postSpy).toHaveBeenCalledWith(
        '/api/v2/predict',
        payload,
        { headers: { 'Content-Type': 'application/json' } }
      );
      expect(result.status).toBe('SUCCESS');
      expect(result.data.recommendations).toHaveLength(1);
    });

    it('throws V2ApiError with status 400 on HTTP 400 Bad Request without V1 fallback', async () => {
      vi.spyOn(api, 'post').mockRejectedValueOnce({
        isAxiosError: true,
        response: {
          status: 400,
          data: {
            error: 'Validation failed',
            details: [{ field: 'soil_ph', message: 'pH must be between 2.0 and 12.0' }],
          },
        },
      });

      await expect(
        predictApi.predictV2({
          state: 'Punjab',
          soil_texture: 'Loam',
          nitrogen: 100,
          phosphorus: 50,
          potassium: 40,
          soil_ph: 1.5,
          temperature: 22,
          humidity: 65,
          sowing_month: 11,
        })
      ).rejects.toThrow(V2ApiError);
    });

    it('throws V2ApiError with status 422 on HTTP 422 Unprocessable Entity', async () => {
      vi.spyOn(api, 'post').mockRejectedValueOnce({
        isAxiosError: true,
        response: {
          status: 422,
          data: {
            error: 'Agronomically impossible combination',
            message: 'Temperature exceeds absolute physiological bounds',
          },
        },
      });

      await expect(
        predictApi.predictV2({
          state: 'Rajasthan',
          soil_texture: 'Sandy',
          nitrogen: 10,
          phosphorus: 10,
          potassium: 10,
          soil_ph: 7.0,
          temperature: 65,
          humidity: 10,
          sowing_month: 5,
        })
      ).rejects.toThrow(V2ApiError);
    });

    it('throws V2ApiError with status 502/503/504 on gateway/service errors without silent fallback', async () => {
      vi.spyOn(api, 'post').mockRejectedValueOnce({
        isAxiosError: true,
        response: {
          status: 502,
          data: { error: 'Recommendation engine subprocess exited with code 1' },
        },
      });

      try {
        await predictApi.predictV2({
          state: 'Punjab',
          soil_texture: 'Loam',
          nitrogen: 100,
          phosphorus: 50,
          potassium: 40,
          soil_ph: 6.8,
          temperature: 22,
          humidity: 65,
          sowing_month: 11,
        });
        expect.unreachable('Should have thrown V2ApiError');
      } catch (err) {
        expect(err).toBeInstanceOf(V2ApiError);
        expect((err as V2ApiError).status).toBe(502);
      }
    });

    it('throws V2NetworkError on connection failure without silent fallback', async () => {
      vi.spyOn(api, 'post').mockRejectedValueOnce({
        isAxiosError: true,
        request: {},
        message: 'Network Error',
      });

      await expect(
        predictApi.predictV2({
          state: 'Punjab',
          soil_texture: 'Loam',
          nitrogen: 100,
          phosphorus: 50,
          potassium: 40,
          soil_ph: 6.8,
          temperature: 22,
          humidity: 65,
          sowing_month: 11,
        })
      ).rejects.toThrow(V2NetworkError);
    });

    it('preserves V1 predictApi.predict method and fallback behavior intact', async () => {
      // Mock axios post failure for V1 to test local Gaussian engine fallback
      vi.spyOn(api, 'post').mockRejectedValueOnce(new Error('Network error'));

      const v1Result = await predictApi.predict({
        rainfall: 800,
        temperature: 25,
        humidity: 60,
        soilType: 'Loamy',
        nitrogen: 100,
        phosphorus: 50,
        potassium: 40,
        ph: 6.5,
        state: 'Punjab',
      });

      expect(v1Result.data).toBeDefined();
      expect(v1Result.data.mode).toBe('offline_ml_engine');
      expect(v1Result.data.predictions.length).toBeGreaterThan(0);
    });
  });

  // ─────────────────────────────────────────────────────────────
  // 2. Form Payload Construction & Validation (`PredictionFormV2`)
  // ─────────────────────────────────────────────────────────────
  describe('PredictionFormV2 Component', () => {
    it('renders initial state with unselected sowing month and unknown irrigation', () => {
      render(<PredictionFormV2 onSubmit={vi.fn()} isLoading={false} />);

      // Sowing month select shows placeholder & unselected warning
      expect(screen.getByText(/Select sowing month\.\.\./i)).toBeInTheDocument();
      expect(screen.getByText(/Unselected by default/i)).toBeInTheDocument();

      // Submit button is disabled because sowing_month is null
      const submitBtn = screen.getByRole('button', { name: /Evaluate Crops with Engine V2/i });
      expect(submitBtn).toBeDisabled();

      // Soil test checkbox should be unchecked
      const soilTestCheckbox = screen.getByRole('checkbox', {
        name: /Farmer-Declared Soil Health Card/i,
      });
      expect(soilTestCheckbox).not.toBeChecked();
    });

    it('validates numeric bounds for negative nitrogen and shows error', async () => {
      render(
        <PredictionFormV2
          onSubmit={vi.fn()}
          isLoading={false}
          initialValues={{ state: 'Punjab', sowing_month: 11, nitrogen: -10 }}
        />
      );

      const submitBtn = screen.getByRole('button', { name: /Evaluate Crops with Engine V2/i });
      expect(submitBtn).not.toBeDisabled();
      fireEvent.click(submitBtn);

      await waitFor(() => {
        expect(screen.getByText(/Nitrogen cannot be negative\./i)).toBeInTheDocument();
      });
    });

    it('validates whole-day integers for irrigation period days and rejects non-positive/zero', async () => {
      render(
        <PredictionFormV2
          onSubmit={vi.fn()}
          isLoading={false}
          initialValues={{ state: 'Punjab', sowing_month: 11, irrigation_period_days: 0 }}
        />
      );

      const submitBtn = screen.getByRole('button', { name: /Evaluate Crops with Engine V2/i });
      fireEvent.click(submitBtn);

      await waitFor(() => {
        expect(screen.getByText(/Irrigation period must be an integer greater than 0\./i)).toBeInTheDocument();
      });
    });

    it('correctly constructs V2 payload with seasonal rainfall separate from annual rainfall', async () => {
      const mockSubmit = vi.fn();
      render(
        <PredictionFormV2
          onSubmit={mockSubmit}
          isLoading={false}
          initialValues={{
            state: 'Punjab',
            sowing_month: 11,
            irrigation_access: 'None_Rainfed',
            seasonal_rainfall_amount: 450,
            annual_rainfall: 950,
            has_soil_test: true,
          }}
        />
      );

      const submitBtn = screen.getByRole('button', { name: /Evaluate Crops with Engine V2/i });
      expect(submitBtn).not.toBeDisabled();
      fireEvent.click(submitBtn);

      await waitFor(() => {
        expect(mockSubmit).toHaveBeenCalledTimes(1);
      });

      const submittedPayload: V2PredictRequest = mockSubmit.mock.calls[0][0];
      expect(submittedPayload.state).toBe('Punjab');
      expect(submittedPayload.sowing_month).toBe(11);
      expect(submittedPayload.has_soil_test).toBe(true);
      expect(submittedPayload.seasonal_rainfall_amount).toBe(450);
      expect(submittedPayload.annual_rainfall).toBe(950);
      expect(submittedPayload.irrigation_access).toBe('None_Rainfed');
    });

    it('omits seasonal rainfall when empty and leaves irrigation null when unknown', async () => {
      const mockSubmit = vi.fn();
      render(
        <PredictionFormV2
          onSubmit={mockSubmit}
          isLoading={false}
          initialValues={{
            state: 'Haryana',
            sowing_month: 6,
            irrigation_access: null,
            seasonal_rainfall_amount: null,
            has_soil_test: false,
          }}
        />
      );

      const submitBtn = screen.getByRole('button', { name: /Evaluate Crops with Engine V2/i });
      fireEvent.click(submitBtn);

      await waitFor(() => {
        expect(mockSubmit).toHaveBeenCalledTimes(1);
      });

      const submittedPayload: V2PredictRequest = mockSubmit.mock.calls[0][0];
      expect(submittedPayload.sowing_month).toBe(6);
      expect(submittedPayload.has_soil_test).toBe(false);
      expect(submittedPayload.seasonal_rainfall_amount).toBeNull();
      expect(submittedPayload.irrigation_access).toBeNull();
    });
  });

  // ─────────────────────────────────────────────────────────────
  // 3. Results Presentation (`PredictionResultsV2`)
  // ─────────────────────────────────────────────────────────────
  describe('PredictionResultsV2 Component', () => {
    it('renders SUCCESS state with suitability score, explicit notice, yield range, and water/fertilizer guidance', () => {
      render(<PredictionResultsV2 response={sampleSuccessResponse} error={null} />);

      // Engine status banner
      expect(screen.getByText(/Agronomic Recommendations/i)).toBeInTheDocument();

      // Recommended crop and score
      expect(screen.getByText('Wheat')).toBeInTheDocument();
      expect(screen.getByText('88.5')).toBeInTheDocument();

      // Suitability notice (explicit: NOT statistical probability)
      expect(
        screen.getByText(/Suitability Score Meaning:/i)
      ).toBeInTheDocument();

      // Yield range as [min, max] t/ha (not a single point)
      expect(screen.getByText(/3\.5 – 5 t\/ha/i)).toBeInTheDocument();

      // Water assessment
      expect(screen.getByText(/Crop Water Balance Assessment/i)).toBeInTheDocument();
      expect(screen.getByText('450 mm')).toBeInTheDocument(); // Demand
      expect(screen.getByText('150 mm')).toBeInTheDocument(); // Deficit

      // Fertilizer prescription with farmer-declared warning
      expect(screen.getByText(/Nutrient Requirements & Fertilizer Guidance/i)).toBeInTheDocument();
      expect(
        screen.getByText(/Status: BASELINE_RDF_ARITHMETIC \(Farmer-Declared\)/i)
      ).toBeInTheDocument();

      // Excluded candidates accordion
      expect(screen.getByText(/Why Other Crops Were Not Recommended/i)).toBeInTheDocument();
      fireEvent.click(screen.getByText(/Why Other Crops Were Not Recommended/i));
      expect(screen.getByText('Rice')).toBeInTheDocument();
      expect(screen.getByText(/Water requirement \(1200 mm\) exceeds available water/i)).toBeInTheDocument();
    });

    it('renders INSUFFICIENT_DATA state with missing parameters, suggestions, and zero crops', () => {
      render(<PredictionResultsV2 response={sampleInsufficientDataResponse} error={null} />);

      expect(screen.getByText(/Insufficient Data for Reliable Agronomic Evaluation/i)).toBeInTheDocument();
      expect(screen.getByText(/Diagnostic Reason/i)).toBeInTheDocument();
      expect(
        screen.getByText(/Sowing month and regional climate context are required to assess seasonal viability\./i)
      ).toBeInTheDocument();

      // Verify zero recommended crops
      expect(screen.queryByText(/Reference Expected Yield Range/i)).not.toBeInTheDocument();
    });

    it('renders NO_RECOMMENDATION_SUITABLE state with land reclamation advisory and zero invented crops', () => {
      render(<PredictionResultsV2 response={sampleNoRecommendationResponse} error={null} />);

      expect(
        screen.getByText(/No Crops Met Agronomic Viability Threshold Under Current Conditions/i)
      ).toBeInTheDocument();
      expect(
        screen.getByText(/Authoritative Land Reclamation & Management Advisory/i)
      ).toBeInTheDocument();
      expect(
        screen.getByText(/Severe soil acidity \(pH 4\.0\) inhibits nutrient uptake across all regional crops/i)
      ).toBeInTheDocument();

      // Zero recommended crops
      expect(screen.queryByText(/Reference Expected Yield Range/i)).not.toBeInTheDocument();
    });

    it('renders error banner with retry button on error', () => {
      const mockRetry = vi.fn();
      const testError = new V2ApiError('Process timeout after 10000ms', 504, 'TIMEOUT', {
        message: 'The recommendation engine exceeded its maximum execution time window (10,000 ms) and was terminated.',
      });

      render(<PredictionResultsV2 response={null} error={testError} onRetry={mockRetry} />);

      expect(screen.getByText(/Execution Timeout \(HTTP 504\)/i)).toBeInTheDocument();
      expect(screen.getByText(/Process timeout after 10000ms/i)).toBeInTheDocument();

      const retryBtn = screen.getByRole('button', { name: /Retry Analysis/i });
      fireEvent.click(retryBtn);
      expect(mockRetry).toHaveBeenCalledTimes(1);
    });
  });

  // ─────────────────────────────────────────────────────────────
  // 4. Switcher & V1 Compatibility (`CropRecommendation`)
  // ─────────────────────────────────────────────────────────────
  describe('CropRecommendation Module Integration', () => {
    it('renders Engine V2 by default with Engine Switcher buttons', () => {
      render(
        <MemoryRouter>
          <CropRecommendation user={MOCK_USER} onNavigate={vi.fn()} />
        </MemoryRouter>
      );

      // Switcher buttons
      const v2Btn = screen.getByRole('button', { name: /Engine V2 \(Recommended\)/i });
      const v1Btn = screen.getByRole('button', { name: /Engine V1 \(Legacy\)/i });
      expect(v2Btn).toBeInTheDocument();
      expect(v1Btn).toBeInTheDocument();

      // V2 Form is active
      expect(screen.getByLabelText(/Planned Sowing Month/i)).toBeInTheDocument();
      expect(screen.getByText(/Farmer-Declared Soil Health Card/i)).toBeInTheDocument();
    });

    it('switches to Engine V1 on toggle and preserves V1 form and farm profile', () => {
      render(
        <MemoryRouter>
          <CropRecommendation user={MOCK_USER} onNavigate={vi.fn()} />
        </MemoryRouter>
      );

      const v1Btn = screen.getByRole('button', { name: /Engine V1 \(Legacy\)/i });
      fireEvent.click(v1Btn);

      // V1 sections should now be visible
      expect(screen.getByRole('heading', { name: /Your Farm/i })).toBeInTheDocument();
      expect(screen.getByRole('heading', { name: /Available Farm Conditions/i })).toBeInTheDocument();
      expect(screen.getByRole('heading', { name: /Soil Characteristics & NPK Nutrients/i })).toBeInTheDocument();
      expect(screen.getByRole('heading', { name: /Environmental & Climate Conditions/i })).toBeInTheDocument();

      // Switch back to V2
      const v2Btn = screen.getByRole('button', { name: /Engine V2 \(Recommended\)/i });
      fireEvent.click(v2Btn);
      expect(screen.getByLabelText(/Planned Sowing Month/i)).toBeInTheDocument();
    });
  });
});
