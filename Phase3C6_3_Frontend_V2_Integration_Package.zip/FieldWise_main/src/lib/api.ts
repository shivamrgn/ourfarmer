/**
 * CropPredict AI — Axios API Client
 * Base URL points to backend. Interceptor auto-attaches JWT from localStorage.
 */

import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export const api = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// ── Request interceptor: attach JWT Bearer token ─────────────────────────────
api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('croppredict_token');
        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

// ── Response interceptor: handle responses and errors ─────────────────────────────
api.interceptors.response.use(
    (response) => response,
    (error) => {
        return Promise.reject(error);
    }
);


// ── Auth helpers ─────────────────────────────────────────────────────────────

export const authApi = {
    login: (email: string, password: string) =>
        api.post('/api/auth/login', { email, password }),

    register: (name: string, email: string, password: string) =>
        api.post('/api/auth/register', { name, email, password }),

    getMe: () => api.get('/api/auth/me'),
};

import { predictCropsEngine } from './predictorEngine';
import { V2PredictRequest, V2PredictResponse } from '../types/v2Prediction';

export class V2ApiError extends Error {
    code: string;
    status: number;
    details?: any;

    constructor(message: string, status: number, code?: string, details?: any) {
        super(message);
        this.name = 'V2ApiError';
        this.status = status;
        this.code = code || `HTTP_${status}`;
        this.details = details;
        Object.setPrototypeOf(this, V2ApiError.prototype);
    }
}

export class V2NetworkError extends Error {
    code: string;
    status: number;

    constructor(message = 'FieldWise Recommendation Service is unreachable. Please verify network connectivity or that the backend server is active.') {
        super(message);
        this.name = 'V2NetworkError';
        this.code = 'NETWORK_ERROR';
        this.status = 0;
        Object.setPrototypeOf(this, V2NetworkError.prototype);
    }
}

export const predictApi = {
    // ── V1 Predictor Method (Preserved Unchanged) ─────────────────────────────
    predict: async (data: {
        rainfall: number;
        temperature: number;
        humidity: number;
        soilType: string;
        nitrogen: number;
        phosphorus: number;
        potassium: number;
        ph: number;
        state: string;
    }) => {
        try {
            const res = await api.post('/api/predict', data);
            return res;
        } catch (err: any) {
            // Rethrow client-side 4xx errors (validation failures from express-validator)
            if (err?.response && err.response.status >= 400 && err.response.status < 500) {
                throw err;
            }
            // When backend is not running or unreachable, run the local Gaussian prediction engine
            const localPredictions = predictCropsEngine(data);
            return {
                data: {
                    success: true,
                    mode: 'offline_ml_engine',
                    predictions: localPredictions,
                }
            };
        }
    },

    // ── V2 Recommendation Engine Bridge Client (Phase 3C.6.3) ────────────────
    predictV2: async (data: V2PredictRequest): Promise<V2PredictResponse> => {
        try {
            const res = await api.post<V2PredictResponse>('/api/v2/predict', data, {
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            return res.data;
        } catch (err: any) {
            // Distinguish HTTP 400, 422, 502, 503, 504 and Network Errors
            // CRITICAL: Never silently fall back to V1 on a V2 error!
            if (err?.response) {
                const status = err.response.status;
                const errData = err.response.data?.error || err.response.data || {};
                const message =
                    errData.message ||
                    (typeof err.response.data === 'string'
                        ? err.response.data
                        : `V2 API request failed with status ${status}`);
                const code = errData.code || `HTTP_${status}`;
                throw new V2ApiError(message, status, code, errData);
            } else if (err?.request) {
                throw new V2NetworkError();
            }
            throw err;
        }
    },
};
