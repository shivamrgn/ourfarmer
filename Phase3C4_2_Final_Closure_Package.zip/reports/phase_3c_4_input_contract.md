# FieldWise — Phase 3C.4: Canonical Input Contract Specification

**Specification Version**: 1.2.0-FINAL-CLOSURE (Phase 3C.4.2)  
**Phase**: Phase 3C.4 / Phase 3C.4.2 (Final Specification Closure)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Overview & Objective

Phase 3C.3 proved that FieldWise's existing recommendation input interface suffered from critical semantic ambiguities:
1. Conflating annual rainfall, seasonal rainfall, and monthly rainfall into an uncalibrated scalar.
2. Silently interpreting Recommended Dose of Fertilizers (RDF) as soil test nutrient targets.
3. Completely omitting cultivation season, intended sowing date, and regional planting windows.
4. Conflating qualitative irrigation infrastructure access with guaranteed volumetric water delivery.
5. Assuming all farmers have laboratory soil tests, with zero defined missing-data behavior.
6. Forcing diverse planting systems (Boro rice, Adsali sugarcane, Spring maize) into rigid broad season buckets (Kharif, Rabi, Zaid).

This document establishes the **Canonical Input Contract** for FieldWise, updated to Phase 3C.4.2 to resolve all season/planting window incompatibilities and decouple water availability accounting. It formally specifies every location, climate, temporal, edaphic, and water input required to make an agronomically defensible crop recommendation.

---

## 2. Decoupled Season & Planting-Window Data Model

### 2.1 The Architectural Disconnect in Broad Seasons
Prior iterations categorized cultivation exclusively into three broad seasons: `Kharif`, `Rabi`, and `Zaid` (plus a vague `Annual` bucket). This created direct agronomic contradictions:
- **Boro Rice**: Sown in nursery beds in November–December, transplanted into puddled fields in December–January, and harvested in April–May in West Bengal, Assam, and Bihar. Classifying Boro as `Kharif` fails because Kharif begins in June; classifying it as `Rabi` fails standard rice thermal checks; classifying it as `Zaid` fails because Zaid begins in March.
- **Adsali Sugarcane**: Planted in July–August in Maharashtra and Karnataka and grown for 15–18 months. Classifying it as an annual crop conflates it with 10–12 month `Eksali` or Spring canes.
- **Tomato & Vegetable Crops**: Cultivated across three overlapping overlapping cycles (Autumn-Winter, Spring-Summer, Rainy season) depending on altitude, pest pressures, and frost risks.
- **Perennial Fruit Trees (Mango, Banana)**: Mango is a permanent orchard tree taking 4–7 years to first commercial bearing with phenological cycles (flowering in Feb–Mar, fruiting in May–Jul), while Banana is a 11–13 month giant herbaceous crop planted year-round under assured irrigation.

### 2.2 Formal Six-Field Temporal & Cultivation Data Model
To resolve this without breaking simple interfaces, the temporal contract is factored into six distinct architectural dimensions:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    TEMPORAL & CULTIVATION CONTRACT DIMENSIONS                   │
├─────────────────────────────────────────────────┬───────────────────────────────┤
│ 1. broad_season (Enum)                          │ Kharif, Rabi, Zaid,           │
│                                                 │ Boro_Special, Annual_Special, │
│                                                 │ Perennial_Orchard             │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 2. planting_system (String / Enum)              │ Aman, Boro, Aus, Timely_Sown, │
│                                                 │ Late_Sown, Adsali, Eksali,    │
│                                                 │ Spring, Summer, Main_Crop,    │
│                                                 │ Standard_Orchard              │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 3. region_or_agro_climatic_zone (Location)      │ State, District,              │
│                                                 │ ICAR Agro-Climatic Zone       │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 4. sowing_date_or_month_range (Date/Range)      │ sowing_month (1-12),          │
│                                                 │ sowing_date (YYYY-MM-DD),     │
│                                                 │ window_range (e.g. Nov 1-15)  │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 5. crop_life_cycle (Enum)                       │ Annual_Seasonal,              │
│                                                 │ Long_Duration_Annual,         │
│                                                 │ Perennial_Orchard             │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 6. window_evidence_status (Enum)                │ VERIFIED, PROVISIONAL,        │
│                                                 │ UNKNOWN                       │
└─────────────────────────────────────────────────┴───────────────────────────────┘
```

### 2.3 Life Cycle Categories
Every candidate crop belongs to exactly one life cycle category:
1. **`Annual_Seasonal`** (e.g. Wheat, Rice, Maize, Mustard, Chickpea, Lentil, Soybean, Cotton, Groundnut, Potato, Barley, Millets, Jowar, Sunflower, Onion, Tomato):
   - Single distinct season cycle (90 to 180 days).
   - Evaluated strictly against sowing-stage temperature, seasonal rainfall/irrigation, and designated regional planting window.
2. **`Long_Duration_Annual`** (e.g. Sugarcane):
   - Spans 10 to 18 months, crossing multiple meteorological seasons.
   - Evaluated against initial establishment conditions and multi-season cumulative water availability.
3. **`Perennial_Orchard`** (e.g. Mango, Banana):
   - Permanent or multi-year cultivation requiring multi-year land commitment.
   - Mango requires distinct evaluation: vegetative planting vs reproductive floral induction.
   - Banana requires 11–13 month frost-free warm humid conditions with high water continuity.

---

## 3. Resolution Matrix: User Input Scenarios

The engine deterministically resolves temporal eligibility depending on what inputs the user supplies:

| User Input Combination | Engine Resolution Logic | Resulting Window Status | Advisory / Uncertainty Behavior |
| :--- | :--- | :---: | :--- |
| **1. Season Only** (e.g. "Rabi") | 1. Maps `broad_season` to default regional planting system for each crop in user's state/zone.<br>2. Adopts midpoint calendar month of that season (e.g. Rabi $\to$ November). | `PROVISIONAL` | Prompts user to confirm specific sowing month. Flags: *"Cultivated window assumed as mid-season normal; specify exact sowing date for precision germination checks."* |
| **2. Sowing Date Only** (e.g. "Nov 10") | 1. Extracts calendar month ($m = 11$).<br>2. Automatically derives `broad_season` from state agricultural calendar (Nov in Punjab $\to$ `Rabi`; Nov in Assam $\to$ `Boro_Special` or `Rabi`).<br>3. Matches date against verified regional windows. | `VERIFIED` | Evaluates precise timely vs late sowing window boundaries. |
| **3. Both Season and Sowing Date** | 1. Cross-validates compatibility between season and date.<br>2. If compatible: executes full regional window matching.<br>3. If conflicting (e.g. "Kharif" with "December 15"): halts with validation error prompting correction. | `VERIFIED` | Highest precision evaluation. |
| **4. Unknown Planting Window** (Crop not established in region) | 1. Crop lacks verified package of practices for the specified zone/district.<br>2. Does not invent speculative window.<br>3. Evaluates generic physiological thermal limits. | `PROVISIONAL` | Marks recommendation badge as `PROVISIONAL`. Displays advisory: *"No locally verified ICAR/SAU planting window for this crop in your district; feasibility evaluated on general thermal bounds."* |
| **5. Region with No Verified Planting Window** (Unsupported State/District) | 1. System falls back to macro-climatic agro-zone default.<br>2. If macro-zone unknown: marks window as `UNKNOWN`.<br>3. Decrements Data Completeness Index ($DCI \le 0.70$). | `UNKNOWN` | Capped at `PROVISIONAL_EVALUATION` confidence tier. |

---

## 4. Worked Crop-Specific Examples

### 4.1 Rice (*Oryza sativa*)
Rice possesses three distinct agro-climatic cultivation systems in India:
- **Aman (Main Kharif)**:
  - *Broad Season*: `Kharif`
  - *Planting System*: `Aman_Lowland`
  - *Supported Regions*: All rice ecologies (Eastern IGP, Peninsular, Western Coastal).
  - *Sowing / Transplanting Window*: Nursery sowing: Jun 15 – Jul 10; Transplanting: Jul 15 – Aug 10.
  - *Evidence*: ICAR-IIRR Tech. Bull. 92/2021.
  - *Thermal & Water Check*: Monsoon dependent ($ET_c \approx 1100\text{–}1350\text{ mm}$); warm humid ($25\text{–}35^\circ\text{C}$).
- **Boro (Winter / Spring Rice)**:
  - *Broad Season*: `Boro_Special` (also matches Rabi winter queries in specific ecologies).
  - *Planting System*: `Boro_Deepwater_Receding`
  - *Supported Regions*: West Bengal, Assam, Bihar, Odisha, Eastern UP.
  - *Sowing / Transplanting Window*: Nursery sowing: Nov 15 – Dec 15; Transplanting: Dec 20 – Jan 20; Harvest: Apr – May.
  - *Evidence*: ICAR-IIRR Tech. Bull. 92/2021; AAU/UBKV Boro Rice Packages. Cold-tolerant varieties (e.g. Gautam, Krishna Hamsa).
  - *Thermal & Water Check*: Requires assured irrigation (canals/shallow tubewells); seedling stage tolerant to low night temperatures ($10\text{–}15^\circ\text{C}$); flowering occurs during rising spring temperatures ($25\text{–}32^\circ\text{C}$).
- **Aus (Autumn / Pre-Monsoon Rice)**:
  - *Broad Season*: `Zaid` / `Pre_Monsoon`
  - *Planting System*: `Aus_Direct_Seeded`
  - *Supported Regions*: Assam, West Bengal, Coastal Odisha.
  - *Sowing Window*: Direct seeding / early transplanting: Mar 15 – Apr 30; Harvest: Jul – Aug.
  - *Evidence*: AAU Package of Practices (2019). Utilizes pre-monsoon Nor'wester showers.

### 4.2 Wheat (*Triticum aestivum*)
Wheat is an obligatory cool-season winter crop sensitive to terminal heat:
- **North-Western Plains Zone (NWPZ: Punjab, Haryana, Western UP, Rajasthan)**:
  - *Timely Sown Window*: Nov 1 – Nov 15 (Optimum tillering and vernalization; 135–145 days duration).
  - *Late Sown Window*: Nov 20 – Dec 15 (Requires late-sown cultivars like PBW-771, DBW-107; duration compressed to 110–120 days; yield potential penalized by 1.5% per day of delay past Nov 20).
  - *Evidence*: ICAR-IIWBR Wheat Production Technologies (2022).
- **Central Zone (CZ: Madhya Pradesh, Chhattisgarh, Gujarat, Southern Rajasthan)**:
  - *Sowing Window*: Oct 25 – Nov 15. Winter is significantly shorter and warmer; later sowing incurs catastrophic terminal heat (>35°C during February–March grain filling).
  - *Evidence*: ICAR-IIWBR Bull. 55 (2022).

### 4.3 Sugarcane (*Saccharum officinarum*)
Sugarcane represents a multi-season, long-duration annual crop ($ET_c = 1200\text{–}2200\text{ mm}$):
- **Adsali Planting System (Tropical Maharashtra, Karnataka)**:
  - *Broad Season*: `Annual_Special` (Adsali Cycle).
  - *Planting Window*: Jul 15 – Aug 31.
  - *Crop Life Cycle*: `Long_Duration_Annual` (15–18 months duration).
  - *Evidence*: Vasantdada Sugar Institute (VSI) Agronomy Manual (2020). Produces 20–30% higher cane tonnage due to extended vegetative growth across two monsoons.
- **Eksali / Autumn Planting (Subtropical UP, Haryana, Bihar)**:
  - *Planting Window*: Oct 1 – Oct 31. Duration: 12–13 months. Sown before winter chill; intercropped with mustard or potato.
  - *Evidence*: ICAR-IISR Tech. Bull. 48/2021.
- **Spring Planting (All India)**:
  - *Planting Window*: Feb 15 – Mar 25. Duration: 10–12 months. Planted after winter harvest.
  - *Evidence*: ICAR-IISR Tech. Bull. 48/2021.

### 4.4 Tomato (*Solanum lycopersicum*)
Tomato is cultivated across multiple specialized seasons:
- *Autumn-Winter Crop*: Sown in nursery Jun–Jul; transplanted Jul–Aug; harvest Nov–Jan. (Major plains crop).
- *Spring-Summer Crop*: Sown in nursery Nov–Dec (protected from frost); transplanted Jan–Feb; harvest Apr–May.
- *Rainy Season Crop (Hills / South India)*: Transplanted May–Jun for off-season supply.
- *Evidence*: ICAR-IIHR Tomato Package of Practices (2020).
- *Thermal Constraint*: Sensitive to night chilling (<10°C reduces pollen viability) and daytime heat (>36°C causes blossom drop).

### 4.5 Banana (*Musa acuminata*)
Banana is a heavy feeder with an 11–14 month crop life cycle:
- *Crop Life Cycle*: `Long_Duration_Annual` / Semi-perennial.
- *Planting Systems*: June–July (Monsoon onset) or September–October (Post-monsoon) under assured drip irrigation.
- *Harvest Cycle*: 10–12 months to shooting; 3 months from shooting to harvest.
- *Evidence*: ICAR-NRCB Banana Production Manual (2021).
- *Thermal Constraint*: Lethal frost/chilling (<8°C causes permanent bunch choke); optimal $25\text{–}32^\circ\text{C}$.

### 4.6 Mango (*Mangifera indica*)
Mango represents an obligatory perennial fruit orchard tree:
- *Crop Life Cycle*: `Perennial_Orchard`.
- *Establishment Phase*: Vegetative graft planting during monsoon (Jul–Aug); requires 4–7 years to reach commercial fruit-bearing capacity.
- *Bearing Phenology*:
  - Vegetative Rest: Oct – Dec (Requires cool, dry weather to induce flower bud differentiation).
  - Floral Induction & Anthesis: Jan – Mar (Requires frost-free, dry conditions; rain causes powdery mildew and blossom drop).
  - Fruit Development & Harvest: Mar – Jul.
- *Evidence*: ICAR-CISH Mango Monograph (2020).
- *Readiness Classification*: `RESTRICTED_ORCHARD_PROVISIONAL`. Cannot be scored on the same seasonal arable ladder as annual wheat or rice.

---

## 5. Comprehensive Input Field Dictionary

| Field Name | Type | Physical Units | Valid Range | Status | Missing-Value Behavior | Current UI Support | UI / API Change Required |
| :--- | :---: | :---: | :---: | :--- | :--- | :---: | :---: |
| `state` | `string (enum)` | ISO-IN State Code | 28 States & 8 UTs | **Required** | Validation Error (Form submission blocked). | Yes | None (Already present). |
| `district` | `string (enum)` | District Name | Valid districts in `state` | **Optional** | Fallback to state-level agro-climatic zone default; warning logged. | No | **Yes (New dropdown required).** |
| `agro_climatic_zone` | `string (enum)` | ICAR / Planning Comm. | 15 National Zones | *Derived* | Automatically derived from `state` and `district`. | No | Backend derivation service. |
| `sowing_month` | `integer` | Calendar Month (1–12) | $1 \le m \le 12$ | **Required** | Validation Error (Must specify intended sowing month). | No | **Yes (New dropdown required).** |
| `sowing_date` | `string (ISO-8601)` | `YYYY-MM-DD` | Valid calendar date | **Optional** | Defaults to 15th of `sowing_month` if omitted. | No | Optional date picker. |
| `cultivation_season` | `string (enum)` | Broad Agro-Season | `Kharif`, `Rabi`, `Zaid`, `Boro_Special`, `Annual_Special`, `Perennial_Orchard` | **Required** | Derived automatically from `sowing_month` and regional calendar if omitted. | No | **Yes (Selector required).** |
| `planting_system` | `string (enum)` | Agronomic System | `Standard`, `Aman`, `Boro`, `Aus`, `Adsali`, `Eksali`, `Timely_Sown`, `Late_Sown`, `Spring`, `Summer` | **Optional** | Resolved automatically to dominant regional system if omitted. | No | Advanced drawer dropdown. |
| `seasonal_rainfall_amount` | `float` | Millimeters (mm) | $0.0 \le R \le 5000.0$ | **Required** | Validation Error if negative or null. | Yes | Renamed to prevent annual conflation. |
| `rainfall_period_type` | `string (enum)` | Temporal Duration | `Crop_Season_Measured`, `Monthly_Average`, `Annual_Normal`, `Unspecified` | **Required** | If not `Crop_Season_Measured`, flags uncertainty; prompts for seasonal data. | No | **Yes (Radio/Dropdown required).** |
| `rainfall_source` | `string (enum)` | Data Provenance | `On_Farm_Rain_Gauge`, `IMD_Station_Gridded`, `Weather_API`, `Farmer_Estimate`, `Unknown` | **Optional** | Defaults to `Farmer_Estimate` with confidence flag. | No | Optional API integration. |
| `irrigation_access` | `string (enum)` | Infrastructure Regime | `None_Rainfed`, `Canal_Gravity`, `Tubewell_Borewell`, `Farm_Pond_Tank`, `Drip_Microirrigation`, `Sprinkler`, `Unknown` | **Required** | Safe Default: `None_Rainfed` with high water scrutiny. | No | **Yes (Mandatory selector).** |
| `irrigation_water_quantity_mm` | `float` | Depth in mm | $0.0 \le I \le 3000.0$ | **Optional** | If omitted, treated as **UNMEASURED** (null). **Zero fixed mm assumed.** | No | **Yes (Numeric input field).** |
| `irrigation_quantity_basis` | `string (enum)` | Volumetric Basis | `Measured_Flow_Meter`, `Estimated_Hours_Pump_Capacity`, `Unknown_Unmeasured` | *Conditional* | Defaults to `Unknown_Unmeasured` when quantity is null. | No | Advanced drawer toggle. |
| `temperature_mean` | `float` | Degrees Celsius (°C) | $-10.0 \le T \le 55.0$ | **Required** | Validation Error if out of bounds or null. | Yes | None (Existing input). |
| `temperature_min_night` | `float` | Degrees Celsius (°C) | $-15.0 \le T_{\min} \le 45.0$ | **Optional** | If omitted, chilling rules flag caution based on seasonal zone normals. | No | Advanced drawer toggle. |
| `temperature_max_day` | `float` | Degrees Celsius (°C) | $0.0 \le T_{\max} \le 55.0$ | **Optional** | If omitted, terminal heat rules flag advisory based on seasonal zone normals. | No | Advanced drawer toggle. |
| `relative_humidity` | `float` | Percentage (%) | $5.0 \le H \le 100.0$ | **Required** | Validation Error if outside $[5, 100]$. | Yes | None (Existing input). |
| `soil_texture` | `string (enum)` | USDA / ICAR Texture | `Clay`, `Clay Loam`, `Loamy`, `Sandy Loam`, `Sandy`, `Black Vertisol`, `Red Sandy`, `Alluvial` | **Required** | Validation Error (Must select compatible soil class). | Yes | Dropdown standardisation. |
| `soil_ph` | `float` | Standard pH scale | $3.0 \le \text{pH} \le 11.0$ | **Required** | Validation Error if $< 3.0$ or $> 11.0$. | Yes | None (Existing input). |
| `has_soil_test` | `boolean` | Flag | `true`, `false` | **Required** | Defaults to `false` if nutrient values are omitted. | No | **Yes (Toggle checkbox).** |
| `soil_nitrogen` | `float` | Defined by `nutrient_basis` | $0.0 \le N \le 1500.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `soil_phosphorus` | `float` | Defined by `nutrient_basis` | $0.0 \le P \le 250.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `soil_potassium` | `float` | Defined by `nutrient_basis` | $0.0 \le K \le 1000.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `nutrient_basis` | `string (enum)` | Analytical Method | `SHC_Available_kg_ha`, `Laboratory_PPM`, `Qualitative_Tier` | *Conditional* | Defaults to `SHC_Available_kg_ha` if numbers entered; otherwise `Qualitative_Tier`. | No | **Yes (Unit selector).** |

---

## 6. Water Availability Contract & Semantics Disambiguation

### 6.1 Removal of Unsupported Fixed Assumptions
The independent review identified critical flaws in previous water models that must never be reintroduced:
- ❌ **NO Flat Partially Irrigated Quantity**: The previous assumption that `Partially_Irrigated_Protective = 120 mm` is completely removed. Canal availability, tubewell yield, and electricity supply vary by hundreds of millimeters across regions.
- ❌ **NO Flat Assured Irrigation Quantity**: The previous assumption that `Assured_Irrigation = 600–1800 mm` is completely removed. Having a borewell does not guarantee water delivered without depth and pump discharge measurements.
- ❌ **NO Fixed Annual-to-Seasonal Fractions**: The previous assumption that seasonal rain is a flat $75\%$ of annual rainfall is completely removed. Rainfall distribution varies drastically from peninsular winter monsoons (Tamil Nadu) to Western Disturbances in the North.
- ❌ **NO Universal Flat Rainfall Exclusions**: Crops like Rice, Wheat, Cotton, Sugarcane, and Banana in irrigated tracts (e.g. Punjab, Haryana, Western UP, Maharashtra) regularly produce record yields in low-rainfall environments because water is supplied via canal or groundwater. Disqualifying them via universal flat rainfall thresholds is agronomic error.
- **DOES NOT calculate effective water availability** ($W_{\text{eff}}$) by inventing fixed numbers when essential volumetric or period data is missing.

### 6.2 Semantic Differentiation: $ET_c$ versus Rainfed Screening Threshold
The catalog values under `min_seasonal_water_mm` have been formally classified into distinct agronomic definitions:
1. **Total Crop Evapotranspiration ($ET_c$)**:
   - Represents the complete physiological water requirement of a disease-free, well-managed crop across its entire growth duration (e.g. Wheat: 250–450 mm; Sugarcane: 1200–2200 mm; Banana: 1400–2200 mm; Potato: 300–500 mm).
   - In winter and summer irrigated tracts (Punjab, Haryana, Western UP, Gujarat, Maharashtra), natural seasonal rainfall is far below $ET_c$ (e.g. Punjab winter rainfall is 40–80 mm, while wheat $ET_c$ is 250–450 mm).
   - **STRICT PROHIBITION**: Natural rainfall must **NEVER** be compared directly against $ET_c$ to disqualify an irrigated crop!
2. **Rainfed Production Screening Threshold**:
   - Represents the absolute minimum cumulative precipitation during the vegetative and reproductive phases below which commercial rainfed cultivation fails due to severe permanent wilting (e.g. Rainfed Rice: 800 mm; Rainfed Cotton in vertisols: 500 mm; Millets/Bajra: 200 mm; Jowar: 350 mm).
   - Applies **ONLY** when `irrigation_access = 'None_Rainfed'`.
   - Used in Tier 2 Liebig geometric scoring or as a soft advisory penalty, **NOT** as an unverified hard exclusion.

### 6.2 Missing Water Data Protocol
- When `irrigation_water_quantity_mm` is omitted by the user:
  - The engine **DOES NOT invent a fixed number** (e.g. no flat 120 mm, no flat 600 mm).
  - If natural rainfall meets the rainfed threshold, the crop passes with verified certainty.
  - If natural rainfall is below requirement, but irrigation infrastructure is present:
    - Water sufficiency status is marked **`UNKNOWN`** or **`INSUFFICIENT_DATA`**.
    - The crop receives a **`PROVISIONAL_EVALUATION`** advisory banner.
    - User is alerted: *"Irrigation access indicated, but delivery volume is unmeasured. Verify local pump/canal capacity."*

---

## 7. JSON API Payload Specification

### 7.1 Request Contract (`POST /api/recommend`)

```json
{
  "location": {
    "state": "PB",
    "district": "Ludhiana",
    "agro_climatic_zone": "Trans-Gangetic Plains"
  },
  "temporal": {
    "sowing_month": 11,
    "sowing_date": "2026-11-10",
    "cultivation_season": "Rabi",
    "planting_system": "Timely_Sown"
  },
  "climate_and_water": {
    "seasonal_rainfall_amount": 45.0,
    "rainfall_period_type": "Crop_Season_Measured",
    "rainfall_source": "IMD_Station_Gridded",
    "irrigation_access": "Tubewell_Borewell",
    "irrigation_water_quantity_mm": 250.0,
    "irrigation_quantity_basis": "Estimated_Hours_Pump_Capacity",
    "temperature_mean": 18.5,
    "temperature_min_night": 9.0,
    "temperature_max_day": 24.5,
    "relative_humidity": 58.0
  },
  "edaphic": {
    "soil_texture": "Loamy",
    "soil_ph": 7.4,
    "has_soil_test": true,
    "nutrient_basis": "SHC_Available_kg_ha",
    "soil_nitrogen": 310.0,
    "soil_phosphorus": 32.0,
    "soil_potassium": 220.0
  }
}
```

### 7.2 Response Contract (`POST /api/recommend`)

```json
{
  "status": "SUCCESS",
  "engine_version": "2.1.0-CLOSURE",
  "execution_timestamp": "2026-11-19T14:45:00Z",
  "query_summary": {
    "location": "Ludhiana, Punjab (Trans-Gangetic Plains)",
    "season": "Rabi",
    "planting_system_evaluated": "Timely_Sown NWPZ (Nov 1-15)",
    "water_regime_evaluated": "Tubewell_Borewell (Estimated 250 mm + Rain 45 mm)",
    "data_completeness_index": 0.95,
    "evidence_confidence_tier": "HIGH_CONFIDENCE"
  },
  "recommendations": [
    {
      "rank": 1,
      "crop_id": "wheat",
      "canonical_name": "Wheat",
      "crop_life_cycle": "Annual_Seasonal",
      "suitability_score": 91.4,
      "recommendation_readiness": "PRODUCTION_READY",
      "tier1_status": "ELIGIBLE",
      "tier2_components": {
        "climate_score": 94.0,
        "water_score": 88.5,
        "soil_score": 100.0,
        "nutrient_score": 92.0,
        "ph_score": 100.0,
        "liebig_penalty_factor": 0.969
      },
      "expected_yield_range_t_ha": [4.2, 5.0],
      "agronomic_advisory": [
        "Optimal timely sowing window Nov 1-15 active in NWPZ.",
        "Ensure crown root initiation (CRI) irrigation at 21 days after sowing."
      ],
      "fertilizer_prescription": {
        "status": "VERIFIED_STCR_GENERATED",
        "rdf_n_p2o5_k2o_kg_ha": [120, 60, 40],
        "adjusted_dose_kg_ha": [120, 60, 40],
        "commercial_products": {
          "dap_kg_ha": 130.4,
          "dap_nitrogen_credit_kg_ha": 23.5,
          "urea_supplementary_kg_ha": 210.0,
          "mop_kg_ha": 66.7
        },
        "stoichiometric_notes": "Urea quantity reflects net nitrogen after deducting 23.5 kg/ha N supplied by DAP."
      }
    }
  ],
  "excluded_candidates": [
    {
      "crop_id": "rice",
      "canonical_name": "Rice (Paddy)",
      "tier1_status": "DISQUALIFIED",
      "failing_rules": [
        {
          "rule_id": "RULE-RICE-SEAS-01",
          "dimension": "planting_system",
          "reason": "Main Aman rice requires warm monsoon Kharif season; winter Rabi conditions in Punjab cause chilling failure."
        }
      ]
    }
  ]
}
```
