# FieldWise — Phase 3C.4: Recommendation Engine Redesign Decision & Technical Report

**Specification Version**: 1.1.0-CONSOLIDATED-CORRECTIONS (Phase 3C.4.1)  
**Phase**: Phase 3C.4 / Phase 3C.4.1 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  
**Governing Authority**: FieldWise ML Pipeline Architecture & Agronomic Validation Team  

---

## 1. Executive Summary & Purpose

Phase 3C.3 identified profound vulnerabilities in FieldWise's legacy recommendation engines (`model/predictor.js` and `src/lib/predictorEngine.ts`):
- **Additive Scoring Failure**: Overriding fatal constraints with unrelated positive scores, resulting in lethal recommendations (winter pulses recommended in 38°C desert summer; wheat recommended in 1200 mm submerged wetland).
- **Omission of Cultivation Season**: Zero checking of sowing season or calendar timing.
- **Water Semantics Distortion**: Compressing seasonal water requirements (350–2500 mm) into 30–300 mm monthly brackets.
- **NPK Measurement Confusion**: Conflating Soil Health Card soil test availability with fertilizer application rates.
- **Architectural Split-Brain**: Disjoint catalogs between online backend (16 crops) and offline frontend (16 crops) with divergent yields (+75% delta) and conflicting fertilizer prescriptions.

**Phase 3C.4 converts these critical audit findings into an implementable technical redesign specification**. Following an independent technical audit of the initial Phase 3C.4 draft, **Phase 3C.4.1 consolidates all mandatory safety and agronomic corrections**:
1. Decoupling the water model and eliminating unsupported flat assumptions (no flat 120 mm, no flat 600 mm, no flat 75% monsoon fraction).
2. Individually reviewing all 100 eligibility rules, strictly restricting statuses to `HARD_EXCLUSION`, `SOFT_PENALTY`, `WARNING_ONLY`, `UNKNOWN`, `NOT_APPLICABLE`, removing flowering heat from sowing gates, and eliminating universal rainfall exclusions on irrigated crops.
3. Overhauling fertilizer safety: eliminating blanket $+25\% / -25\%$ multipliers, decoupling 4 distinct nutrient concepts, enforcing the deduction of Nitrogen supplied by DAP, and restricting commercial bag prescriptions to verified regional STCR equations.
4. Implementing region-aware planting windows (timely vs late NW plains, Aus/Aman/Boro, Adsali).
5. Establishing explicit recommendation readiness tiers in the 19-crop catalogue and standardizing the taxonomy of Millets (Pearl Millet / Bajra) vs Jowar (Sorghum).
6. Formalizing scoring behavior for UNKNOWN eligibility, missing components, score non-comparability, and the deterministic boundary between `NO_RECOMMENDATION_SUITABLE` and `INSUFFICIENT_DATA`.
7. Correcting all 15 acceptance tests to eliminate unverified assumptions.
8. Establishing 100% portable path resolution in generators and validators.

In strict compliance with governance rules, **zero application code was modified**. All artifacts represent technical specifications, data contracts, rule matrices, and test suites prepared for independent review before Phase 3C.5 implementation.

---

## 2. Summary of Redesign Specification Deliverables

| Deliverable Path | Document Title | Primary Contribution |
| :--- | :--- | :--- |
| `reports/phase_3c_4_input_contract.md` | Canonical Input Contract Specification | Structured contract for location, region-aware planting windows, decoupled water fields, and soil test units. |
| `reports/phase_3c_4_eligibility_rules.csv` | Agronomic Eligibility Rules Matrix | 100 evidence-backed Boolean gating rules individually reviewed across 7 biological dimensions for all 19 crops. |
| `reports/phase_3c_4_scoring_architecture.md` | Scoring Architecture Specification | Two-Tier Hybrid Architecture (Boolean Gating $\to$ Liebig Geometric Ranking), non-comparability rules, and DCI. |
| `reports/phase_3c_4_canonical_crop_catalogue.csv` | Canonical 19-Crop Master Catalogue | Single Source of Truth (SSOT) defining all 19 crops with explicit recommendation-readiness and evidence tiers. |
| `reports/phase_3c_4_fertilizer_safety_spec.md` | Fertilizer & Soil-Nutrient Safety Spec | Decouples soil test from RDF, eliminates blanket multipliers, enforces DAP nitrogen credits, and limits bag advice. |
| `reports/phase_3c_4_fallback_and_uncertainty_spec.md` | Fallback & Uncertainty Handling Spec | Establishes 100% dual-engine parity, unmeasured water policies, and `NO_RECOMMENDATION` vs `INSUFFICIENT_DATA`. |
| `reports/phase_3c_4_acceptance_test_matrix.csv` | Mandatory Acceptance Test Matrix | 15 deterministic test cases (including regression of Scenarios S1–S5) with corrected agronomic expectations. |
| `reports/phase_3c_4_source_evidence_gaps.csv` | Source Evidence & Gaps Registry | Catalogs 10 major evidence gaps, citing ICAR, SAU, Govt, and FAO benchmarks with resolved status. |
| `reports/phase_3c_4_metrics.json` | Redesign Specification Metrics | Machine-readable inventory of all rules, contract fields, catalogue entries, and test definitions. |
| `scripts/generate_phase_3c_4_artifacts.py` | Specification Generator Engine | Portable Python builder generating all CSV specification matrices dynamically. |
| `scripts/validate_phase_3c_4_spec.py` | Specification Validation Engine | Portable Python validation script verifying contract integrity and test assertions. |
| `data/processed/recommendation/phase_3c_4_README.md` | Documentation & Checksum Manifest | Directory overview, reproduction instructions, and SHA-256 verification manifest. |

---

## 3. Detailed Engineering Decisions & Corrections (Phase 3C.4.1)

### 3.1 Water Availability Model Overhaul
- **Elimination of Fixed Values**:
  - Removed `Partially_Irrigated = 120 mm` and `Assured_Irrigation = 600–1800 mm`.
  - Removed flat $75\%$ annual-to-seasonal rainfall fraction.
  - Removed flat rainfall exclusion thresholds on crops with access to irrigation infrastructure.
- **Decoupled Architecture**:
  - `seasonal_rainfall_amount`: Measured or estimated precipitation across the actual crop duration.
  - `irrigation_access`: Infrastructure regime (`Canal_Gravity`, `Tubewell_Borewell`, `Farm_Pond_Tank`, `Drip_Microirrigation`, `None_Rainfed`, `Unknown`).
  - `irrigation_water_quantity_mm`: Actual volumetric delivery depth only when measured or calibrated.
- **Unmeasured Water Protocol**:
  - If natural rainfall is insufficient and irrigation access exists but delivery volume is unmeasured, the engine DOES NOT invent water quantities; it evaluates water sufficiency as **`UNKNOWN`** and marks the crop as **`CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK`**.

### 3.2 Eligibility Rules Matrix Overhaul (100 Rules Reviewed Individually)
- **Strict Status Vocabulary**:
  - Every rule is strictly classified into one of: `HARD_EXCLUSION`, `SOFT_PENALTY`, `WARNING_ONLY`, `UNKNOWN`, `NOT_APPLICABLE`.
  - Current distribution: 61 `HARD_EXCLUSION`, 26 `SOFT_PENALTY`, 8 `WARNING_ONLY`, 4 `UNKNOWN`, 1 `NOT_APPLICABLE`.
- **Elimination of Growth-Stage Conflation**:
  - High flowering temperatures (Rice floret sterility >38°C, Maize tassel drying >40°C, Chickpea flowering heat >32°C, Lentil heat >28°C, Mustard seed filling >28°C) are classified as `WARNING_ONLY` or `SOFT_PENALTY` scoped to reproductive stages, NEVER as sowing-stage exclusions.
- **Evidence Differentiation**:
  - Differentiated true Class A physiological survival limits (ICAR/FAO primary research) from Class B secondary package of practices, Class C unmeasured regimes, and Class D empirical extensions.

### 3.3 Fertilizer Safety & Stoichiometry Overhaul
- **Elimination of Blanket Multipliers**:
  - Removed the uncalibrated rule: Low = 125% RDF, Medium = 100%, High = 75%.
- **Separation of Four Concepts**:
  - (1) Soil-test available nutrients, (2) Crop physiological nutrient requirement, (3) Recommended Dose of Fertilizers (RDF), (4) Actual commercial fertilizer product quantity.
- **Mandatory DAP Nitrogen Credit**:
  - Di-Ammonium Phosphate contains 18% N and 46% $P_2O_5$. The nitrogen supplied by DAP ($N_{\text{from\_DAP}} = \text{DAP applied} \times 0.18$) must be deducted from the nitrogen target before computing supplementary Urea:
    $$\text{Urea required (kg/ha)} = \frac{\max\left(0, \text{Target } N - (\text{DAP applied} \times 0.18)\right)}{0.46}$$
- **Stoichiometric Conversion Factors**:
  - $P = P_2O_5 \times 0.4364 \iff P_2O_5 = P \times 2.2915$
  - $K = K_2O \times 0.8302 \iff K_2O = K \times 1.2046$
- **Restriction on Commercial Bag Prescriptions**:
  - Commercial bag quantities are only generated when supported by verified regional STCR target yield equations. Where missing, output is restricted to advisory-only guidance.

### 3.4 Canonical Catalogue & Recommendation Readiness
- **Readiness Classification**:
  - `PRODUCTION_READY` (9 crops): Rice, Wheat, Maize, Cotton, Soybean, Groundnut, Potato, Chickpea, Mustard.
  - `CONDITIONALLY_RECOMMENDABLE` (9 crops): Sugarcane, Lentil, Tomato, Onion, Banana, Jowar, Sunflower, Barley, Millets.
  - `RESTRICTED_ORCHARD_PROVISIONAL` (1 crop): Mango (perennial orchard tree requiring 4-7 year establishment; cannot be recommended as an annual rotational crop by a single-season scoring engine).
- **Millets vs Jowar Taxonomic Resolution**:
  - `jowar`: Confirmed monospecific as Sorghum (*Sorghum bicolor*).
  - `millets`: Standardized specifically to Pearl Millet / Bajra (*Pennisetum glaucum*). Other minor millets (Ragi, Foxtail, Kodo) are explicitly excluded from this profile.

### 3.5 Scoring Architecture Clarifications
- **UNKNOWN Gating**: Disqualifies candidate from `HIGH_CONFIDENCE`; logs explicit parameter uncertainty.
- **Missing Data Handling**: Neutral baseline (70.0) applied to missing components, but decrements Data Completeness Index ($DCI$).
- **Score Non-Comparability**: Scores with different missing inputs are NOT directly comparable and must not be sorted on a single naive score ladder.
- **Confidence Segregation**: Suitability Index (0–100) is displayed alongside an independent Evidence Confidence Tier.
- **Rejection Distinction**:
  - `NO_RECOMMENDATION_SUITABLE`: Complete valid data provided; hostile agricultural conditions disqualify all crops.
  - `INSUFFICIENT_DATA`: Critical mandatory inputs missing; biological viability cannot be evaluated.
- **Prohibition of Probability Claims**: Heuristic suitability scores must NEVER be described as calibrated probabilities.

---

## 4. Phase 3C.5 Implementation Sequence

Upon formal approval of the Phase 3C.4.1 specification, implementation in Phase 3C.5 will proceed in four isolated steps:
1. **Step 1: Single Source of Truth Asset**: Export `canonical_crop_catalogue.json` containing all 19 crops, region-aware planting windows, readiness flags, and 100 eligibility rules.
2. **Step 2: Backend Engine Migration**: Replace `model/predictor.js` scoring logic with Tier 1 Gating and Tier 2 Liebig geometric scoring importing the SSOT asset.
3. **Step 3: Frontend Fallback Migration**: Update `src/lib/predictorEngine.ts` to mirror the exact backend implementation using the shared SSOT asset.
4. **Step 4: Acceptance Test Suite Execution**: Execute the 15 acceptance tests against both backend and frontend engines to assert 100% parity and zero defects.
