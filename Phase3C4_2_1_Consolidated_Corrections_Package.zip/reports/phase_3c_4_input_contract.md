# FieldWise — Phase 3C.4: Canonical Input Contract Specification

**Specification Version**: 1.3.0-FINAL-CORRECTIONS (Phase 3C.4.2.1)  
**Phase**: Phase 3C.4 / Phase 3C.4.2.1 (Consolidated Final Corrections)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Overview & Objective

Phase 3C.3 proved that FieldWise's existing recommendation input interface suffered from critical semantic ambiguities:
1. Conflating annual rainfall, seasonal rainfall, and monthly rainfall into an uncalibrated scalar.
2. Silently interpreting Recommended Dose of Fertilizers (RDF) as soil test nutrient targets.
3. Completely omitting cultivation season, intended sowing date, and regional planting windows.
4. Conflating qualitative irrigation infrastructure access with guaranteed volumetric water delivery.
5. Assuming all farmers have laboratory soil tests, with zero defined missing-data behavior.
6. Forcing diverse planting systems (Boro rice, Adsali sugarcane, Spring maize) into rigid broad season buckets (Kharif, Rabi, Zaid).

This document establishes the **Canonical Input Contract** for FieldWise, updated to Phase 3C.4.2 to resolve all season/planting window incompatibilities and decouple water availability accounting. It formally specifies every location, climate, temporal, edaphic, and water input required to make an agronomically defensible crop recommendation.

---

## 2. Decoupled Season & Planting-Window Data Model

### 2.1 The Architectural Disconnect in Broad Seasons
Prior iterations categorized cultivation exclusively into three broad seasons: `Kharif`, `Rabi`, and `Zaid` (plus a vague `Annual` bucket). This created direct agronomic contradictions:
- **Boro Rice**: Sown in nursery beds in November–December, transplanted into puddled fields in December–January, and harvested in April–May in West Bengal, Assam, and Bihar. Classifying Boro as `Kharif` fails because Kharif begins in June; classifying it as `Rabi` fails standard rice thermal checks; classifying it as `Zaid` fails because Zaid begins in March.
- **Adsali Sugarcane**: Planted in July–August in Maharashtra and Karnataka and grown for 15–18 months. Classifying it as an annual crop conflates it with 10–12 month `Eksali` or Spring canes.
- **Tomato & Vegetable Crops**: Cultivated across three overlapping overlapping cycles (Autumn-Winter, Spring-Summer, Rainy season) depending on altitude, pest pressures, and frost risks.
- **Perennial Fruit Trees (Mango, Banana)**: Mango is a permanent orchard tree taking 4–7 years to first commercial bearing with phenological cycles (flowering in Feb–Mar, fruiting in May–Jul), while Banana is a 11–13 month giant herbaceous crop planted year-round under assured irrigation.

### 2.2 Formal Six-Field Temporal & Cultivation Data Model
To resolve this without breaking simple interfaces, the temporal contract is factored into six distinct architectural dimensions:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                    TEMPORAL & CULTIVATION CONTRACT DIMENSIONS                   │
├─────────────────────────────────────────────────┬───────────────────────────────┤
│ 1. broad_season (Enum)                          │ Kharif, Rabi, Zaid,           │
│                                                 │ Boro_Special, Annual_Special, │
│                                                 │ Perennial_Orchard             │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 2. planting_system (String / Enum)              │ Aman, Boro, Aus, Timely_Sown, │
│                                                 │ Late_Sown, Adsali, Eksali,    │
│                                                 │ Spring, Summer, Main_Crop,    │
│                                                 │ Standard_Orchard              │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 3. region_or_agro_climatic_zone (Location)      │ State, District,              │
│                                                 │ ICAR Agro-Climatic Zone       │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 4. sowing_date_or_month_range (Date/Range)      │ sowing_month (1-12),          │
│                                                 │ sowing_date (YYYY-MM-DD),     │
│                                                 │ window_range (e.g. Nov 1-15)  │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 5. crop_life_cycle (Enum)                       │ Annual_Seasonal,              │
│                                                 │ Long_Duration_Annual,         │
│                                                 │ Perennial_Orchard             │
├─────────────────────────────────────────────────┼───────────────────────────────┤
│ 6. window_evidence_status (Enum)                │ VERIFIED, PROVISIONAL,        │
│                                                 │ UNKNOWN                       │
└─────────────────────────────────────────────────┴───────────────────────────────┘
```

### 2.3 Life Cycle Categories
Every candidate crop belongs to exactly one life cycle category:
1. **`Annual_Seasonal`** (e.g. Wheat, Rice, Maize, Mustard, Chickpea, Lentil, Soybean, Cotton, Groundnut, Potato, Barley, Millets, Jowar, Sunflower, Onion, Tomato):
   - Single distinct season cycle (90 to 180 days).
   - Evaluated strictly against sowing-stage temperature, seasonal rainfall/irrigation, and designated regional planting window.
2. **`Long_Duration_Annual`** (e.g. Sugarcane):
   - Spans 10 to 18 months, crossing multiple meteorological seasons.
   - Evaluated against initial establishment conditions and multi-season cumulative water availability.
3. **`Perennial_Orchard`** (e.g. Mango, Banana):
   - Permanent or multi-year cultivation requiring multi-year land commitment.
   - Mango requires distinct evaluation: vegetative planting vs reproductive floral induction.
   - Banana requires 11–13 month frost-free warm humid conditions with high water continuity.

---

## 3. Resolution Matrix: User Input Scenarios

The engine deterministically resolves temporal eligibility depending on what inputs the user supplies:

| User Input Combination | Engine Resolution Logic | Resulting Window Status | Advisory / Uncertainty Behavior |
| :--- | :--- | :---: | :--- |
| **1. Season Only** (e.g. "Rabi") | 1. Maps `broad_season` to default regional planting system for each crop in user's state/zone.<br>2. Adopts midpoint calendar month of that season (e.g. Rabi $\to$ November). | `PROVISIONAL` | Prompts user to confirm specific sowing month. Flags: *"Cultivated window assumed as mid-season normal; specify exact sowing date for precision germination checks."* |
| **2. Sowing Date Only** (e.g. "Nov 10") | 1. Extracts calendar month ($m = 11$).<br>2. Automatically derives `broad_season` from state agricultural calendar (Nov in Punjab $\to$ `Rabi`; Nov in Assam $\to$ `Boro_Special` or `Rabi`).<br>3. Matches date against verified regional windows. | `VERIFIED` | Evaluates precise timely vs late sowing window boundaries. |
| **3. Both Season and Sowing Date** | 1. Cross-validates compatibility between season and date.<br>2. If compatible: executes full regional window matching.<br>3. If conflicting (e.g. "Kharif" with "December 15"): halts with validation error prompting correction. | `VERIFIED` | Highest precision evaluation. |
| **4. Unknown Planting Window** (Crop not established in region) | 1. Crop lacks verified package of practices for the specified zone/district.<br>2. Does not invent speculative window.<br>3. Evaluates generic physiological thermal limits. | `PROVISIONAL` | Marks recommendation badge as `PROVISIONAL`. Displays advisory: *"No locally verified ICAR/SAU planting window for this crop in your district; feasibility evaluated on general thermal bounds."* |
| **5. Region with No Verified Planting Window** (Unsupported State/District) | 1. System falls back to macro-climatic agro-zone default.<br>2. If macro-zone unknown: marks window as `UNKNOWN`.<br>3. Decrements Data Completeness Index ($DCI \le 0.70$). | `UNKNOWN` | Capped at `PROVISIONAL_EVALUATION` confidence tier. |

---

## 4. Worked Crop-Specific Examples

### 4.1 Rice (*Oryza sativa*)
Rice possesses three distinct agro-climatic cultivation systems in India:
- **Aman (Main Kharif)**:
  - *Broad Season*: `Kharif`
  - *Planting System*: `Aman_Lowland`
  - *Supported Regions*: All rice ecologies (Eastern IGP, Peninsular, Western Coastal).
  - *Sowing / Transplanting Window*: Nursery sowing: Jun 15 – Jul 10; Transplanting: Jul 15 – Aug 10.
  - *Evidence*: ICAR-IIRR Tech. Bull. 92/2021.
  - *Thermal & Water Check*: Monsoon dependent ($ET_c \approx 1100\text{–}1350\text{ mm}$); warm humid ($25\text{–}35^\circ\text{C}$).
- **Boro (Winter / Spring Rice)**:
  - *Broad Season*: `Boro_Special` (also matches Rabi winter queries in specific ecologies).
  - *Planting System*: `Boro_Deepwater_Receding`
  - *Supported Regions*: West Bengal, Assam, Bihar, Odisha, Eastern UP.
  - *Sowing / Transplanting Window*: Nursery sowing: Nov 15 – Dec 15; Transplanting: Dec 20 – Jan 20; Harvest: Apr – May.
  - *Evidence*: ICAR-IIRR Tech. Bull. 92/2021; AAU/UBKV Boro Rice Packages. Cold-tolerant varieties (e.g. Gautam, Krishna Hamsa).
  - *Thermal & Water Check*: Requires assured irrigation (canals/shallow tubewells); seedling stage tolerant to low night temperatures ($10\text{–}15^\circ\text{C}$); flowering occurs during rising spring temperatures ($25\text{–}32^\circ\text{C}$).
- **Aus (Autumn / Pre-Monsoon Rice)**:
  - *Broad Season*: `Zaid` / `Pre_Monsoon`
  - *Planting System*: `Aus_Direct_Seeded`
  - *Supported Regions*: Assam, West Bengal, Coastal Odisha.
  - *Sowing Window*: Direct seeding / early transplanting: Mar 15 – Apr 30; Harvest: Jul – Aug.
  - *Evidence*: AAU Package of Practices (2019). Utilizes pre-monsoon Nor'wester showers.

### 4.2 Wheat (*Triticum aestivum*)
Wheat is an obligatory cool-season winter crop sensitive to terminal heat:
- **North-Western Plains Zone (NWPZ: Punjab, Haryana, Western UP, Rajasthan)**:
  - *Timely Sown Window*: Nov 1 – Nov 15 (Optimum tillering and vernalization; 135–145 days duration).
  - *Late Sown Window*: Nov 20 – Dec 15 (Requires late-sown cultivars like PBW-771, DBW-107; duration compressed to 110–120 days; yield potential penalized by 1.5% per day of delay past Nov 20).
  - *Evidence*: ICAR-IIWBR Wheat Production Technologies (2022).
- **Central Zone (CZ: Madhya Pradesh, Chhattisgarh, Gujarat, Southern Rajasthan)**:
  - *Sowing Window*: Oct 25 – Nov 15. Winter is significantly shorter and warmer; later sowing incurs catastrophic terminal heat (>35°C during February–March grain filling).
  - *Evidence*: ICAR-IIWBR Bull. 55 (2022).

### 4.3 Sugarcane (*Saccharum officinarum*)
Sugarcane represents a multi-season, long-duration annual crop ($ET_c = 1200\text{–}2200\text{ mm}$):
- **Adsali Planting System (Tropical Maharashtra, Karnataka)**:
  - *Broad Season*: `Annual_Special` (Adsali Cycle).
  - *Planting Window*: Jul 15 – Aug 31.
  - *Crop Life Cycle*: `Long_Duration_Annual` (15–18 months duration).
  - *Evidence*: Vasantdada Sugar Institute (VSI) Agronomy Manual (2020). Produces 20–30% higher cane tonnage due to extended vegetative growth across two monsoons.
- **Eksali / Autumn Planting (Subtropical UP, Haryana, Bihar)**:
  - *Planting Window*: Oct 1 – Oct 31. Duration: 12–13 months. Sown before winter chill; intercropped with mustard or potato.
  - *Evidence*: ICAR-IISR Tech. Bull. 48/2021.
- **Spring Planting (All India)**:
  - *Planting Window*: Feb 15 – Mar 25. Duration: 10–12 months. Planted after winter harvest.
  - *Evidence*: ICAR-IISR Tech. Bull. 48/2021.

### 4.4 Tomato (*Solanum lycopersicum*)
Tomato is cultivated across multiple specialized seasons:
- *Autumn-Winter Crop*: Sown in nursery Jun–Jul; transplanted Jul–Aug; harvest Nov–Jan. (Major plains crop).
- *Spring-Summer Crop*: Sown in nursery Nov–Dec (protected from frost); transplanted Jan–Feb; harvest Apr–May.
- *Rainy Season Crop (Hills / South India)*: Transplanted May–Jun for off-season supply.
- *Evidence*: ICAR-IIHR Tomato Package of Practices (2020).
- *Thermal Constraint*: Sensitive to night chilling (<10°C reduces pollen viability) and daytime heat (>36°C causes blossom drop).

### 4.5 Banana (*Musa acuminata*)
Banana is a heavy feeder with an 11–14 month crop life cycle:
- *Crop Life Cycle*: `Long_Duration_Annual` / Semi-perennial.
- *Planting Systems*: June–July (Monsoon onset) or September–October (Post-monsoon) under assured drip irrigation.
- *Harvest Cycle*: 10–12 months to shooting; 3 months from shooting to harvest.
- *Evidence*: ICAR-NRCB Banana Production Manual (2021).
- *Thermal Constraint*: Lethal frost/chilling (<8°C causes permanent bunch choke); optimal $25\text{–}32^\circ\text{C}$.

### 4.6 Mango (*Mangifera indica*)
Mango represents an obligatory perennial fruit orchard tree:
- *Crop Life Cycle*: `Perennial_Orchard`.
- *Establishment Phase*: Vegetative graft planting during monsoon (Jul–Aug); requires 4–7 years to reach commercial fruit-bearing capacity.
- *Bearing Phenology*:
  - Vegetative Rest: Oct – Dec (Requires cool, dry weather to induce flower bud differentiation).
  - Floral Induction & Anthesis: Jan – Mar (Requires frost-free, dry conditions; rain causes powdery mildew and blossom drop).
  - Fruit Development & Harvest: Mar – Jul.
- *Evidence*: ICAR-CISH Mango Monograph (2020).
- *Readiness Classification*: `RESTRICTED_ORCHARD_PROVISIONAL`. Cannot be scored on the same seasonal arable ladder as annual wheat or rice.

---

## 5. Comprehensive Input Field Dictionary

| Field Name | Type | Physical Units | Valid Range | Status | Missing-Value Behavior | Current UI Support | UI / API Change Required |
| :--- | :---: | :---: | :---: | :--- | :--- | :---: | :---: |
| `state` | `string (enum)` | ISO-IN State Code | 28 States & 8 UTs | **Required** | Validation Error (Form submission blocked). | Yes | None (Already present). |
| `district` | `string (enum)` | District Name | Valid districts in `state` | **Optional** | Fallback to state-level agro-climatic zone default; warning logged. | No | **Yes (New dropdown required).** |
| `agro_climatic_zone` | `string (enum)` | ICAR / Planning Comm. | 15 National Zones | *Derived* | Automatically derived from `state` and `district`. | No | Backend derivation service. |
| `sowing_month` | `integer` | Calendar Month (1–12) | $1 \le m \le 12$ | **Required** | Validation Error (Must specify intended sowing month). | No | **Yes (New dropdown required).** |
| `sowing_date` | `string (ISO-8601)` | `YYYY-MM-DD` | Valid calendar date | **Optional** | Defaults to 15th of `sowing_month` if omitted. | No | Optional date picker. |
| `cultivation_season` | `string (enum)` | Broad Agro-Season | `Kharif`, `Rabi`, `Zaid`, `Boro_Special`, `Annual_Special`, `Perennial_Orchard` | **Required** | Derived automatically from `sowing_month` and regional calendar if omitted. | No | **Yes (Selector required).** |
| `planting_system` | `string (enum)` | Agronomic System | `Standard`, `Aman`, `Boro`, `Aus`, `Adsali`, `Eksali`, `Timely_Sown`, `Late_Sown`, `Spring`, `Summer` | **Optional** | Resolved automatically to dominant regional system if omitted. | No | Advanced drawer dropdown. |
| `seasonal_rainfall_amount` | `float` | Millimeters (mm) | $0.0 \le R \le 5000.0$ | **Required** | Validation Error if negative or null. | Yes | Renamed to prevent annual conflation. |
| `rainfall_period_type` | `string (enum)` | Temporal Duration | `Crop_Season_Measured`, `Monthly_Average`, `Annual_Normal`, `Unspecified` | **Required** | If not `Crop_Season_Measured`, flags uncertainty; prompts for seasonal data. | No | **Yes (Radio/Dropdown required).** |
| `rainfall_source` | `string (enum)` | Data Provenance | `On_Farm_Rain_Gauge`, `IMD_Station_Gridded`, `Weather_API`, `Farmer_Estimate`, `Unknown` | **Optional** | Defaults to `Farmer_Estimate` with confidence flag. | No | Optional API integration. |
| `irrigation_access` | `string (enum)` | Infrastructure Regime | `None_Rainfed`, `Canal_Gravity`, `Tubewell_Borewell`, `Farm_Pond_Tank`, `Drip_Microirrigation`, `Sprinkler`, `Unknown` | **Required** | Safe Default: `None_Rainfed` with high water scrutiny. | No | **Yes (Mandatory selector).** |
| `irrigation_water_quantity_mm` | `float` | Depth in mm | $0.0 \le I \le 3000.0$ | **Optional** | If omitted, treated as **UNMEASURED** (null). **Zero fixed mm assumed.** | No | **Yes (Numeric input field).** |
| `irrigation_quantity_basis` | `string (enum)` | Volumetric Basis | `Measured_Flow_Meter`, `Estimated_Hours_Pump_Capacity`, `Unknown_Unmeasured` | *Conditional* | Defaults to `Unknown_Unmeasured` when quantity is null. | No | Advanced drawer toggle. |
| `temperature_mean` | `float` | Degrees Celsius (°C) | $-10.0 \le T \le 55.0$ | **Required** | Validation Error if out of bounds or null. | Yes | None (Existing input). |
| `temperature_min_night` | `float` | Degrees Celsius (°C) | $-15.0 \le T_{\min} \le 45.0$ | **Optional** | If omitted, chilling rules flag caution based on seasonal zone normals. | No | Advanced drawer toggle. |
| `temperature_max_day` | `float` | Degrees Celsius (°C) | $0.0 \le T_{\max} \le 55.0$ | **Optional** | If omitted, terminal heat rules flag advisory based on seasonal zone normals. | No | Advanced drawer toggle. |
| `relative_humidity` | `float` | Percentage (%) | $5.0 \le H \le 100.0$ | **Required** | Validation Error if outside $[5, 100]$. | Yes | None (Existing input). |
| `soil_texture` | `string (enum)` | USDA / ICAR Texture | `Clay`, `Clay Loam`, `Loamy`, `Sandy Loam`, `Sandy`, `Black Vertisol`, `Red Sandy`, `Alluvial` | **Required** | Validation Error (Must select compatible soil class). | Yes | Dropdown standardisation. |
| `soil_ph` | `float` | Standard pH scale | $3.0 \le \text{pH} \le 11.0$ | **Required** | Validation Error if $< 3.0$ or $> 11.0$. | Yes | None (Existing input). |
| `has_soil_test` | `boolean` | Flag | `true`, `false` | **Required** | Defaults to `false` if nutrient values are omitted. | No | **Yes (Toggle checkbox).** |
| `soil_nitrogen` | `float` | Defined by `nutrient_basis` | $0.0 \le N \le 1500.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `soil_phosphorus` | `float` | Defined by `nutrient_basis` | $0.0 \le P \le 250.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `soil_potassium` | `float` | Defined by `nutrient_basis` | $0.0 \le K \le 1000.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `nutrient_basis` | `string (enum)` | Analytical Method | `SHC_Available_kg_ha`, `Laboratory_PPM`, `Qualitative_Tier` | *Conditional* | Defaults to `SHC_Available_kg_ha` if numbers entered; otherwise `Qualitative_Tier`. | No | **Yes (Unit selector).** |

---

## 6. Water Availability Contract & Semantics Disambiguation

### 6.1 Removal of Unsupported Fixed Assumptions
The independent review identified critical flaws in previous water models that must never be reintroduced:
- ❌ **NO Flat Partially Irrigated Quantity**: The previous assumption that `Partially_Irrigated_Protective = 120 mm` is completely removed. Canal availability, tubewell yield, and electricity supply vary by hundreds of millimeters across regions.
- ❌ **NO Flat Assured Irrigation Quantity**: The previous assumption that `Assured_Irrigation = 600–1800 mm` is completely removed. Having a borewell does not guarantee water delivered without depth and pump discharge measurements.
- ❌ **NO Fixed Annual-to-Seasonal Fractions**: The previous assumption that seasonal rain is a flat $75\%$ of annual rainfall is completely removed. Rainfall distribution varies drastically from peninsular winter monsoons (Tamil Nadu) to Western Disturbances in the North.
- ❌ **NO Universal Flat Rainfall Exclusions**: Crops like Rice, Wheat, Cotton, Sugarcane, and Banana in irrigated tracts (e.g. Punjab, Haryana, Western UP, Maharashtra) regularly produce record yields in low-rainfall environments because water is supplied via canal or groundwater. Disqualifying them via universal flat rainfall thresholds is agronomic error.
- ❌ **NO Invented Effective Rainfall**: Effective rainfall must not be synthesized via blanket percentage multipliers (e.g. flat $75\%$ or $80\%$). If unmeasured, it remains explicitly unmeasured.

### 6.2 Formal Definitions of the Six Decoupled Water Concepts
To prevent semantic conflation across agronomic literature, hydrologic modelling, and user input interfaces, the redesign defines six decoupled water concepts:

1. **Total Crop Evapotranspiration ($ET_c$) [mm/season]**:
   - Represents the complete physiological, consumptive water requirement of a disease-free, well-fertilized crop growing under non-limiting soil water conditions across its entire growth cycle.
   - Formula: $ET_c = K_c \times ET_0$, where $ET_0$ is FAO Penman-Monteith reference evapotranspiration and $K_c$ is the crop coefficient across initial, development, mid-season, and late-season stages.
   - Units: Cumulative millimeters of water depth per cultivation season ($\text{mm/season}$).
   - **Governing Rule**: $ET_c$ measures consumptive demand, NOT rainfall supply. Under irrigated conditions, seasonal rainfall is frequently a fraction of $ET_c$ (e.g. Punjab wheat $ET_c = 250–350\text{ mm}$ while winter rain is $40–80\text{ mm}$). Natural seasonal rainfall must **NEVER** be compared directly against $ET_c$ to disqualify an irrigated crop.

2. **Effective Rainfall ($P_{\text{eff}}$) [mm/season]**:
   - Represents the portion of cumulative seasonal precipitation ($P_{\text{gross}}$) that infiltrates and is stored in the active crop root zone available for transpiration, excluding surface runoff, deep percolation below rooting depth, and direct canopy interception evaporation.
   - Units: Cumulative millimeters per cultivation season ($\text{mm/season}$).
   - **Governing Rule**: Effective rainfall depends on soil infiltration rate, profile water holding capacity, slope, and rainfall intensity. When daily hydrologic balance data is absent, the engine **DOES NOT invent an arbitrary percentage** (e.g. no flat 70% or 80%). The variable is categorized as `UNMEASURED_EFFECTIVE_RAIN`.

3. **Net Irrigation Requirement ($NIR$) [mm/season]**:
   - The depth of water required exclusively at the root zone to satisfy crop evapotranspiration without moisture stress, after crediting effective rainfall and usable antecedent soil moisture.
   - Formula: $NIR = \max\big(0,\; ET_c - P_{\text{eff}} - \Delta S\big)$, where $\Delta S$ is root-zone soil water storage depletion available at planting.
   - Units: Net millimeters per season ($\text{mm/season}$).

4. **Gross Irrigation Applied ($GIR$) [mm/season]**:
   - The total depth of water withdrawn from the source (canal turnout, tubewell discharge, farm pond) and applied to the field surface, accounting for application and conveyance losses.
   - Formula: $GIR = \frac{NIR}{\eta_{\text{appl}}}$, where $\eta_{\text{appl}} \in (0, 1.0]$ is the irrigation application efficiency:
     - Surface / Border / Basin flood irrigation: $\eta_{\text{appl}} \approx 0.45 - 0.60$ (ICAR-CSSRI benchmark).
     - Furrow / Surge irrigation: $\eta_{\text{appl}} \approx 0.65 - 0.75$.
     - Pressurized Drip micro-irrigation: $\eta_{\text{appl}} \approx 0.85 - 0.92$.
   - Units: Gross millimeters per season ($\text{mm/season}$) or cubic meters per hectare ($1\text{ mm} = 10\text{ m}^3/\text{ha}$).

5. **Measured Irrigation Quantity ($I_{\text{meas}}$) & Measurement Period**:
   - Direct volumetric water delivery reported by the user, verified by flow meter, canal rotational allocation (warabandi hours $\times$ discharge), or tubewell operating hours $\times$ rated discharge ($Q$).
   - Units: Cumulative millimeters ($\text{mm}$) applied over the defined crop growth period (e.g. "320 mm applied across 4 irrigations between sowing and dough stage").

6. **Water Availability or Irrigation Access Without Measured Quantity**:
   - Qualitative presence of irrigation infrastructure (e.g. `Canal_Gravity`, `Tubewell_Borewell`, `Farm_Pond_Tank`, `Drip_Microirrigation`) without measured volumetric depth ($I_{\text{quantity\_mm}} = \text{null}$).
   - **Governing Rule**: Irrigation access indicates the operational capacity to apply water, but does NOT certify water sufficiency. The engine returns an **`UNKNOWN`** water sufficiency outcome and assigns recommendation status **`CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK`**. It **NEVER** assumes 100% water delivery or auto-passes the water gate.

### 6.3 Mandatory Integrity Rules for Water Accounting
1. **Never Mix Net and Gross Irrigation**:
   - Net crop demand ($NIR$) and gross application ($GIR$) must never be added together or directly equated without dividing by application efficiency $\eta_{\text{appl}}$.
2. **Never Add Raw Rainfall Directly to Gross Irrigation Without Unit Calibration**:
   - Total available water at root zone is $W_{\text{root}} = P_{\text{eff}} + (GIR \times \eta_{\text{appl}})$, NOT $P_{\text{gross}} + GIR$.
3. **Rainfed Screening Threshold is NOT an Automatic Hard Exclusion**:
   - Rainfed production screening thresholds in the catalogue (e.g. 800 mm for Rice, 500 mm for Cotton, 350 mm for Jowar) reflect economic risk boundaries under un-irrigated dryland conditions.
   - Violating a rainfed screening threshold under rainfed management incurs a Tier 2 Liebig geometric penalty (`SOFT_PENALTY`) or an advisory risk warning, NOT a fatal Tier 1 biological disqualification.
4. **Treatment of Unmeasured Irrigation**:
   - When irrigation access is indicated but `irrigation_water_quantity_mm` is omitted:
     - The engine DOES NOT invent a fixed default (no flat 120 mm, no flat 600 mm).
     - If natural seasonal rainfall alone satisfies the rainfed screening threshold, the crop passes with verified certainty.
     - If natural rainfall is below requirement, the water gate returns **`UNKNOWN`**.
     - The crop is marked **`CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK`**, requiring farmer verification of local pump yield.

### 6.4 Worked Water Calculation Examples

#### Worked Example A: Rainfed Rice (*Oryza sativa*) in Chhattisgarh Plain
- **Farmer Profile**:
  - Location: Raipur, Chhattisgarh.
  - Sowing Date: June 25 (Kharif monsoon).
  - Measured Seasonal Rainfall: $P_{\text{measured}} = 1150\text{ mm}$ (monsoon rainfall June–October, rain gauge).
  - Irrigation Infrastructure: `irrigation_access = 'None_Rainfed'`.
  - Irrigation Quantity: $I_{\text{quantity\_mm}} = 0\text{ mm}$.
- **Evaluation Logic**:
  - Production System: Purely Rainfed.
  - Rice Rainfed Production Screening Threshold $= 800\text{ mm}$ (ICAR-NRRI Cuttack benchmark).
  - Comparison: $P_{\text{measured}} (1150\text{ mm}) \ge \text{Threshold} (800\text{ mm})$.
  - Tier 1 Outcome: **`PASS_VERIFIED`**.
  - Tier 2 Water Score: $s_{\text{water}} = 100 \times \min\Big(1.0,\; \frac{1150}{1200}\Big) = 95.8\text{ points}$.
  - Final Status: **`ELIGIBLE_RAINFED`** with high water security.

#### Worked Example B: Irrigated Wheat (*Triticum aestivum*) in Ludhiana, Punjab
- **Farmer Profile**:
  - Location: Ludhiana, Punjab (Trans-Gangetic Plain).
  - Sowing Date: November 10 (Rabi timely sown).
  - Measured Seasonal Rainfall: $P_{\text{measured}} = 65\text{ mm}$ (Western Disturbances, Nov–March).
  - Irrigation Infrastructure: `irrigation_access = 'Tubewell_Borewell'`.
  - Measured Gross Irrigation: $GIR = 320\text{ mm}$ (4 irrigations $\times$ 80 mm border flood).
  - Irrigation Application Efficiency: Surface border flood $\eta_{\text{appl}} = 0.70$.
- **Evaluation Logic**:
  - Wheat Total Crop Evapotranspiration: $ET_c = 250 - 350\text{ mm}$ (ICAR-IIWBR Karnal).
  - *Naive Legacy Engine Failure*: Comparing raw winter rainfall (65 mm) directly to $ET_c$ (250 mm) would falsely disqualify wheat from Punjab, India's premier wheat bowl!
  - *Decoupled Water Accounting*:
    - Net irrigation delivered to root zone: $NIR_{\text{delivered}} = GIR \times \eta_{\text{appl}} = 320\text{ mm} \times 0.70 = 224\text{ mm}$.
    - Estimated effective rainfall from gentle Western Disturbances: $P_{\text{eff}} \approx 50\text{ mm}$.
    - Total root zone water available: $W_{\text{root}} = 224\text{ mm} + 50\text{ mm} = 274\text{ mm} \ge ET_{c,\min} (250\text{ mm})$.
  - Tier 1 Outcome: **`PASS_VERIFIED`**.
  - Tier 2 Water Score: $s_{\text{water}} = 100.0\text{ points}$.
  - Final Status: **`ELIGIBLE_IRRIGATED`** with verified water adequacy.

#### Worked Example C: Crop with Unknown Irrigation Quantity (Rabi Maize in Samastipur, Bihar)
- **Farmer Profile**:
  - Location: Samastipur, Bihar.
  - Sowing Date: November 15 (Rabi season).
  - Measured Seasonal Rainfall: $P_{\text{measured}} = 35\text{ mm}$.
  - Irrigation Infrastructure: `irrigation_access = 'Tubewell_Borewell'`.
  - Irrigation Quantity: $I_{\text{quantity\_mm}} = \text{null}$ (unmeasured tubewell depth).
- **Evaluation Logic**:
  - Maize Total Crop Evapotranspiration: $ET_c = 400 - 500\text{ mm}$ (ICAR-IIMR Ludhiana).
  - Maize Rainfed Screening Threshold: $450\text{ mm}$.
  - Analysis:
    - Rainfall ($35\text{ mm}$) is far below rainfed threshold ($450\text{ mm}$); crop cannot survive as rainfed.
    - Borewell infrastructure exists, but actual pumped volume is unmeasured.
    - The engine **DOES NOT assume sufficiency** and **DOES NOT invent flat numbers**.
  - Tier 1 Water Gate: Returns **`UNKNOWN`** (insufficient volumetric data).
  - Recommendation Status: **`CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK`**.
  - UI Advisory Banner: *"Tubewell access reported, but seasonal water application volume is unmeasured. Rabi maize requires 4–5 timely irrigations totaling ~350 mm net water. Confirm borewell discharge and electricity availability before planting."*
  - DCI Impact: Water domain completeness receives partial score ($c_3 = 0.40$), preventing misleading high-confidence recommendations.

---

## 7. Data Completeness Index ($DCI$) Formal Specification

### 7.1 Decoupled 6-Domain Formulation
The independent review established that DCI must track input measurement completeness across all operational data dimensions, preventing unearned confidence badges while avoiding double-counting:

$$DCI = \sum_{k=1}^{6} w_k \cdot c_k \quad \in [0.00, 1.00]$$

Where the 6 orthogonal domains and their verified weights are:
$$\begin{aligned}
w_{\text{temporal}} &= 0.15 \quad &\text{(Sowing date, month, and regional planting window)} \\
w_{\text{climate}} &= 0.20 \quad &\text{(Mean temperature and relative humidity)} \\
w_{\text{water}} &= 0.25 \quad &\text{(Seasonal rainfall and volumetric irrigation applied)} \\
w_{\text{soil}} &= 0.15 \quad &\text{(Soil texture class and drainage characteristics)} \\
w_{\text{ph}} &= 0.10 \quad &\text{(Soil reaction / potentiometric pH)} \\
w_{\text{nutrients}} &= 0.15 \quad &\text{(Available N, P, K from Soil Health Card)}
\end{aligned}$$

$$\sum_{k=1}^{6} w_k = 0.15 + 0.20 + 0.25 + 0.15 + 0.10 + 0.15 = 1.000$$

### 7.2 Domain Measurement Scoring Criteria ($c_k$)

1. **Temporal & Planting Window Completeness ($c_1 \in [0, 1]$)**:
   - $c_1 = 1.00$: Exact sowing date (`YYYY-MM-DD`) or calendar week provided and matched to a verified ICAR regional planting window.
   - $c_1 = 0.60$: Only broad cultivation season (`Kharif`, `Rabi`, `Zaid`) provided without exact sowing date; window matched provisionally.
   - $c_1 = 0.00$: Sowing date and season completely omitted.

2. **Climate Specification Completeness ($c_2 \in [0, 1]$)**:
   - $c_2 = 1.00$: Both mean temperature (°C) and relative humidity (%) measured from on-farm sensor, local AWS, or IMD gridded reanalysis.
   - $c_2 = 0.50$: Only temperature is measured; relative humidity is estimated from historical regional normals (or vice versa).
   - $c_2 = 0.00$: Temperature and humidity both omitted.

3. **Water Supply Measurement Completeness ($c_3 \in [0, 1]$)**:
   - *For Rainfed Systems (`irrigation_access = 'None_Rainfed'`)*:
     - $c_3 = 1.00$: Seasonal rainfall measured via local rain gauge or IMD station.
     - $c_3 = 0.50$: Seasonal rainfall estimated from district annual historical normals.
     - $c_3 = 0.00$: Rainfall data missing.
   - *For Irrigated Systems (`irrigation_access != 'None_Rainfed'`)*:
     - $c_3 = 1.00$: Both seasonal rainfall and volumetric irrigation applied ($GIR$ in mm, measured via flow meter or calibrated pump hours $\times$ discharge) are provided.
     - $c_3 = 0.40$: Seasonal rainfall is measured and irrigation access is confirmed (`Tubewell_Borewell`, `Canal_Gravity`), but volumetric irrigation depth is unmeasured ($I_{\text{quantity\_mm}} = \text{null}$).
     - $c_3 = 0.00$: Rainfall and irrigation access both omitted.

4. **Soil Physical / Texture Completeness ($c_4 \in [0, 1]$)**:
   - $c_4 = 1.00$: Soil texture class determined via laboratory mechanical analysis or ICAR-NBSS&LUP verified soil survey.
   - $c_4 = 0.50$: Soil texture class estimated from farmer feel method or district general soil map.
   - $c_4 = 0.00$: Soil texture omitted.

5. **Soil Chemical Reaction / pH Completeness ($c_5 \in [0, 1]$)**:
   - $c_5 = 1.00$: Soil pH measured via laboratory potentiometric 1:2.5 soil:water suspension.
   - $c_5 = 0.00$: Soil pH omitted.

6. **Soil Available Macronutrients Completeness ($c_6 \in [0, 1]$)**:
   - $c_6 = 1.00$: Quantitative available Nitrogen, Phosphorus, Potassium measured from an official Soil Health Card (SHC) within 3 years.
   - $c_6 = 0.50$: Partial nutrient test (e.g. only N and P tested) or qualitative fertility rating (`Low`, `Medium`, `High`) provided.
   - $c_6 = 0.00$: Soil Health Card data completely omitted (engine applies neutral default $s_{\text{nutrients}} = 70.0$).

### 7.3 Prevention of Double-Counting
Missing information affects either the parameter completeness domain or the scoring domain, never both:
- Missing exact planting date penalizes ONLY $c_1$ ($1.00 \to 0.60$), not climate or water.
- Unmeasured irrigation volume penalizes ONLY $c_3$ ($1.00 \to 0.40$), resulting in an `UNKNOWN` water gate outcome without subtracting points from soil or nutrients.
- Missing Soil Health Card penalizes ONLY $c_6$ ($1.00 \to 0.00$) while setting $s_{\text{nutrients}} = 70.0$, ensuring transparent traceability.

### 7.4 Four Reproducible Worked Benchmark Calculations

| Scenario | Description | $c_1$ | $c_2$ | $c_3$ | $c_4$ | $c_5$ | $c_6$ | Recalculated $DCI$ | Confidence Tier Assigned |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **Benchmark 1** | **Gold Standard Full Profile**: Lab SHC, metered tubewell irrigation, verified sowing date Nov 10, local AWS weather. | $1.00$ | $1.00$ | $1.00$ | $1.00$ | $1.00$ | $1.00$ | **$1.000$** | `HIGH_CONFIDENCE` |
| **Benchmark 2** | **Commercial Irrigated Wheat, Missing SHC**: Sowing date Nov 15 verified, metered irrigation, lab pH & texture, but no SHC NPK. | $1.00$ | $1.00$ | $1.00$ | $1.00$ | $1.00$ | $0.00$ | **$0.850$** | `HIGH_CONFIDENCE_ESTIMATED_FERTILITY` |
| **Benchmark 3** | **Typical Smallholder Profile**: Broad Kharif season only (no exact date), tubewell present but unmeasured volume, no SHC. | $0.60$ | $1.00$ | $0.40$ | $1.00$ | $1.00$ | $0.00$ | **$0.640$** | `PROVISIONAL_EVALUATION` |
| **Benchmark 4** | **Rainfed Dryland Farmer**: Verified sowing date July 5, local rain gauge, no irrigation needed, regional soil survey texture, no SHC. | $1.00$ | $1.00$ | $1.00$ | $0.50$ | $1.00$ | $0.00$ | **$0.775$** | `MODERATE_ESTIMATED` |

**Arithmetic Verification for Benchmark 3**:
$$\begin{aligned}
DCI &= 0.15(0.60) + 0.20(1.00) + 0.25(0.40) + 0.15(1.00) + 0.10(1.00) + 0.15(0.00) \\
&= 0.090 + 0.200 + 0.100 + 0.150 + 0.100 + 0.000 = \mathbf{0.640}
\end{aligned}$$
*(If pH is also estimated from regional soil atlas, $c_5 = 0.50 \implies DCI = 0.640 - 0.050 = \mathbf{0.590}$)*.

### 7.5 Strict Rejection Boundary
- If $DCI < 0.500$, the engine halts and raises **`INSUFFICIENT_DATA`**. Recommendation generation is refused because more than 50% of the decision weight would rely on unverified assumptions.

---

## 8. JSON API Payload Specification

### 8.1 Request Contract (`POST /api/recommend`)

```json
{
  "location": {
    "state": "PB",
    "district": "Ludhiana",
    "agro_climatic_zone": "Trans-Gangetic Plains"
  },
  "temporal": {
    "sowing_month": 11,
    "sowing_date": "2026-11-10",
    "cultivation_season": "Rabi",
    "planting_system": "Timely_Sown"
  },
  "climate_and_water": {
    "seasonal_rainfall_amount": 45.0,
    "rainfall_period_type": "Crop_Season_Measured",
    "rainfall_source": "IMD_Station_Gridded",
    "irrigation_access": "Tubewell_Borewell",
    "irrigation_water_quantity_mm": 250.0,
    "irrigation_quantity_basis": "Estimated_Hours_Pump_Capacity",
    "temperature_mean": 18.5,
    "temperature_min_night": 9.0,
    "temperature_max_day": 24.5,
    "relative_humidity": 58.0
  },
  "edaphic": {
    "soil_texture": "Loamy",
    "soil_ph": 7.4,
    "has_soil_test": true,
    "nutrient_basis": "SHC_Available_kg_ha",
    "soil_nitrogen": 310.0,
    "soil_phosphorus": 32.0,
    "soil_potassium": 220.0
  }
}
```

### 7.2 Response Contract (`POST /api/recommend`)

```json
{
  "status": "SUCCESS",
  "engine_version": "2.1.0-CLOSURE",
  "execution_timestamp": "2026-11-19T14:45:00Z",
  "query_summary": {
    "location": "Ludhiana, Punjab (Trans-Gangetic Plains)",
    "season": "Rabi",
    "planting_system_evaluated": "Timely_Sown NWPZ (Nov 1-15)",
    "water_regime_evaluated": "Tubewell_Borewell (Estimated 250 mm + Rain 45 mm)",
    "data_completeness_index": 0.95,
    "evidence_confidence_tier": "HIGH_CONFIDENCE"
  },
  "recommendations": [
    {
      "rank": 1,
      "crop_id": "wheat",
      "canonical_name": "Wheat",
      "crop_life_cycle": "Annual_Seasonal",
      "suitability_score": 91.4,
      "recommendation_readiness": "PRODUCTION_READY",
      "tier1_status": "ELIGIBLE",
      "tier2_components": {
        "climate_score": 94.0,
        "water_score": 88.5,
        "soil_score": 100.0,
        "nutrient_score": 92.0,
        "ph_score": 100.0,
        "liebig_penalty_factor": 0.969
      },
      "expected_yield_range_t_ha": [4.2, 5.0],
      "agronomic_advisory": [
        "Optimal timely sowing window Nov 1-15 active in NWPZ.",
        "Ensure crown root initiation (CRI) irrigation at 21 days after sowing."
      ],
      "fertilizer_prescription": {
        "status": "VERIFIED_STCR_GENERATED",
        "rdf_n_p2o5_k2o_kg_ha": [120, 60, 40],
        "adjusted_dose_kg_ha": [120, 60, 40],
        "commercial_products": {
          "dap_kg_ha": 130.4,
          "dap_nitrogen_credit_kg_ha": 23.5,
          "urea_supplementary_kg_ha": 210.0,
          "mop_kg_ha": 66.7
        },
        "stoichiometric_notes": "Urea quantity reflects net nitrogen after deducting 23.5 kg/ha N supplied by DAP."
      }
    }
  ],
  "excluded_candidates": [
    {
      "crop_id": "rice",
      "canonical_name": "Rice (Paddy)",
      "tier1_status": "DISQUALIFIED",
      "failing_rules": [
        {
          "rule_id": "RULE-RICE-SEAS-01",
          "dimension": "planting_system",
          "reason": "Main Aman rice requires warm monsoon Kharif season; winter Rabi conditions in Punjab cause chilling failure."
        }
      ]
    }
  ]
}
```
