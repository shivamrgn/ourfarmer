# FieldWise — Phase 3C.4: Canonical Input Contract Specification

**Specification Version**: 1.1.0-CONSOLIDATED-CORRECTIONS (Phase 3C.4.1)  
**Phase**: Phase 3C.4 / Phase 3C.4.1 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Overview & Objective

Phase 3C.3 proved that FieldWise's existing recommendation input interface suffered from severe semantic ambiguities:
1. Conflating annual rainfall, seasonal rainfall, and monthly rainfall into an uncalibrated scalar.
2. Silently interpreting Recommended Dose of Fertilizers (RDF) as soil test nutrient targets.
3. Completely omitting cultivation season, intended sowing date, and regional planting windows.
4. Conflating qualitative irrigation infrastructure access with guaranteed volumetric water delivery.
5. Assuming all farmers have laboratory soil tests, with zero defined missing-data behavior.

This document establishes the **Canonical Input Contract** for FieldWise, updated to incorporate all mandatory corrections from the independent Phase 3C.4 review. It formally specifies every location, climate, temporal, edaphic, and water input required to make an agronomically defensible crop recommendation without resorting to unsupported fixed multipliers or fabricated assumptions.

---

## 2. Input Dimension Architecture

The input schema is organized into four decoupled domains:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       CANONICAL INPUT CONTRACT DOMAINS                       │
├───────────────────────────────┬─────────────────────────────────────────────┤
│ 1. Location & Administration  │ State, District, Agro-Climatic Zone         │
├───────────────────────────────┼─────────────────────────────────────────────┤
│ 2. Temporal & Planting Window │ Intended Sowing Month, Region-Aware Window, │
│                               │ Cultivation Season (Kharif, Rabi, Zaid)     │
├───────────────────────────────┼─────────────────────────────────────────────┤
│ 3. Water & Climate (Decoupled)│ Measured/Estimated Seasonal Rain (mm),      │
│                               │ Rain Duration & Source, Irrigation Access,  │
│                               │ Measured Irrigation Quantity (if known),    │
│                               │ Temperature (Mean/Min/Max), Humidity        │
├───────────────────────────────┼─────────────────────────────────────────────┤
│ 4. Edaphic & Soil Nutrients   │ Texture Class, pH, Soil Test Flag, N, P, K   │
│                               │ Available Basis, Decoupled from Crop RDF    │
└───────────────────────────────┴─────────────────────────────────────────────┘
```

---

## 3. Comprehensive Input Field Dictionary

| Field Name | Type | Physical Units | Valid Range | Status | Missing-Value Behavior | Current UI Support | UI / API Change Required |
| :--- | :---: | :---: | :---: | :---: | :--- | :---: | :---: |
| `state` | `string (enum)` | ISO-IN State Code | 28 States & 8 UTs | **Required** | Validation Error (Form submission blocked). | Yes | None (Already present). |
| `district` | `string (enum)` | District Name | Valid districts in `state` | **Optional** | Fallback to state-level agro-climatic zone default; warning logged. | No | **Yes (New dropdown required).** |
| `agro_climatic_zone` | `string (enum)` | ICAR / Planning Comm. | 15 National Zones | *Derived* | Automatically derived from `state` and `district`. | No | Backend derivation service. |
| `sowing_month` | `integer` | Calendar Month (1–12) | $1 \le m \le 12$ | **Required** | Validation Error (Must specify intended sowing month). | No | **Yes (New dropdown required).** |
| `sowing_date` | `string (ISO-8601)` | `YYYY-MM-DD` | Valid calendar date | **Optional** | Defaults to 15th of `sowing_month` if omitted. | No | Optional date picker. |
| `cultivation_season` | `string (enum)` | Indian Agro-Season | `Kharif`, `Rabi`, `Zaid`, `Annual` | **Required** | Derived automatically from `sowing_month` if omitted, with user confirmation. | No | **Yes (Selector required).** |
| `seasonal_rainfall_amount` | `float` | Millimeters (mm) | $0.0 \le R \le 5000.0$ | **Required** | Validation Error if negative or null. | Yes | Renamed to prevent annual conflation. |
| `rainfall_period_type` | `string (enum)` | Temporal Duration | `Crop_Season_Measured`, `Monthly_Average`, `Annual_Normal`, `Unspecified` | **Required** | If not `Crop_Season_Measured`, flags uncertainty; prompts for seasonal data. | No | **Yes (Radio/Dropdown required).** |
| `rainfall_source` | `string (enum)` | Data Provenance | `On_Farm_Rain_Gauge`, `IMD_Station_Gridded`, `Weather_API`, `Farmer_Estimate`, `Unknown` | **Optional** | Defaults to `Farmer_Estimate` with confidence flag. | No | Optional API integration. |
| `irrigation_access` | `string (enum)` | Infrastructure Regime | `None_Rainfed`, `Canal_Gravity`, `Tubewell_Borewell`, `Farm_Pond_Tank`, `Drip_Microirrigation`, `Sprinkler`, `Unknown` | **Required** | Safe Default: `None_Rainfed` with high water scrutiny. | No | **Yes (Mandatory selector).** |
| `irrigation_water_quantity_mm` | `float` | Depth in mm | $0.0 \le I \le 3000.0$ | **Optional** | If omitted, treated as **UNMEASURED** (null). **Zero fixed mm assumed.** | No | **Yes (Numeric input field).** |
| `irrigation_quantity_basis` | `string (enum)` | Volumetric Basis | `Measured_Flow_Meter`, `Estimated_Hours_Pump_Capacity`, `Unknown_Unmeasured` | *Conditional* | Defaults to `Unknown_Unmeasured` when quantity is null. | No | Advanced drawer toggle. |
| `temperature_mean` | `float` | Degrees Celsius (°C) | $-10.0 \le T \le 55.0$ | **Required** | Validation Error if out of bounds or null. | Yes | None (Existing input). |
| `temperature_min_night` | `float` | Degrees Celsius (°C) | $-15.0 \le T_{\min} \le 45.0$ | **Optional** | If omitted, chilling rules flag caution based on seasonal zone normals. | No | Advanced drawer toggle. |
| `temperature_max_day` | `float` | Degrees Celsius (°C) | $0.0 \le T_{\max} \le 55.0$ | **Optional** | If omitted, terminal heat rules flag advisory based on seasonal zone normals. | No | Advanced drawer toggle. |
| `relative_humidity` | `float` | Percentage (%) | $5.0 \le H \le 100.0$ | **Required** | Validation Error if outside $[5, 100]$. | Yes | None (Existing input). |
| `soil_texture` | `string (enum)` | USDA / ICAR Texture | `Clay`, `Clay Loam`, `Loamy`, `Sandy Loam`, `Sandy`, `Black Vertisol`, `Red Sandy`, `Alluvial` | **Required** | Validation Error (Must select compatible soil class). | Yes | Dropdown standardisation. |
| `soil_ph` | `float` | Standard pH scale | $3.0 \le \text{pH} \le 11.0$ | **Required** | Validation Error if $< 3.0$ or $> 11.0$. | Yes | None (Existing input). |
| `has_soil_test` | `boolean` | Flag | `true`, `false` | **Required** | Defaults to `false` if nutrient values are omitted. | No | **Yes (Toggle checkbox).** |
| `soil_nitrogen` | `float` | Defined by `nutrient_basis` | $0.0 \le N \le 1500.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `soil_phosphorus` | `float` | Defined by `nutrient_basis` | $0.0 \le P \le 250.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `soil_potassium` | `float` | Defined by `nutrient_basis` | $0.0 \le K \le 1000.0$ | *Conditional* | If `has_soil_test=false`: defaults to neutral rating ($s_{\text{nutrients}} = 70.0$, $DCI$ reduced). | Yes | Decoupled from Crop RDF. |
| `nutrient_basis` | `string (enum)` | Analytical Method | `SHC_Available_kg_ha`, `Laboratory_PPM`, `Qualitative_Tier` | *Conditional* | Defaults to `SHC_Available_kg_ha` if numbers entered; otherwise `Qualitative_Tier`. | No | **Yes (Unit selector).** |

---

## 4. Rigorous Water Availability Model (Phase 3C.4.1 Correction)

### 4.1 Removal of Unsupported Fixed Assumptions
The independent review of Phase 3C.4 identified critical flaws in previous water models that must never be reintroduced:
- ❌ **NO Flat Partially Irrigated Quantity**: The previous assumption that `Partially_Irrigated_Protective = 120 mm` is completely removed. Canal availability, tubewell yield, and electricity supply vary by hundreds of millimeters across regions.
- ❌ **NO Flat Assured Irrigation Quantity**: The previous assumption that `Assured_Irrigation = 600–1800 mm` is completely removed. Having a borewell does not guarantee water delivered without depth and pump discharge measurements.
- ❌ **NO Fixed Annual-to-Seasonal Fractions**: The previous assumption that seasonal rain is a flat $75\%$ of annual rainfall is completely removed. Rainfall distribution varies drastically from peninsular winter monsoons (Tamil Nadu) to Western Disturbances in the North.
- ❌ **NO Universal Flat Rainfall Exclusions**: Crops like Rice, Wheat, Cotton, Sugarcane, and Banana in irrigated tracts (e.g. Punjab, Haryana, Western UP, Maharashtra) regularly produce record yields in low-rainfall environments because water is supplied via canal or groundwater. Disqualifying them via universal flat rainfall thresholds is agronomic error.

### 4.2 Decoupled Water Accounting Framework
The engine strictly decouples **Natural Rainfall**, **Irrigation Access Regime**, and **Measured Irrigation Volume**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ 1. Natural Seasonal Rainfall (R_seasonal)                                   │
│    - Measured or localized estimated precipitation across the crop cycle.   │
├─────────────────────────────────────────────────────────────────────────────┤
│ 2. Qualitative Irrigation Access Regime                                     │
│    - Physical access to water source: Canal, Tubewell, Tank, Drip, None.    │
│    - Does NOT imply guaranteed volumetric delivery.                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ 3. Actual Volumetric Delivery (I_quantity_mm)                               │
│    - Measured depth (mm) or volume (m³/ha) ONLY when explicitly known.      │
│    - If farmer does not know: recorded as UNKNOWN / UNMEASURED.             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.3 Missing Water Data Handling Protocol
When evaluating crop water adequacy:
1. **Measured Water Available**:
   If both $R_{\text{seasonal}}$ and $I_{\text{quantity\_mm}}$ are measured:
   $$W_{\text{total}} = R_{\text{seasonal}} + I_{\text{quantity\_mm}}$$
   Water adequacy is evaluated against the crop's verified consumptive requirement range ($ET_c$).
2. **Rainfed Regime (`irrigation_access = 'None_Rainfed'`)**:
   $$W_{\text{total}} = R_{\text{seasonal}}$$
   Water adequacy is evaluated strictly against rainfed moisture stress thresholds.
3. **Irrigation Access Available but Quantity Unmeasured (`irrigation_water_quantity_mm = null`)**:
   - The engine **DOES NOT calculate effective water availability** ($W_{\text{eff}}$) by inventing a number.
   - If natural rainfall is sufficient on its own ($R_{\text{seasonal}} \ge c.\text{min\_seasonal\_water}$), the crop passes the water gate with high certainty.
   - If natural rainfall is below rainfed requirement, but the farmer has confirmed irrigation infrastructure:
     - The water sufficiency status is set to **`UNKNOWN`** or **`INSUFFICIENT_DATA`**.
     - The crop is marked **`CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK`**.
     - The UI displays an explicit notice:
       > ⚠️ **Unmeasured Irrigation Advisory**: Natural rainfall ($R_{\text{seasonal}}\text{ mm}$) is below rainfed requirement for this crop. While irrigation access is indicated, delivered volume is unmeasured. Verify local canal/borewell discharge before planting.

---

## 5. Region-Aware Cultivation Windows (Phase 3C.4.1 Correction)

Single universal crop season assumptions are replaced with region-aware planting windows backed by ICAR and State Agricultural University (SAU) packages of practices:

```
┌─────────────────┬──────────────────────────┬─────────────────────────────┬──────────────────────────┐
│ Crop ID         │ Agro-Climatic Zone / State│ Planting Window             │ Evidence & Phenology     │
├─────────────────┼──────────────────────────┼─────────────────────────────┼──────────────────────────┤
│ wheat           │ North-Western Plains     │ Timely: Nov 1 – Nov 15      │ ICAR-IIWBR: Optimum      │
│                 │ (Punjab, Haryana, W-UP)  │ Late: Nov 20 – Dec 10       │ vernalization & tillering│
├─────────────────┼──────────────────────────┼─────────────────────────────┼──────────────────────────┤
│ wheat           │ Central Zone (MP, CG)    │ Oct 25 – Nov 15             │ Shorter winter; early    │
│                 │                          │                             │ terminal heat avoidance  │
├─────────────────┼──────────────────────────┼─────────────────────────────┼──────────────────────────┤
│ rice            │ Eastern IGP / Peninsular │ Kharif (Aman): Jun 15–Jul 15│ Monsoon transplanting    │
│                 │                          │ Boro (Winter): Nov – Dec    │ Cold-tolerant seedling   │
│                 │                          │ Aus (Autumn): Apr – May     │ Pre-monsoon sowing       │
├─────────────────┼──────────────────────────┼─────────────────────────────┼──────────────────────────┤
│ maize           │ Northern Plains (Spring) │ Jan 20 – Feb 15             │ ICAR-IIMR: High yield    │
│                 │ Central / Peninsular     │ Kharif: Jun 15 – Jul 15     │ Monsoon rainfed/irrigated│
│                 │ Bihar (Rabi Maize)       │ Oct 15 – Nov 15             │ High winter radiation    │
├─────────────────┼──────────────────────────┼─────────────────────────────┼──────────────────────────┤
│ groundnut       │ Saurashtra / Gujarat     │ Kharif: Jun 15 – Jul 15     │ Monsoon rainfed onset    │
│                 │ Gujarat / Andhra / TN    │ Summer (Zaid): Jan 15–Feb 15│ Assured irrigated pegging│
├─────────────────┼──────────────────────────┼─────────────────────────────┼──────────────────────────┤
│ potato           │ Indo-Gangetic Plains     │ Early: Oct 1 – Oct 15       │ High market price        │
│                 │                          │ Main: Oct 15 – Nov 5        │ ICAR-CPRI Optimum bulking│
├─────────────────┼──────────────────────────┼─────────────────────────────┼──────────────────────────┤
│ sugarcane       │ Subtropical (UP, Bihar)  │ Autumn: Oct; Spring: Feb-Mar│ 10–12 month duration     │
│                 │ Tropical (Maharashtra)   │ Adsali: Jul – Aug           │ 15–18 month duration     │
├─────────────────┼──────────────────────────┼─────────────────────────────┼──────────────────────────┤
│ mango           │ Subtropical / Tropical   │ Graft Planting: Jul–Aug     │ Multi-year establishment │
│                 │ (Orchard Perennial)      │ Panicle Emergence: Feb–Mar  │ 4–7 years to bearing     │
└─────────────────┴──────────────────────────┴─────────────────────────────┴──────────────────────────┘
```

*Rule on Regional Missing Data*: If a user enters a region where credible agronomic research has not established a validated planting window for that crop, the window status is marked **`UNKNOWN`** rather than inventing a speculative window.

---

## 6. Soil Nutrient Testing vs. Qualitative Assessment (Decoupled from RDF)

To permanently eliminate the semantic conflation between soil fertility measurements and fertilizer prescriptions:
- **Path A: Laboratory Soil Health Card Input (`has_soil_test = true`)**:
  - Farmer provides laboratory-measured Available N ($\text{KMnO}_4$), Available P (Olsen $P_2O_5$), and Available K ($\text{NH}_4\text{OAc}$).
  - Evaluated against standard Ministry of Agriculture & Farmers Welfare (DAC&FW 2015) fertility limits:
    - Available N: Low ($< 280\text{ kg/ha}$), Medium ($280–560\text{ kg/ha}$), High ($> 560\text{ kg/ha}$).
    - Available $P_2O_5$: Low ($< 23\text{ kg/ha}$), Medium ($23–56\text{ kg/ha}$), High ($> 56\text{ kg/ha}$).
    - Available $K_2O$: Low ($< 140\text{ kg/ha}$), Medium ($140–330\text{ kg/ha}$), High ($> 330\text{ kg/ha}$).
- **Path B: Qualitative Farmer Assessment (`has_soil_test = false`)**:
  - Farmer toggles soil test off.
  - The engine assigns neutral medium nutrient scores ($s_{\text{nutrients}} = 70.0$) and tracks a separate **Data Completeness Index (DCI)**.
  - Commercial fertilizer bag quantities are **NOT generated automatically**; general state extension advisory packages are displayed with a notice to conduct a formal soil test.

---

## 7. JSON API Payload Specification

### 7.1 Request Contract (`POST /api/recommend`)

```json
{
  "location": {
    "state": "PB",
    "district": "Ludhiana",
    "agro_climatic_zone": "Trans-Gangetic Plains"
  },
  "temporal": {
    "sowing_month": 11,
    "sowing_date": "2026-11-10",
    "cultivation_season": "Rabi"
  },
  "climate_and_water": {
    "seasonal_rainfall_amount": 45.0,
    "rainfall_period_type": "Crop_Season_Measured",
    "rainfall_source": "IMD_Station_Gridded",
    "irrigation_access": "Tubewell_Borewell",
    "irrigation_water_quantity_mm": 250.0,
    "irrigation_quantity_basis": "Estimated_Hours_Pump_Capacity",
    "temperature_mean": 18.5,
    "temperature_min_night": 9.0,
    "temperature_max_day": 24.5,
    "relative_humidity": 58.0
  },
  "edaphic": {
    "soil_texture": "Loamy",
    "soil_ph": 7.4,
    "has_soil_test": true,
    "nutrient_basis": "SHC_Available_kg_ha",
    "soil_nitrogen": 310.0,
    "soil_phosphorus": 32.0,
    "soil_potassium": 220.0
  }
}
```

### 7.2 Response Contract (`POST /api/recommend`)

```json
{
  "status": "SUCCESS",
  "engine_version": "2.0.0-PROPOSED",
  "execution_timestamp": "2026-11-19T14:15:00Z",
  "query_summary": {
    "location": "Ludhiana, Punjab (Trans-Gangetic Plains)",
    "season": "Rabi",
    "planting_window_evaluated": "Timely NWPZ: Nov 1-15",
    "water_regime_evaluated": "Tubewell_Borewell (Estimated 250 mm + Rain 45 mm)",
    "data_completeness_index": 0.95,
    "evidence_confidence_tier": "HIGH_CONFIDENCE"
  },
  "recommendations": [
    {
      "rank": 1,
      "crop_id": "wheat",
      "canonical_name": "Wheat",
      "suitability_score": 91.4,
      "recommendation_readiness": "PRODUCTION_READY",
      "tier1_status": "ELIGIBLE",
      "tier2_components": {
        "climate_score": 94.0,
        "water_score": 88.5,
        "soil_score": 100.0,
        "nutrient_score": 92.0,
        "ph_score": 100.0,
        "liebig_penalty_factor": 0.969
      },
      "expected_yield_range_t_ha": [4.2, 5.0],
      "agronomic_advisory": [
        "Optimal timely sowing window Nov 1-15 active in NWPZ.",
        "Ensure crown root initiation (CRI) irrigation at 21 days after sowing."
      ],
      "fertilizer_prescription": {
        "status": "VERIFIED_STCR_GENERATED",
        "rdf_n_p2o5_k2o_kg_ha": [120, 60, 40],
        "adjusted_dose_kg_ha": [120, 60, 40],
        "commercial_products": {
          "dap_kg_ha": 130.4,
          "dap_nitrogen_credit_kg_ha": 23.5,
          "urea_supplementary_kg_ha": 210.0,
          "mop_kg_ha": 66.7
        },
        "stoichiometric_notes": "Urea quantity reflects net nitrogen after deducting 23.5 kg/ha N supplied by DAP."
      }
    }
  ],
  "excluded_candidates": [
    {
      "crop_id": "rice",
      "canonical_name": "Rice (Paddy)",
      "tier1_status": "DISQUALIFIED",
      "failing_rules": [
        {
          "rule_id": "RULE-RICE-SEAS-01",
          "dimension": "cultivation_season",
          "reason": "Rice requires warm Kharif monsoon season; vernalization and chilling injury prevent Rabi growth."
        }
      ]
    }
  ]
}
```
