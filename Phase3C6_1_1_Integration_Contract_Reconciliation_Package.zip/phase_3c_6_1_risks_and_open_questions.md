# FieldWise — Phase 3C.6.1.1: Integration Risks, Provenance Audit, and Modification Inventory

**Document Reference**: `FieldWise_main/model/ml_pipeline/reports/phase_3c_6_1_risks_and_open_questions.md`  
**Phase**: 3C.6.1.1 Integration Contract and Safety Reconciliation  
**Execution Mode**: READ-ONLY Architectural Analysis  
**Date**: November 2026  
**Status**: APPROVED RECONCILED RISK & INVENTORY SPECIFICATION  

---

## 1. Verified Source Findings vs. Assumptions

In accordance with Phase 3C.6.1.1 directives, the table below explicitly delineates which findings are verified from actual inspected source code and which represent architectural assumptions.

| Finding / Architectural Element | Status | Supporting Source Reference | Details / Verification Notes |
| :--- | :--- | :--- | :--- |
| **Express Route & Validator Rules** | **VERIFIED** | `FieldWise_main/backend/src/routes/predict.js`, L13–27 | Validates 8 numeric fields with `express-validator`. Does not validate `state` or `sowing_month`. |
| **Backend Controller & Predictor Invocation** | **VERIFIED** | `FieldWise_main/backend/src/controllers/predictController.js`, L7, 32–48 | Extracts 9 fields, directly invokes legacy `predictCrops()`, returns 4-field JSON response. |
| **Legacy Gaussian Scoring & 35% Cut-off** | **VERIFIED** | `FieldWise_main/model/predictor.js`, L77–146 | Normalizes raw score to 0–100, computes synthetic yield multiplier, filters `confidence > 35`. |
| **Legacy Crop Database (16 Crops)** | **VERIFIED** | `FieldWise_main/model/cropDatabase.js`, L1–261 | Static database of 16 crops with baseline ranges and single yield constants. |
| **Legacy Fertilizer Recipes** | **VERIFIED** | `FieldWise_main/model/fertilizerDatabase.js`, L1–92 | Static string arrays per crop with fixed doses (e.g. Rice -> Urea 100–120 kg/ha). |
| **Silent Offline Fallback on 5xx Errors** | **VERIFIED** | `FieldWise_main/src/lib/api.ts`, L68–81 | Catches 5xx / connection failures and silently runs client-side `predictCropsEngine`. |
| **Client-Side Predictor Clone** | **VERIFIED** | `FieldWise_main/src/lib/predictorEngine.ts`, L1–490 | Complete in-browser TypeScript clone of the legacy Gaussian predictor. |
| **Frontend Form State & Bounds** | **VERIFIED** | `FieldWise_main/src/components/modules/CropRecommendation.tsx`, L48–125 | Captures 9 inputs. Pre-fills default values (NPK 80-50-50, pH 6.5, rain 150) if storage empty. |
| **Confidence % Display & Progress Bar** | **VERIFIED** | `FieldWise_main/src/components/PredictionResults.tsx`, L142–153 | Renders `${result.confidence.toFixed(1)}%` with horizontal progress bar. |
| **Supabase Cloud Schema** | **VERIFIED** | `FieldWise_main/src/lib/supabase.ts`, L201–222 | Writes row to `crop_predictions` with string `confidence` and numeric NPK/pH/climate fields. |
| **Frozen Phase 3C.5 RecommendationQuery** | **VERIFIED** | `FieldWise_main/model/ml_pipeline/recommendation_engine/schemas.py`, L105–218 | Exact dataclasses: `LocationInput`, `TemporalInput`, `ClimateWaterInput`, `EdaphicInput`. |
| **Frozen Mandatory Sowing Month Gate** | **VERIFIED** | `FieldWise_main/model/ml_pipeline/recommendation_engine/input_validator.py`, L105–108, 172–174 | Rejects missing/invalid `sowing_month` with `InputValidationError` / `INSUFFICIENT_DATA`. |
| **Frozen Zero STCR Approved Calibrations** | **VERIFIED** | `FieldWise_main/model/ml_pipeline/recommendation_engine/stcr_registry.py`, L30–33 | `_APPROVED_CALIBRATIONS = {}`. Engine purges unverified calibrations; returns baseline RDF. |
| **Frozen Trusted Verification Requirement** | **VERIFIED** | `FieldWise_main/model/ml_pipeline/recommendation_engine/dci_confidence.py`, L14–24 | User strings alone remain `USER_DECLARED`. Verified tier strictly requires signed `TrustedVerificationRecord`. |
| **Host Python 3 Availability** | **ASSUMPTION** | Operational deployment environment | Assumed that standard host/container has `python3` ($\ge$ 3.9) installed and on `$PATH`. |
| **Farmer Sowing Month Interaction** | **ASSUMPTION** | User experience behavior | Assumed that farmers are willing to explicitly select their planned sowing month before submission. |

---

## 2. Technical and Architectural Risks

### 2.1 Missing Sowing Month Blocking Form Submission
- **Risk Level**: HIGH
- **Description**: Sowing month must start unselected and require explicit farmer input. If users overlook the dropdown, form submission will be blocked.
- **Mitigation**:
  - Add clear validation styling to the Sowing Month dropdown (red border + descriptive helper text when submission is attempted without selection).
  - Provide a clear tooltip: *"Planned sowing month is required to match your local agricultural season and crop planting windows."*

### 2.2 Reconciled Fallback Behavior (Surfacing 5xx Errors)
- **Risk Level**: MEDIUM
- **Description**: In the legacy client (`src/lib/api.ts`), backend 5xx errors were silently swallowed by executing `predictCropsEngine` client-side. Surfacing 5xx errors directly will make backend service disruptions visible to users.
- **Mitigation**:
  - The backend bridge service will be thoroughly tested against malformed JSON and timeouts to prevent 5xx crashes.
  - When a genuine 5xx error occurs, the UI will display a constructive error message prompting the user to check their network or retry, rather than silently serving misleading local estimates.

### 2.3 User Declaration vs. Laboratory Verification Perception
- **Risk Level**: MEDIUM
- **Description**: Farmers checking `[ ] I have an official Soil Health Card / Lab Report` might expect `INDEPENDENTLY_VERIFIED` status. However, under the frozen engine's DCI evaluator, user checkboxes remain `USER_DECLARED` (granting `HIGH_CONFIDENCE_ESTIMATED_FERTILITY` or `MODERATE_ESTIMATED`).
- **Mitigation**:
  - The UI will clearly explain that checking the box enables tailored chemical fertilizer dosages with DAP Nitrogen credit, while independent verification requires an official digital verification token.

---

## 3. Open Questions for Reviewers and Stakeholders

### Question 1: Sowing Month Selector Format
- **Options**:
  - Option A: Dropdown showing 12 calendar months with agricultural season tags: e.g. `"October (Rabi)"`, `"June (Kharif)"`, `"March (Zaid)"`.
  - Option B: Simple 12-month dropdown (`"January"`, `"February"`, ...).
- **Recommendation**: Option A. Adding season annotations helps farmers align their planned sowing date with standard regional cropping cycles.

### Question 2: Fertilizer Display When Soil Test is Absent
- **Options**:
  - Option A: Display baseline ICAR State Recommended Dose of Fertilizer (RDF) figures marked `"General Reference — Not a Field Prescription"`.
  - Option B: Completely hide all fertilizer cards and show only the soil testing advisory.
- **Recommendation**: Option A. Provides valuable agronomic context without generating unverified chemical recommendations.

### Question 3: Supabase Schema Evolution
- **Options**:
  - Option A: Continue writing formatted suitability strings (e.g. `"Suitability: 88.5/100 (HIGH_CONFIDENCE)"`) to the existing `confidence` column.
  - Option B: Plan a database migration in Phase 4 to introduce dedicated `suitability_score` and `evidence_tier` columns.
- **Recommendation**: Option A for Phase 3C.6 (maintains zero schema downtime), followed by Option B in Phase 4.

---

## 4. Exact Inventory of Files Planned for Modification

The following files are strictly scheduled for creation or modification in subsequent phases. **No modifications are made in the current read-only Phase 3C.6.1.1.**

### Phase 3C.6.2: Backend Adapter and Pipeline Bridge

| File Path | Action | Planned Scope of Change |
| :--- | :--- | :--- |
| `FieldWise_main/model/ml_pipeline/recommendation_engine/adapter_cli.py` | **Create** | Standalone Python CLI runner script. Reads JSON query from `stdin`, executes `CropRecommendationEngine.recommend()`, serializes `RecommendationResult` to `stdout`. Completely external to frozen engine core. |
| `FieldWise_main/backend/src/services/recommendationEngineBridge.js` | **Create** | Node.js bridge service. Handles `child_process.spawn('python3', ...)`, marshals Express request into 20-field query, handles timeouts and exit codes, formats response. |
| `FieldWise_main/backend/src/controllers/predictController.js` | **Modify** | Integrate `recommendationEngineBridge`. Check `USE_PHASE3C_RECOMMENDATION_ENGINE` flag. Route requests to bridge; format output into unified response contract. |
| `FieldWise_main/backend/src/routes/predict.js` | **Modify** | Update `express-validator` rules: allow optional `sowing_month` (integer 1–12), `irrigationType`, `hasSoilTest`. |
| `FieldWise_main/backend/.env` & `.env.example` | **Modify** | Add environment configuration: `USE_PHASE3C_RECOMMENDATION_ENGINE=true`, `PYTHON_EXECUTABLE_PATH=python3`. |
| `FieldWise_main/backend/src/tests/predict.test.js` | **Create** | Automated backend integration test suite verifying `POST /api/predict` end-to-end against the Phase 3C.5 engine and legacy fallback behavior. |

### Phase 3C.6.3: Frontend and End-to-End Integration

| File Path | Action | Planned Scope of Change |
| :--- | :--- | :--- |
| `FieldWise_main/src/components/PredictionForm.tsx` | **Modify** | Add Planned Sowing Month selector (starts unselected, 1–12); add Soil Health Card verification toggle; connect profile irrigation type. |
| `FieldWise_main/src/components/modules/CropRecommendation.tsx` | **Modify** | Manage new form states; enforce unselected sowing month validation; handle `NO_RECOMMENDATION_SUITABLE` reclamation advisories; update Supabase save payload. |
| `FieldWise_main/src/components/PredictionResults.tsx` | **Modify** | Refactor "Confidence %" to "Agronomic Suitability: XX / 100"; add Evidence Quality Badges; render DAP Nitrogen credit notice; add expandable "Why other crops were not recommended" accordion. |
| `FieldWise_main/src/lib/api.ts` | **Modify** | Update TypeScript interfaces for `predictApi.predict` to accept 20-field payload and return augmented metadata; stop silently catching 5xx errors; restrict offline fallback to genuine network disconnection (`!navigator.onLine`). |
| `FieldWise_main/src/services/farmIntelligenceService.ts` | **Modify** | Enhance `StoredCropRecommendation` parser to handle suitability score, evidence tiers, and reclamation advisories without breaking legacy widgets. |
| `FieldWise_main/src/test/integration/recommendationIntegration.test.ts` | **Create** | Frontend integration test suite verifying form submission, API interaction, offline fallback, and result rendering. |
