/**
 * FieldWise Phase 3C.6.2.2.3: V2 Crop Recommendation Controller
 * ==============================================================
 * Dispatches validated V2 recommendation queries to the Python bridge service
 * and formats standardized, versioned HTTP responses.
 *
 * Status Codes:
 *   200 OK                   - Successful recommendation engine evaluation
 *                              (status: SUCCESS, INSUFFICIENT_DATA, NO_RECOMMENDATION_SUITABLE)
 *   400 Bad Request          - Outer schema validation failure (handled by route middleware)
 *   422 Unprocessable Entity - Agronomic validation error rejected by recommendation engine
 *   502 Bad Gateway          - Engine emitted invalid, empty, malformed, or oversized output
 *   503 Service Unavailable  - Python executable / child process could not be spawned
 *   504 Gateway Timeout      - Child process exceeded maximum execution timeout
 *   500 Internal Error       - Unexpected engine crash or execution exception
 */

const {
    executeRecommendationEngine,
    EngineValidationError,
    ProcessTimeoutError,
    ProcessSpawnError,
    ProcessSignalError,
    OversizedOutputError,
    MalformedJsonOutputError,
    InvalidEngineOutputError,
    EmptyOutputError,
} = require('../../services/v2/recommendationBridgeService');

async function predictV2(req, res, options = {}) {
    // Setup abort controller for client disconnects
    const abortController = new AbortController();
    res.on('close', () => {
        if (!res.writableEnded) {
            abortController.abort();
        }
    });

    try {
        const bridgeOptions = Object.assign({}, options, {
            abortSignal: abortController.signal,
        });

        const result = await executeRecommendationEngine(req.body, bridgeOptions);

        // Before sending 200 OK, verify client connection is still active
        if (res.writableEnded || res.destroyed || abortController.signal.aborted) {
            return;
        }

        // 200 OK: Engine completed evaluation
        // Preserves engine status (SUCCESS, INSUFFICIENT_DATA, NO_RECOMMENDATION_SUITABLE)
        // Does NOT convert suitability scores to legacy confidence or probabilities.
        return res.status(200).json({
            success: true,
            version: result.engine_version || '2.2.0-CLOSURE',
            status: result.status,
            data: result,
        });
    } catch (err) {
        // Guard: check if connection is closed, response is destroyed, or abort was signaled
        // Do not attempt to write an HTTP response or log if client disconnected
        if (res.writableEnded || res.destroyed || abortController.signal.aborted) {
            return;
        }

        console.error('[PredictV2 Error]', err.name, err.message);

        // 422: Engine-level agronomic validation error (e.g. invalid soil pH bounds, contradictory inputs)
        if (err instanceof EngineValidationError) {
            return res.status(422).json({
                success: false,
                error: {
                    code: 'ENGINE_VALIDATION_ERROR',
                    message: err.message,
                },
            });
        }

        // 504: Engine child process timed out
        if (err instanceof ProcessTimeoutError) {
            return res.status(504).json({
                success: false,
                error: {
                    code: 'EXECUTION_TIMEOUT',
                    message: 'Recommendation engine timed out while processing request.',
                },
            });
        }

        // 503: Python executable or spawn error
        if (err instanceof ProcessSpawnError) {
            return res.status(503).json({
                success: false,
                error: {
                    code: 'SERVICE_UNAVAILABLE',
                    message: 'Recommendation engine service is temporarily unavailable.',
                },
            });
        }

        // 502: Buffer limit exceeded (stdout or stderr)
        if (err instanceof OversizedOutputError) {
            return res.status(502).json({
                success: false,
                error: {
                    code: 'OUTPUT_LIMIT_EXCEEDED',
                    message: 'Recommendation engine output exceeded maximum buffer capacity.',
                },
            });
        }

        // 502: Malformed JSON, empty stdout, or invalid engine response structure
        if (
            err instanceof MalformedJsonOutputError ||
            err instanceof EmptyOutputError ||
            err instanceof InvalidEngineOutputError
        ) {
            return res.status(502).json({
                success: false,
                error: {
                    code: 'INVALID_ENGINE_OUTPUT',
                    message: 'Recommendation engine returned invalid or unparseable output.',
                },
            });
        }

        // 500: Unexpected termination by signal
        if (err instanceof ProcessSignalError) {
            return res.status(500).json({
                success: false,
                error: {
                    code: 'PROCESS_TERMINATED',
                    message: 'Recommendation engine process was unexpectedly terminated.',
                },
            });
        }

        // 500: General internal / unhandled execution error
        return res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ENGINE_ERROR',
                message: 'An unexpected internal error occurred while executing the recommendation engine.',
            },
        });
    }
}

module.exports = {
    predictV2,
};
