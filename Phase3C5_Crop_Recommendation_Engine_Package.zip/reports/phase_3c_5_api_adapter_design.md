# FieldWise — Phase 3C.5: API Compatibility Adapter Design Specification
## Non-Destructive Integration Architecture for Future Deployment

**Document Identifier**: `SPEC-3C-5-ADAPTER-v1.0.0`  
**Phase**: 3C.5 (Implementation & Specification)  
**Status**: **DESIGN ONLY — STRICTLY INACTIVE**  
**Governing Principle**: Read-only preservation of live production code (`model/predictor.js`, `model/cropDatabase.js`, `model/fertilizerDatabase.js`, `src/lib/predictorEngine.ts`, `src/lib/api.ts`).

---

## 1. Executive Summary & Purpose

The **FieldWise Phase 3C.5 Crop Recommendation Engine** operates with a rich, six-domain input schema (`RecommendationQuery`) and produces a multidimensional output tuple `[Suitability Index (0-100), Evidence Confidence Tier, Liebig Subscores, Agronomic Advisory, Stoichiometric Fertilizer Prescription]`.

In contrast, the legacy FieldWise production application (`src/lib/predictorEngine.ts`, `model/predictor.js`) expects a flat eight-field input payload:
```typescript
interface PredictionInputs {
  rainfall: number;
  temperature: number;
  humidity: number;
  soilType: string;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  ph: number;
}
```
and returns a naive scalar result:
```typescript
interface CropPredictionResult {
  crop: CropData;
  confidence: number;
  yieldPrediction: number;
  scoreBreakdown: { ... };
  fertilizers: FertilizerRec[];
}
```

This document specifies the **API Compatibility Adapter Layer** designed to bridge between the new rule-based engine and legacy clients during future migration (Phase 3C.6+), **without modifying production files or activating the adapter during Phase 3C.5**.

---

## 2. Strict Boundary & Non-Activation Invariant

1. **Zero Production Mutation**:
   - `FieldWise_main/model/predictor.js` remains unmodified.
   - `FieldWise_main/model/cropDatabase.js` remains unmodified.
   - `FieldWise_main/model/fertilizerDatabase.js` remains unmodified.
   - `FieldWise_main/src/lib/predictorEngine.ts` remains unmodified.
   - `FieldWise_main/src/lib/api.ts` remains unmodified.
2. **Adapter State**: This adapter specification is purely architectural. No adapter middleware, proxy route, or monkey-patch is active in the live runtime.
3. **Execution**: The new engine runs exclusively in its isolated Python environment under `model/ml_pipeline/recommendation_engine/`.

---

## 3. Input Transformation Layer (Legacy Client → Canonical Engine)

When an existing frontend form submits a legacy `PredictionInputs` payload, the adapter synthesizes a canonical `RecommendationQuery` using explicit, safe agronomic defaults:

```
┌─────────────────────────────────┐
│ Legacy PredictionInputs         │
│  - rainfall: 650 mm             │
│  - temperature: 28°C            │
│  - humidity: 70%                │
│  - soilType: "Clay Loam"        │
│  - nitrogen: 310 kg/ha          │
│  - phosphorus: 32 kg/ha         │
│  - potassium: 220 kg/ha         │
│  - ph: 7.2                      │
└────────────────┬────────────────┘
                 │
                 ▼  [Adapter Ingestion & Normalization]
┌─────────────────────────────────────────────────────────────────┐
│ Canonical RecommendationQuery (v1.5.0)                          │
│                                                                 │
│  location:                                                      │
│    state: (inferred from user profile or "All_India")           │
│  temporal:                                                      │
│    sowing_month: (inferred from current system date 1-12)       │
│    sowing_date: (current UTC date YYYY-MM-DD)                   │
│    cultivation_season: (inferred Kharif/Rabi from sowing_month) │
│  climate_and_water:                                             │
│    seasonal_rainfall_amount: rainfall                           │
│    temperature_mean: temperature                                │
│    relative_humidity: humidity                                  │
│    irrigation_access: "None_Rainfed" (or prompt user)           │
│  edaphic:                                                       │
│    soil_texture: (mapped via SOIL_TEXTURE_NORMALIZATION)        │
│    soil_ph: ph                                                  │
│    has_soil_test: true (if N, P, K provided and > 0)            │
│    soil_nitrogen: nitrogen                                      │
│    soil_phosphorus: phosphorus                                  │
│    soil_potassium: potassium                                    │
└─────────────────────────────────────────────────────────────────┘
```

### Safety Principles for Input Transformation
- **No Silent Favorability**: If rainfall is omitted or negative, the adapter halts and returns `INSUFFICIENT_DATA` rather than guessing zero or an average.
- **Temporal Inference Disclosure**: If `sowing_month` is derived from the server timestamp, the response metadata must explicitly state: `"temporal_source": "SERVER_TIMESTAMP_INFERRED"`.

---

## 4. Output Transformation Layer (Canonical Engine → Legacy Client)

The adapter maps the rich `RecommendationResult` into the legacy `CropPredictionResult` schema expected by existing React UI components:

| Legacy Field (`CropPredictionResult`) | Canonical Source (`CropRecommendation`) | Transformation & Safety Rules |
| :--- | :--- | :--- |
| `crop.id` | `crop_id` | Direct 1:1 lowercase string mapping. |
| `crop.name` | `canonical_name` | Direct canonical display name. |
| `crop.season` | `active_planting_window.broad_season` | Active season evaluated during Tier 1 resolution. |
| `confidence` | `suitability_score` | Transformed from $[0, 100]$ to percentage $[0, 100]$. **Mandatory Disclaimer**: Must NOT represent posterior probability. |
| `yieldPrediction` | `expected_yield_range_t_ha` | Midpoint of verified ICAR yield range: `(min_yield + max_yield) / 2.0`. |
| `scoreBreakdown.rainfall` | `tier2_components.water_score` | Decoupled physical root adequacy score. |
| `scoreBreakdown.temperature` | `tier2_components.climate_score` | Gaussian thermal alignment score. |
| `scoreBreakdown.humidity` | `tier2_components.climate_score` | Gaussian humidity alignment score. |
| `scoreBreakdown.soil` | `tier2_components.soil_score` | Edaphic texture score ($100, 75, 50$). |
| `scoreBreakdown.nitrogen` | `tier2_components.nutrient_score` | DAC&FW soil health card score. |
| `scoreBreakdown.phosphorus`| `tier2_components.nutrient_score` | DAC&FW soil health card score. |
| `scoreBreakdown.potassium` | `tier2_components.nutrient_score` | DAC&FW soil health card score. |
| `scoreBreakdown.phBonus` | `tier2_components.ph_score` | Physiological buffer alignment score. |
| `fertilizers` | `fertilizer_prescription` | **Safety Guard**: If `has_soil_test=False`, array is empty `[]` or returns general KVK advisory text. If `has_soil_test=True`, outputs DAP, Urea (with DAP N deduction), and MOP. |

---

## 5. Handling Non-Standard Execution Statuses

The legacy UI expects an array of crop predictions. The adapter defines explicit mapping for non-standard outcomes:

### 5.1 Case A: `NO_RECOMMENDATION_SUITABLE` (Environmental Hostility)
- **Cause**: Extreme heat ($> 45^\circ\text{C}$), severe soil sodicity ($\text{pH} \ge 9.0$), toxic acidity ($\text{pH} < 4.5$), or arid drought.
- **Legacy Response Mapping**:
  ```json
  {
    "status": "NO_RECOMMENDATION_SUITABLE",
    "predictions": [],
    "warning": "The agricultural environment poses extreme physiological stress. No standard crop is viable.",
    "reclamation_advisory": "Severe sodicity (pH 9.2). Gypsum application and organic pressmud required."
  }
  ```
- **UI Behavior**: Displays a warning alert banner with soil reclamation instructions instead of recommending crops that would fail.

### 5.2 Case B: `INSUFFICIENT_DATA` (Incomplete Input)
- **Cause**: Sowing month omitted, or rainfall omitted under rainfed cultivation ($DCI < 0.500$).
- **Legacy Response Mapping**:
  ```json
  {
    "status": "INSUFFICIENT_DATA",
    "predictions": [],
    "message": "Essential agricultural parameters are missing. Please provide cultivation month and water regime."
  }
  ```

---

## 6. Future Integration Architecture (Phase 3C.6 Preview)

When the project reaches Phase 3C.6 (Live Application Migration), the adapter will be deployed as an Express / TypeScript middleware module:

```
[Frontend Form UI] ── HTTP POST /api/recommend ──▶ [Express Route Handler]
                                                           │
                                                           ▼
                                               [Adapter Middleware (TS)]
                                                - Validates session JWT
                                                - Normalizes legacy payload
                                                           │
                                                           ▼
                                               [Python Child Process / Microservice]
                                                - Runs recommendation_engine/
                                                - Pure rule-based inference
                                                           │
                                                           ▼
                                               [Adapter Response Transformer]
                                                - Maps 2D tuple to UI props
                                                - Injects KVK & DAP disclaimers
                                                           │
                                                           ▼
                                               [Legacy React Dashboard View]
```

---

## 7. Compliance Checklist

- [x] Zero modifications to existing live application code.
- [x] Zero activation of integration adapters during Phase 3C.5.
- [x] Preserves decoupled water and soil accounting.
- [x] Enforces withholding of physical fertilizer quantities when soil test is absent.
- [x] Replaces probability claims with Agronomic Suitability Index.
