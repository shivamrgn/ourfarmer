# FieldWise — Phase 3C.6.1.1: Integration Architecture and Implementation Strategy

**Document Reference**: `FieldWise_main/model/ml_pipeline/reports/phase_3c_6_1_integration_architecture.md`  
**Phase**: 3C.6.1.1 Integration Contract and Safety Reconciliation  
**Execution Mode**: READ-ONLY Architectural Design  
**Date**: November 2026  
**Status**: APPROVED RECONCILED INTEGRATION ARCHITECTURE  

---

## 1. Architectural Mission & Reconciled Principles

The primary objective of Phase 3C.6 is to integrate the frozen Phase 3C.5 Python recommendation engine into the production FieldWise Node.js / React application. In accordance with Phase 3C.6.1.1 review findings, the integration architecture enforces strict safety, provenance, and fallback consistency rules across the entire stack.

### Core Architectural Principles
1. **Engine Immutability**: The frozen engine package (`FieldWise_main/model/ml_pipeline/recommendation_engine/`) remains 100% untouched. All integration logic resides in external adapters.
2. **Strict Fallback Consistency**:
   - `INSUFFICIENT_DATA` & `NO_RECOMMENDATION_SUITABLE`: Return the engine result to the client; **never** trigger fallback.
   - Backend HTTP 4xx / 5xx: Surface the exact error; **do not** silently invoke offline predictions.
   - Genuine browser network disconnection (`!navigator.onLine`): Offline legacy mode may run, with a visible warning and explicit engine attribution (`offline_legacy_engine`).
   - Python runtime unavailable on server: Server-side legacy fallback occurs **only** when `ALLOW_LEGACY_PREDICTOR_FALLBACK=true` is explicitly enabled, returning explicit metadata (`engine: "legacy_v1_fallback"`).
   - Python timeout, malformed JSON, engine exception or other runtime failure: Return an **explicit service error** (HTTP 500 / 502); do not silently invoke the legacy predictor.
3. **Explicit Farmer Input (No Silently Inferred Context)**:
   - Planned sowing month must start **unselected** in the UI and require explicit farmer input. It must **never** default to the current calendar month.
   - Missing irrigation access must remain `UNKNOWN` or trigger `INSUFFICIENT_DATA` where required; it must **never** be silently converted to rainfed.
   - User declarations (e.g. form checkboxes) must be clearly distinguished from independent laboratory verification.
   - `has_soil_test=True` must **never** be inferred from `lastTestedDate`.

---

## 2. Adapter and Service Boundary Architecture

```mermaid
sequenceDiagram
    autonumber
    actor Farmer as Farmer / Web Client
    participant UI as React UI (CropRecommendation.tsx)
    participant API as Express API (/api/v2/predict)
    participant Bridge as RecommendationEngineBridge (Node.js)
    participant CLI as adapter_cli.py (Python 3)
    participant Engine as Phase 3C.5 Engine (engine.py)

    Farmer->>UI: Submit Form (Inputs + Explicit Sowing Month)
    UI->>API: POST /api/v2/predict (JSON Payload)
    
    alt Normal Execution (Python available)
        API->>Bridge: executeRecommendation(payload)
        Bridge->>CLI: spawn python3 -m ...adapter_cli (stdin JSON)
        CLI->>Engine: recommend(RecommendationQuery)
        Engine-->>CLI: RecommendationResult (SUCCESS / NO_RECOMMENDATION / INSUFFICIENT_DATA)
        CLI-->>Bridge: stdout JSON Result
        Bridge-->>API: Parsed Engine Result
        API-->>UI: 200 OK { execution_status, recommendations, diagnostics }
        UI->>Farmer: Render Agronomic Suitability, Evidence Tiers & Advisories
    else Python Subprocess Timeout / Malformed JSON / Exception
        Bridge-->>API: Service Error (502 / 500)
        API-->>UI: 502 Bad Gateway / 500 Service Error (Explicit Failure Details)
        UI->>Farmer: Display Service Error (No silent fallback!)
    else Python Executable Missing on Server AND ALLOW_LEGACY_PREDICTOR_FALLBACK == true
        API->>API: Invoke legacy model/predictor.js
        API-->>UI: 200 OK { meta: { engine: "legacy_v1_fallback", warning: "..." }, predictions }
        UI->>Farmer: Display Legacy Fallback Banner + Predictions
    end
```

### 2.1 The Python Subprocess Bridge (`recommendation_engine/adapter_cli.py`)
In Phase 3C.6.2, a standalone CLI runner will be created outside the frozen engine core:
- **Location**: `FieldWise_main/model/ml_pipeline/recommendation_engine/adapter_cli.py`
- **Execution Protocol**:
  - `stdin`: Reads raw JSON query object matching `RecommendationQuery` schema.
  - `stdout`: Emits raw JSON result object matching `RecommendationResult` schema.
  - `stderr`: Emits operational logs and diagnostics (captured by Node.js for error reporting).
  - Exit code `0` on completed execution (including `SUCCESS`, `NO_RECOMMENDATION_SUITABLE`, and `INSUFFICIENT_DATA`).
  - Non-zero exit code only on unhandled syntax errors or interpreter crashes.
- **Source-Verified CLI Invocation Pattern**:
  ```python
  import sys, json
  from .schemas import (
      RecommendationQuery, LocationInput, TemporalInput,
      ClimateWaterInput, EdaphicInput
  )
  from .engine import CropRecommendationEngine

  def main():
      try:
          raw_input = sys.stdin.read()
          payload = json.loads(raw_input)
          query = RecommendationQuery(
              location=LocationInput(**payload["location"]),
              temporal=TemporalInput(**payload["temporal"]),
              climate_and_water=ClimateWaterInput(**payload["climate_and_water"]),
              edaphic=EdaphicInput(**payload["edaphic"]),
              # Optional fields
              stcr_calibration_id=payload.get("stcr_calibration_id"),
              target_yield_t_ha=payload.get("target_yield_t_ha"),
              has_stcr_calibration=payload.get("has_stcr_calibration", False),
          )
          engine = CropRecommendationEngine()
          result = engine.recommend(query)
          # Custom serializer converting enums and dataclasses to dict
          sys.stdout.write(json.dumps(result_to_dict(result)))
          sys.stdout.flush()
          sys.exit(0)
      except Exception as e:
          sys.stderr.write(f"FATAL_CLI_ERROR: {str(e)}\n")
          sys.exit(1)
  ```

### 2.2 Node.js Bridge Service (`FieldWise_main/backend/src/services/recommendationEngineBridge.js`)
- Spawns `python3` with a **5000 ms timeout**.
- If the child process times out, terminates the process and rejects with an explicit `ETIMEDOUT` error.
- If stdout is not valid JSON, rejects with an explicit `MALFORMED_OUTPUT` error.
- If stderr reports an exception, returns an explicit `ENGINE_EXCEPTION` error.
- Under **no circumstances** does the bridge silently swallow errors and invoke the legacy predictor.

---

## 3. Strict Reconciled Fallback Policy

| Scenario | Location | Action | UI Presentation & Attribution |
| :--- | :--- | :--- | :--- |
| **`INSUFFICIENT_DATA`** (e.g. missing sowing month or rainfed water) | Backend | Return HTTP 200 with `execution_status: "INSUFFICIENT_DATA"` and `diagnostics.rejection_reason`. | Display clear data requirement notice explaining what data is missing. **Zero fallback.** |
| **`NO_RECOMMENDATION_SUITABLE`** (e.g. severe sodicity pH 9.2) | Backend | Return HTTP 200 with `execution_status: "NO_RECOMMENDATION_SUITABLE"` and `land_reclamation_advisory`. | Display **Agronomic Remediation & Soil Health Advisory** card. **Zero fallback.** |
| **Backend HTTP 4xx / 5xx** | Client API | Surface error directly to UI state; throw error. | Display red error banner with server error message. **Zero silent fallback.** |
| **Subprocess Timeout or Engine Crash** | Backend | Return HTTP 502 / 500 with explicit error message. | Display server service error: *"Agronomic engine timed out or failed to execute."* **Zero fallback.** |
| **Python Binary Missing on Host** AND `ALLOW_LEGACY_PREDICTOR_FALLBACK=false` | Backend | Return HTTP 500: `"Python 3 runtime not installed on host"`. | Display server configuration error. |
| **Python Binary Missing on Host** AND `ALLOW_LEGACY_PREDICTOR_FALLBACK=true` | Backend | Execute `model/predictor.js`. Return payload with `meta.engine = "legacy_v1_fallback"`. | Display prominent amber banner: *"Operating in Legacy Fallback Mode. Python runtime unavailable on server."* |
| **Genuine Browser Offline Disconnection** (`!navigator.onLine`) | Client API | Execute `src/lib/predictorEngine.ts`. Return payload with `mode = "offline_legacy_engine"`. | Display prominent amber banner: *"Offline Mode: Showing basic browser estimations. Reconnect for verified agronomic gating."* |

---

## 4. Input Requirements and User Declaration Semantics

### 4.1 Sowing Month Explicit Input Policy
- In `PredictionForm.tsx` and `CropRecommendation.tsx`, the Planned Sowing Month dropdown will start **unselected** (placeholder: `"Select planned sowing month..."`).
- The "Analyze Farm & Recommend Crops" button will remain disabled until a valid month (1–12) is explicitly selected.
- The system will **NEVER** default this field to the current calendar month, preventing unverified temporal assumptions.

### 4.2 Irrigation Access Requirements
- In `PredictionForm.tsx`, an explicit **Irrigation Water Source** selector will be provided:
  - Options: `"None (Strictly Rainfed)"`, `"Tubewell / Borewell"`, `"Canal Gravity"`, `"Drip Micro-irrigation"`, `"Sprinkler"`, `"Open Well"`.
- It will start unselected. If the farmer declares `"None (Strictly Rainfed)"`, the engine evaluates rainfed adequacy.
- If the field is omitted, it will be treated as `None` / `UNKNOWN`. If rainfall is also absent, the engine immediately halts with `INSUFFICIENT_DATA`. It will **never** silently assume rainfed cultivation.

### 4.3 Soil Test Provenance and Checkbox Semantics
- A new form toggle: `[ ] I have an official Soil Health Card / Lab Test Report`.
- **Epistemic Classification**:
  - Checking this box sets `has_soil_test=True`, but its epistemic tier in DCI is **`USER_DECLARED`**.
  - It does **not** grant `INDEPENDENTLY_VERIFIED` status (which requires a verified `TrustedVerificationRecord`).
  - `lastTestedDate` from the farm profile must **never** automatically check this box.
- **Safety Gate**:
  - If unchecked (`has_soil_test=False`): Chemical fertilizer doses are **withheld for safety**, accompanied by baseline state RDF reference figures.
  - If checked (`has_soil_test=True`): Stoichiometric commercial fertilizer products (DAP, Urea, MOP) are calculated with mandatory **DAP Nitrogen credit**.

---

## 5. Frontend Presentation and UX Strategy

### 5.1 Presentation of Suitability Scores
- The crop card header in `PredictionResults.tsx` will display:
  - **"Agronomic Suitability: 88 / 100"** (Clean integer representation of ASI).
  - An adjacent **Evidence Quality Badge** (`High Evidence Confidence`, `Provisional Evidence`, `Unverified Soil Test`).
  - **Expected Yield Benchmark**: Displayed as `"3.5 – 5.0 t/ha (ICAR Regional Benchmark)"` (NO point estimates).
- The continuous percentage progress bar (`<Progress value={result.confidence} />`) will be replaced by an ASI scale indicator (`88/100`).

### 5.2 Environmental Hostility (`NO_RECOMMENDATION_SUITABLE`)
- Renders an informative, constructive **Land Reclamation & Soil Health Advisory** card (amber/violet styling).
- Explains why crops failed (e.g. *"Severe Sodicity: Soil pH 9.2 exceeds the critical tolerance of standard arable crops"*).
- Lists the specific `land_reclamation_advisory` provided by the engine (gypsum application, green manuring, drainage).
- Displays evaluated depressed crops in an expandable accordion showing their achieved ASI and primary limiting factor.
