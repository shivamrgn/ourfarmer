# FieldWise — Phase 3C.4: Canonical Input Contract Specification

**Specification Version**: 1.0.0-PROPOSED  
**Phase**: Phase 3C.4 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Overview & Objective

Phase 3C.3 proved that FieldWise's existing recommendation input interface suffered from severe semantic ambiguities:
1. Conflating annual rainfall, seasonal rainfall, and monthly rainfall into an uncalibrated scalar.
2. Silently interpreting Recommended Dose of Fertilizers (RDF) as soil test nutrient targets.
3. Completely omitting cultivation season and sowing date.
4. Omitting farm irrigation availability and water security context.
5. Assuming all farmers have laboratory soil tests, with zero defined missing-data behavior.

This document establishes the **Canonical Input Contract** for FieldWise. It formally specifies every location, climate, temporal, edaphic, and water input required to make an agronomically defensible crop recommendation.

---

## 2. Input Dimension Architecture

The input schema is organized into four decoupled domains:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       CANONICAL INPUT CONTRACT DOMAINS                       │
├───────────────────────────────┬─────────────────────────────────────────────┤
│ 1. Location & Administration  │ State, District, Agro-Climatic Zone         │
├───────────────────────────────┼─────────────────────────────────────────────┤
│ 2. Temporal & Season          │ Intended Sowing Month, Sowing Window, Season │
├───────────────────────────────┼─────────────────────────────────────────────┤
│ 3. Water & Climate            │ Rain Amount, Period, Source, Irrigation Tier│
│                               │ Temperature (Mean/Min/Max), Humidity        │
├───────────────────────────────┼─────────────────────────────────────────────┤
│ 4. Edaphic & Soil Nutrients   │ Texture Class, pH, Soil Test Flag, N, P, K   │
│                               │ Nutrient Measurement Basis & Physical Units │
└───────────────────────────────┴─────────────────────────────────────────────┘
```

---

## 3. Comprehensive Input Field Dictionary

| Field Name | Type | Physical Units | Valid Range | Status | Missing-Value Behavior | Current UI Support | UI / API Change Required |
| :--- | :---: | :---: | :---: | :---: | :--- | :---: | :---: |
| `state` | `string (enum)` | ISO-IN State Code | 28 States & 8 UTs | **Required** | Validation Error (Form submission blocked). | Yes | None (Already present). |
| `district` | `string (enum)` | District Name | Valid districts in `state` | **Optional** | Fallback to state-level agro-climatic zone default; warning logged. | No | **Yes (New dropdown required).** |
| `agro_climatic_zone` | `string (enum)` | ICAR / Planning Comm. | 15 National Zones | *Derived* | Automatically derived from `state` and `district`. | No | Backend derivation service. |
| `sowing_month` | `integer` | Calendar Month (1–12) | $1 \le m \le 12$ | **Required** | Validation Error (Must specify intended sowing month). | No | **Yes (New dropdown required).** |
| `cultivation_season` | `string (enum)` | Indian Agro-Season | `Kharif`, `Rabi`, `Zaid`, `Annual` | **Required** | Derived automatically from `sowing_month` if omitted, with user confirmation. | No | **Yes (Selector required).** |
| `irrigation_capacity` | `string (enum)` | Water Security Tier | `Rainfed_Zero_Irrigation`, `Partially_Irrigated_Protective`, `Assured_Irrigation` | **Required** | Safe Default: `Rainfed_Zero_Irrigation` with High Uncertainty Flag. | No | **Yes (Mandatory selector).** |
| `rainfall_amount` | `float` | Millimeters (mm) | $0.0 \le R \le 5000.0$ | **Required** | Validation Error if negative or null. | Yes | None (Existing input). |
| `rainfall_period_type` | `string (enum)` | Temporal Duration | `Crop_Season_Total`, `Monthly_Average`, `Annual_Normal` | **Required** | Fallback to `Crop_Season_Total`; warning logged if unconfirmed. | No | **Yes (Radio/Dropdown required).** |
| `rainfall_source` | `string (enum)` | Data Provenance | `Farmer_Estimate`, `IMD_Station_Normal`, `Weather_API` | **Optional** | Defaults to `Farmer_Estimate`. | No | Optional API integration. |
| `temperature_mean` | `float` | Degrees Celsius (°C) | $-10.0 \le T \le 55.0$ | **Required** | Validation Error if out of bounds or null. | Yes | None (Existing input). |
| `temperature_min_night` | `float` | Degrees Celsius (°C) | $-15.0 \le T_{\min} \le 45.0$ | **Optional** | Estimated from `temperature_mean` ($\Delta T \approx -8°C$ diurnal range). | No | Advanced drawer toggle. |
| `temperature_max_day` | `float` | Degrees Celsius (°C) | $0.0 \le T_{\max} \le 55.0$ | **Optional** | Estimated from `temperature_mean` ($\Delta T \approx +8°C$ diurnal range). | No | Advanced drawer toggle. |
| `relative_humidity` | `float` | Percentage (%) | $5.0 \le H \le 100.0$ | **Required** | Validation Error if outside $[5, 100]$. | Yes | None (Existing input). |
| `soil_texture` | `string (enum)` | USDA / ICAR Texture | `Clay`, `Clay Loam`, `Loamy`, `Sandy Loam`, `Sandy`, `Black Vertisol`, `Red Sandy`, `Alluvial` | **Required** | Validation Error (Must select compatible soil class). | Yes | Dropdown standardisation. |
| `soil_ph` | `float` | Standard pH scale | $3.0 \le \text{pH} \le 11.0$ | **Required** | Validation Error if $< 3.0$ or $> 11.0$. | Yes | None (Existing input). |
| `has_soil_test` | `boolean` | Flag | `true`, `false` | **Required** | Defaults to `false` if nutrient values are omitted. | No | **Yes (Toggle checkbox).** |
| `soil_nitrogen` | `float` | Defined by `nutrient_basis` | $0.0 \le N \le 1500.0$ | *Conditional* | If `has_soil_test=false`: defaults to Medium rating ($280–560$ kg/ha equivalent). | Yes | Renamed to prevent RDF confusion. |
| `soil_phosphorus` | `float` | Defined by `nutrient_basis` | $0.0 \le P \le 250.0$ | *Conditional* | If `has_soil_test=false`: defaults to Medium rating ($23–56$ kg/ha equivalent). | Yes | Renamed to prevent RDF confusion. |
| `soil_potassium` | `float` | Defined by `nutrient_basis` | $0.0 \le K \le 1000.0$ | *Conditional* | If `has_soil_test=false`: defaults to Medium rating ($140–330$ kg/ha equivalent). | Yes | Renamed to prevent RDF confusion. |
| `nutrient_basis` | `string (enum)` | Analytical Method | `SHC_Available_kg_ha`, `Laboratory_PPM`, `Qualitative_Tier` | *Conditional* | Defaults to `SHC_Available_kg_ha` if numbers entered; otherwise `Qualitative_Tier`. | No | **Yes (Unit selector).** |

---

## 4. Detailed Specification of Critical Input Dimensions

### 4.1 Cultivation Season & Sowing Window Mapping
The engine requires explicit identification of cultivation season. When a farmer selects an `sowing_month`, the system resolves the candidate season according to official national calendar standards:

```
Month:    Jan  Feb  Mar  Apr  May  Jun  Jul  Aug  Sep  Oct  Nov  Dec
Season:  [---- Rabi ----] [--- Zaid ---] [----- Kharif -----] [--- Rabi ---]
Cycle:    Harvest/Late     Summer Crop   Monsoon Sowing/Growth Winter Sowing
```

- **Kharif**: Sowing June 1 – July 31; harvest October – November. (High monsoon rain, warm temperatures).
- **Rabi**: Sowing October 15 – November 30; harvest February – April. (Cool winter days, chilling nights, dry air).
- **Zaid (Summer)**: Sowing February 15 – March 31; harvest May – June. (Hot, dry, requires assured irrigation).
- **Annual**: Year-round / 10–18 months duration (Sugarcane, Banana).

*Validation Rule*: If `cultivation_season` is entered explicitly and conflicts with `sowing_month` (e.g. `sowing_month = 7 (July)` and `season = 'Rabi'`), the system raises an immediate validation block: *"Sowing month July conflicts with Rabi winter season. Please verify your planting schedule."*

### 4.2 Irrigation Capacity & Effective Water Calculation
Rainfall and irrigation must not be evaluated in isolation. The engine defines **Total Effective Water ($W_{\text{eff}}$)** available to the crop over its growth cycle:

$$W_{\text{eff}} = R_{\text{seasonal}} + I_{\text{capacity}}$$

where $I_{\text{capacity}}$ is parameterized by the user's selected irrigation tier:
- `Rainfed_Zero_Irrigation`: $I_{\text{capacity}} = 0\text{ mm}$. The crop is 100% dependent on natural rainfall.
- `Partially_Irrigated_Protective`: $I_{\text{capacity}} = 120\text{ mm}$ (Equivalent to 1–2 life-saving irrigations of 60 mm each at critical phenological stages).
- `Assured_Irrigation`: $I_{\text{capacity}} = 600\text{ to } 1800\text{ mm}$ (Adequate to satisfy full evapotranspiration demand $ET_c$ for any field crop, provided regional canal/groundwater depth permits).

### 4.3 Rainfall Semantic Normalization
To resolve the 10x rainfall distortion identified in Phase 3C.3, input rainfall is normalized to **Seasonal Crop Water Availability ($R_{\text{seasonal}}$)**:
1. If user inputs `rainfall_period_type = 'Crop_Season_Total'`:
   $$R_{\text{seasonal}} = \text{rainfall\_amount}$$
2. If user inputs `rainfall_period_type = 'Monthly_Average'`:
   $$R_{\text{seasonal}} = \text{rainfall\_amount} \times \text{CropDurationMonths}$$
   *(e.g., 200 mm/month × 4 months = 800 mm seasonal water).*
3. If user inputs `rainfall_period_type = 'Annual_Normal'`:
   $$R_{\text{seasonal}} = \text{rainfall\_amount} \times f_{\text{monsoon\_fraction}}$$
   *(For Kharif crops, $f_{\text{monsoon\_fraction}} \approx 0.75$ in peninsular/plains India; for Rabi crops, $f \approx 0.15$).*

### 4.4 Soil Nutrient Testing vs. Qualitative Tiers
To accommodate smallholder farmers who lack formal soil test laboratory reports, the system supports a dual-path nutrient interface:
- **Path A (Laboratory Soil Health Card Input)**: Farmer enters numeric values and selects `nutrient_basis = 'SHC_Available_kg_ha'`. Values are scored against standard DAC&FW rating limits (Low/Medium/High).
- **Path B (Qualitative Assessment)**: Farmer toggles `has_soil_test = false`. The UI prompts for qualitative farmer observations:
  - *Soil Fertility Status*: `Low (Degraded / Sandy)`, `Medium (Normal Crop Land)`, `High (Heavy Manured / River Basin)`.
  - The engine assigns neutral medium nutrient scores ($s_{\text{nutrients}} = 70/100$) and flags the recommendation with `nutrient_confidence = 'ESTIMATED'`.

---

## 5. UI and Backend API Contract Specifications

### 5.1 JSON Request Payload Contract (`POST /api/recommend`)

```json
{
  "location": {
    "state": "Punjab",
    "district": "Ludhiana"
  },
  "timing": {
    "sowing_month": 11,
    "cultivation_season": "Rabi"
  },
  "water": {
    "irrigation_capacity": "Assured_Irrigation",
    "rainfall_amount": 80.0,
    "rainfall_period_type": "Crop_Season_Total",
    "rainfall_source": "IMD_Station_Normal"
  },
  "climate": {
    "temperature_mean": 18.5,
    "temperature_min_night": 11.0,
    "temperature_max_day": 24.0,
    "relative_humidity": 65.0
  },
  "soil": {
    "soil_texture": "Loamy",
    "soil_ph": 7.2,
    "has_soil_test": true,
    "nutrients": {
      "nitrogen": 310.0,
      "phosphorus": 26.0,
      "potassium": 210.0,
      "nutrient_basis": "SHC_Available_kg_ha"
    }
  }
}
```

### 5.2 JSON Response Contract

```json
{
  "success": true,
  "engine_version": "3C.5-HYBRID",
  "data_completeness_index": 0.95,
  "recommendations": [
    {
      "rank": 1,
      "crop_id": "wheat",
      "canonical_name": "Wheat",
      "scientific_name": "Triticum aestivum",
      "suitability_score": 94.2,
      "tier1_status": "ELIGIBLE",
      "limiting_factor": "None (Optimum)",
      "yield_estimate": {
        "expected_t_ha": 4.5,
        "range_t_ha": [4.0, 5.0],
        "irrigation_basis": "Assured_Irrigation"
      },
      "agronomic_advisory": [
        "Optimal sowing window for North-Western Plains Zone (Nov 1–25).",
        "Soil test indicates Medium Nitrogen (310 kg/ha); apply 100% baseline RDF (120 kg N, 60 kg P2O5, 40 kg K2O).",
        "Schedule 4–6 irrigations starting with Crown Root Initiation (CRI) at 21 days after sowing."
      ]
    }
  ],
  "excluded_crops": [
    {
      "crop_id": "rice",
      "canonical_name": "Rice (Paddy)",
      "tier1_status": "INELIGIBLE",
      "exclusion_reason": "Season Incompatibility: Rice is a Kharif crop; sowing in November Rabi violates thermal vernalization requirements.",
      "failing_constraints": ["cultivation_season", "temperature_mean"]
    }
  ],
  "warnings": []
}
```
