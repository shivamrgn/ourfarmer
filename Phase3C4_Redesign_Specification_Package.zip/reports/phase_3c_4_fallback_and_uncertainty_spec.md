# FieldWise — Phase 3C.4: Fallback & Uncertainty Handling Specification

**Specification Version**: 1.0.0-PROPOSED  
**Phase**: Phase 3C.4 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Executive Summary

A major vulnerability uncovered in Phase 3C.3 was the **Architectural Split-Brain** between the online backend engine (`model/predictor.js`) and the client-side offline fallback engine (`src/lib/predictorEngine.ts`):
- The backend catalog had 16 crops (including Banana, Mango, Jowar; omitting Sunflower, Barley, Millets).
- The frontend catalog had 16 crops (including Sunflower, Barley, Millets; omitting Banana, Mango, Jowar).
- When a user's network connection drops, `src/lib/api.ts` silently switched to the client engine, altering available crops, shifting base yields by up to +75% (Tomato), and changing fertilizer prescriptions.
- Furthermore, neither engine defined explicit policies for missing inputs, silently treating absent data as neutral or allowing undefined variables to propagate as `NaN`.

This document establishes the **Fallback & Uncertainty Handling Specification** for FieldWise. It defines explicit, fail-safe behavior for every missing, ambiguous, or out-of-bounds input, and enforces absolute **100% Dual-Engine Parity** between backend and frontend.

---

## 2. Dual-Engine Parity Architecture (Eliminating the Split-Brain)

To permanently resolve the catalog asymmetry and divergent behavior, the redesign establishes a **Single Source of Truth (SSOT)**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                 SINGLE SOURCE OF TRUTH (SSOT) CONFIGURATION                 │
│                 canonical_crop_catalogue.json (All 19 Crops)                │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                    ┌──────────────────┴──────────────────┐
                    │                                     │
                    ▼                                     ▼
┌───────────────────────────────────────┐ ┌───────────────────────────────────┐
│ ONLINE BACKEND ENGINE                 │ │ OFFLINE CLIENT-SIDE FALLBACK      │
│ (Node.js / Express Backend)           │ │ (Browser TypeScript / React)      │
│                                       │ │                                   │
│  - Imports canonical JSON             │ │  - Imports canonical JSON         │
│  - Executes Tier 1 Eligibility Gates  │ │  - Executes Tier 1 Eligibility    │
│  - Computes Tier 2 Liebig Scores      │ │  - Computes Tier 2 Liebig Scores  │
│  - Returns standardized JSON payload  │ │  - Returns identical JSON payload │
└───────────────────────────────────────┘ └───────────────────────────────────┘
```

### Parity Invariant
For any valid input payload $\mathbf{x}$:

$$\text{Backend}(\mathbf{x}) \equiv \text{FrontendFallback}(\mathbf{x})$$

The ranked list of recommended crops, suitability scores, exclusion explanations, yield projections, and fertilizer prescriptions MUST BE BITWISE IDENTICAL between the online server and offline fallback.

---

## 3. Explicit Missing-Data & Edge-Case Policies

The redesign defines explicit, non-compensatory policies for every potential data gap:

| Data Gap Scenario | Engine Behavior | User-Facing Warning / Advisory | Uncertainty Classification |
| :--- | :--- | :--- | :---: |
| **1. Missing Soil Test Values** | 1. Assigns neutral Medium rating ($s_{\text{nutrients}} = 70.0$).<br>2. Applies baseline 100% RDF (no STCR boost/cut). | *"No soil test provided. Nutrient suitability estimated using regional baseline. Perform a Soil Health Card test for precision advisory."* | `ESTIMATED_FERTILITY` |
| **2. Missing Rainfall Period Type** | 1. Defaults to `Crop_Season_Total`.<br>2. Asserts value $\le 2500$ mm; if $> 2500$, prompts user for period clarification. | *"Rainfall period assumed as Total Seasonal Crop Rainfall. Verify if your entry was annual or monthly."* | `ASSUMED_PERIOD` |
| **3. Unknown Irrigation Access** | 1. **CONSERVATIVE SAFETY DEFAULT**: Sets `irrigation_capacity = Rainfed_Zero_Irrigation`.<br>2. High water crops (Sugarcane, Banana, Rice) automatically excluded in dry zones. | *"Irrigation status omitted; defaulted safely to Rainfed (Zero Irrigation). High-water commercial crops excluded to prevent drought failure."* | `HIGH_DROUGHT_RISK` |
| **4. Unknown Planting Month** | 1. Halts execution if `cultivation_season` is also missing.<br>2. If season is provided, maps to mid-season month (e.g. Kharif $\to$ July, Rabi $\to$ November). | *"Sowing month derived from selected cultivation season."* | `CALENDAR_DERIVED` |
| **5. Unsupported / Unknown District** | 1. Validates that `state` is valid.<br>2. Resolves agro-climatic parameters using State Regional Planning Zone averages. | *"District not recognized; state-level agro-climatic averages applied. Local micro-climates may vary."* | `DISTRICT_FALLBACK` |
| **6. Conflicting Agronomic Sources** | 1. Adopts the **more restrictive physiological tolerance bound** (conservative safety margin).<br>2. Cites conflicting SAU guidelines in advisory. | *"Agronomic sources differ between states; conservative climatic threshold applied for crop safety."* | `CONSERVATIVE_BOUND` |
| **7. Physical Out-of-Bounds Inputs** | 1. Schema validator intercepts inputs before engine execution.<br>2. Rejects invalid physical values (e.g. Rain $< 0$, Temp $> 60°C$, pH $< 2.5$ or $> 12.0$). | *"Validation Error: Input values fall outside physically possible agricultural limits."* | `INVALID_INPUT_HALT` |
| **8. Crop with Insufficient Evidence** | 1. Crop status set to `HELD_BACK` in catalogue.<br>2. Crop excluded from active recommendation until peer-reviewed evidence is verified. | *"Crop temporarily omitted from recommendations pending regional research trial verification."* | `EVIDENCE_HELD_BACK` |

---

## 4. System Rejection & Zero-Recommendation Conditions

The engine must never force a recommendation when farm conditions are genuinely unfavorable.

### 4.1 Trigger Conditions for Recommendation Rejection
The engine returns an explicit `STATUS: NO_RECOMMENDATION_SUITABLE` whenever:
1. **Zero Eligible Crops**: All 19 canonical crops are excluded by Tier 1 Boolean gates.
2. **Sub-Critical Suitability**: The highest-ranking eligible crop has a suitability score $< 40.0/100$.
3. **Severe Edaphic Toxicity**: Soil pH $< 4.5$ (Acid Sulfate) or $> 8.8$ (Severe Sodic/Alkaline) without declared soil amendments.
4. **Extreme Climatic Drought**: Total effective water $W_{\text{eff}} < 200\text{ mm}$ with temperature $> 42°C$ in non-desert zones.

### 4.2 Standard Rejection Payload Contract
```json
{
  "success": true,
  "status": "NO_RECOMMENDATION_SUITABLE",
  "data_completeness_index": 0.85,
  "message": "Current agro-climatic and soil conditions do not support commercial cultivation for any of the 19 canonical field crops.",
  "primary_limiting_constraints": [
    {
      "factor": "Soil Reaction (pH)",
      "observed_value": 9.2,
      "tolerable_range": [5.0, 8.5],
      "agronomic_advisory": "Severe alkalinity prevents nutrient uptake and root nodulation. Apply agricultural gypsum and organic green manure before cropping."
    },
    {
      "factor": "Water Availability",
      "observed_value": "40 mm (Rainfed)",
      "tolerable_range": [250, 2000],
      "agronomic_advisory": "Rainfall is inadequate for commercial cropping without assured irrigation access."
    }
  ],
  "recommendations": []
}
```

---

## 5. UI Uncertainty & Transparency Display Guidelines

To ensure farmers and field extension workers clearly understand the confidence boundaries of every advisory, the UI components must adhere to the following rendering specifications:

1. **Certainty Badge**:
   - `HIGH_CERTAINTY` (Green): Full soil test, validated irrigation, known sowing month.
   - `MEDIUM_CERTAINTY` (Amber): Soil test estimated from district defaults; irrigation confirmed.
   - `LOW_CERTAINTY` (Red/Orange): Multiple inputs missing; conservative defaults applied.
2. **Transparent Exclusion Drawer**:
   - The UI must provide a clickable tab: *"Why were other crops excluded?"*
   - Clicking reveals every excluded canonical crop with its exact failing biological constraint (e.g. *"Wheat: Excluded because current season is Kharif (Monsoon heat prohibits winter vernalization)"*).
3. **Offline Indicator**:
   - When running on client-side fallback, a discreet pill displays: *"Offline Mode Active — 100% Parity with Central Agricultural Database"*.
