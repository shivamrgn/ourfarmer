# FieldWise — Phase 3C.4: Scoring Architecture Specification

**Specification Version**: 1.0.0-PROPOSED  
**Phase**: Phase 3C.4 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Executive Summary

Phase 3C.3 proved that FieldWise's current scoring engine (`model/predictor.js` and `src/lib/predictorEngine.ts`) suffers from a **critical additive scoring pathology**: by summing 8 independent continuous features into a 110-point scale, the system allows favorable scores from unrelated factors (e.g. nitrogen, phosphorus, humidity) to override fatal biological constraints (e.g. severe drought, extreme frost, or lethal soil alkalinity). In empirical stress tests, cool-season winter pulses (Lentil, Chickpea) were recommended in a 38°C desert summer with 50%–55% confidence, and Wheat was recommended in a 1200 mm submerged wetland with 51.7% confidence.

This document establishes the **Two-Tier Hybrid Scoring Architecture** for FieldWise. It guarantees that no crop can be recommended unless it first satisfies all mandatory biological survival criteria, while preserving smooth, multi-criteria differentiation among viable candidates.

---

## 2. Comparative Evaluation of Candidate Architectures

To identify the optimal recommendation engine structure, four alternative architectures were evaluated:

| Architecture | Mathematical Formulation | Agronomic Strengths | Critical Vulnerabilities | Evaluation Verdict |
| :--- | :--- | :--- | :--- | :---: |
| **Option 1: Existing Additive Scoring** | $S = \sum_{i=1}^M w_i s_i(\mathbf{x})$ | Simple to compute; continuous decay via Gaussian functions. | **Violates Liebig's Law of the Minimum**. Fatal deficits on critical variables are compensated by surplus in unrelated features. | ❌ **REJECTED (Dangerous)** |
| **Option 2: Gated Additive Scoring** | $S = \mathcal{E}(\mathbf{x}) \cdot \sum_{i=1}^M w_i s_i(\mathbf{x})$ where $\mathcal{E} \in \{0, 1\}$ | Prevents completely lethal crops from being recommended. | Within the eligible set, compensatory pathology persists: severe moisture stress can still be masked by high phosphorus fertility. | ⚠️ **INSUFFICIENT** |
| **Option 3: Pure Multiplicative (Cobb-Douglas / Liebig Min)** | $S = \prod_{i=1}^M s_i^{w_i}$ or $S = \min_i s_i$ | Strictly respects limiting factors; any factor dropping to 0 zeroes the entire score. | Hyper-sensitive to single noisy sensor readings or missing secondary inputs; poor ranking differentiation among near-optimal crops. | ⚠️ **UNBALANCED** |
| **Option 4: Two-Tier Hybrid Architecture (Recommended)** | **Tier 1**: Boolean Eligibility Filter $\mathcal{E}(c, \mathbf{x}) \in \{0, 1\}$<br>**Tier 2**: Liebig-Weighted Geometric Suitability Ranking | **Guarantees zero fatal recommendations** via Tier 1 hard gating; smooth multi-criteria ranking in Tier 2 with non-compensatory penalty. | Requires structured input contract with explicit irrigation and seasonal context. | ✅ **RECOMMENDED (Approved)** |

---

## 3. Mathematical Formalization of the Two-Tier Hybrid Architecture

```
[User Input Query: Location, Timing, Water Regime, Climate, Soil, Nutrients]
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ TIER 1: BOOLEAN AGRONOMIC ELIGIBILITY GATING                                 │
│                                                                               │
│  For each crop c in 19 Canonical Crops:                                       │
│    E_season   = Input.season in c.supported_seasons                           │
│    E_water    = TotalEffectiveWater >= c.min_seasonal_water                   │
│    E_thermal  = Input.sowing_temp between c.sowing_temp_limits                │
│    E_soil     = Input.soil_texture in c.compatible_soils                      │
│    E_ph       = Input.soil_ph between (c.ph_min - 0.5) and (c.ph_max + 0.5)   │
│                                                                               │
│    E(c, x) = E_season AND E_water AND E_thermal AND E_soil AND E_ph           │
└───────────────────────────────────────┬───────────────────────────────────────┘
                                        │
                    ┌───────────────────┴───────────────────┐
                    │                                       │
             E(c, x) = False                         E(c, x) = True
                    │                                       │
                    ▼                                       ▼
    ┌───────────────────────────────┐       ┌───────────────────────────────┐
    │ STATUS: INELIGIBLE            │       │ TIER 2: LIEBIG-WEIGHTED       │
    │ Suitability Score = 0.0       │       │ SUITABILITY RANKING           │
    │ Log specific failing rules    │       │ Compute component scores:     │
    │ Excluded from recommendations │       │   s_climate, s_soil,          │
    │                               │       │   s_nutrients, s_ph in [0,100]│
    └───────────────────────────────┘       └───────────────┬───────────────┘
                                                            │
                                                            ▼
                                            ┌───────────────────────────────┐
                                            │ GEOMETRIC AGGREGATION         │
                                            │ Final Suitability Score       │
                                            │ Return Top 3 + 3 Alternatives │
                                            └───────────────────────────────┘
```

### 3.1 Tier 1: Boolean Eligibility Gating
Let $\mathcal{C} = \{c_1, c_2, \dots, c_{19}\}$ be the 19 canonical crops. For an input query $\mathbf{x}$, a candidate crop $c$ is eligible if and only if it passes all five fundamental agronomic gates:

$$\mathcal{E}(c, \mathbf{x}) = \mathcal{G}_{\text{season}}(c, \mathbf{x}) \land \mathcal{G}_{\text{water}}(c, \mathbf{x}) \land \mathcal{G}_{\text{thermal}}(c, \mathbf{x}) \land \mathcal{G}_{\text{soil}}(c, \mathbf{x}) \land \mathcal{G}_{\text{pH}}(c, \mathbf{x})$$

1. **Season Gate**:
   $$\mathcal{G}_{\text{season}}(c, \mathbf{x}) = \begin{cases} \text{True} & \text{if } \mathbf{x}.\text{cultivation\_season} \in c.\text{supported\_seasons} \\ \text{False} & \text{otherwise} \end{cases}$$
2. **Water Availability Gate**:
   Let $W_{\text{eff}} = \mathbf{x}.R_{\text{seasonal}} + I_{\text{capacity}}(\mathbf{x}.\text{irrigation\_tier})$.
   $$\mathcal{G}_{\text{water}}(c, \mathbf{x}) = \begin{cases} \text{True} & \text{if } W_{\text{eff}} \ge c.\text{min\_seasonal\_water\_mm} \\ \text{False} & \text{otherwise} \end{cases}$$
3. **Thermal Emergence Gate**:
   $$\mathcal{G}_{\text{thermal}}(c, \mathbf{x}) = \begin{cases} \text{True} & \text{if } c.T_{\text{sow\_min}} \le \mathbf{x}.T_{\text{mean}} \le c.T_{\text{sow\_max}} \\ \text{False} & \text{otherwise} \end{cases}$$
4. **Soil Texture Whitelist Gate**:
   $$\mathcal{G}_{\text{soil}}(c, \mathbf{x}) = \begin{cases} \text{True} & \text{if } \mathbf{x}.\text{soil\_texture} \in c.\text{compatible\_soils} \\ \text{False} & \text{otherwise} \end{cases}$$
5. **Absolute pH Survival Gate**:
   $$\mathcal{G}_{\text{pH}}(c, \mathbf{x}) = \begin{cases} \text{True} & \text{if } (c.\text{pH}_{\min} - 0.5) \le \mathbf{x}.\text{soil\_ph} \le (c.\text{pH}_{\max} + 0.5) \\ \text{False} & \text{otherwise} \end{cases}$$

If $\mathcal{E}(c, \mathbf{x}) = \text{False}$, crop $c$ is assigned $\text{Suitability}(c, \mathbf{x}) = 0.0$, marked as `INELIGIBLE`, and routed to the audit log with the explicit identity of every failing constraint.

---

### 3.2 Tier 2: Liebig-Weighted Multi-Criteria Suitability Ranking
For crops that pass Tier 1 ($\mathcal{E}(c, \mathbf{x}) = \text{True}$), suitability is evaluated across four normalized component indices:

1. **Climate Suitability ($s_{\text{climate}} \in [0, 100]$)**:
   Evaluates thermal proximity to crop optimal temperature and relative humidity compatibility using Gaussian distance kernels:
   $$s_{\text{climate}}(c, \mathbf{x}) = 60 \cdot \exp\left(-\frac{\Delta_T^2}{2\sigma_T^2}\right) + 40 \cdot \exp\left(-\frac{\Delta_H^2}{2\sigma_H^2}\right)$$
2. **Water Adequacy ($s_{\text{water}} \in [0, 100]$)**:
   Evaluates effective water $W_{\text{eff}}$ against optimal seasonal water requirement:
   $$s_{\text{water}}(c, \mathbf{x}) = \begin{cases} 
   100 & \text{if } W_{\text{eff}} \ge c.\text{optimal\_water\_mm} \\
   100 \cdot \left(\frac{W_{\text{eff}} - c.\text{min\_water\_mm}}{c.\text{optimal\_water\_mm} - c.\text{min\_water\_mm}}\right)^{0.75} & \text{if } c.\text{min\_water} \le W_{\text{eff}} < c.\text{optimal\_water}
   \end{cases}$$
3. **Edaphic & Soil Texture Suitability ($s_{\text{soil}} \in [0, 100]$)**:
   - Primary ideal texture (e.g. Loamy for Wheat, Vertisol for Cotton, Sandy Loam for Groundnut): $100\text{ points}$.
   - Secondary acceptable texture: $75\text{ points}$.
   - Marginal texture: $50\text{ points}$.
4. **Soil Fertility & Nutrient Alignment ($s_{\text{nutrients}} \in [0, 100]$)**:
   Evaluates farmer Soil Health Card available nutrients ($N, P, K$) mapped against DAC&FW fertility rating limits:
   - If farmer has laboratory test: scores alignment between soil fertility status (Low, Medium, High) and crop nutrient demand.
   - If farmer lacks soil test: defaults to $70\text{ points}$ (neutral medium rating) with an `ESTIMATED_FERTILITY` flag.
5. **Soil Reaction ($s_{\text{ph}} \in [0, 100]$)**:
   - Within preferred range $[c.\text{pH}_{\min}, c.\text{pH}_{\max}]$: $100\text{ points}$.
   - Within buffer $[c.\text{pH}_{\min}-0.5, c.\text{pH}_{\min})$ or $(c.\text{pH}_{\max}, c.\text{pH}_{\max}+0.5]$: Linear decay from $100$ down to $50\text{ points}$.

### 3.3 Non-Compensatory Geometric Aggregation Formula
Component scores are aggregated using a Cobb-Douglas geometric formulation with an explicit **Liebig Minimum Penalty Factor**:

$$\text{CoreSuitability}(c, \mathbf{x}) = s_{\text{climate}}^{0.30} \cdot s_{\text{water}}^{0.30} \cdot s_{\text{soil}}^{0.20} \cdot s_{\text{nutrients}}^{0.10} \cdot s_{\text{ph}}^{0.10}$$

$$\text{LiebigFactor}(c, \mathbf{x}) = \left( \frac{\min(s_{\text{climate}}, s_{\text{water}}, s_{\text{soil}}, s_{\text{ph}})}{100} \right)^{0.25}$$

$$\text{SuitabilityScore}(c, \mathbf{x}) = \text{CoreSuitability}(c, \mathbf{x}) \times \text{LiebigFactor}(c, \mathbf{x})$$

*Agronomic Properties of the Formula*:
- Normalized strictly to $[0, 100]$.
- **Non-compensatory**: If any major physical component is marginal (e.g., $s_{\text{water}} = 40$), the Liebig factor pulls the total score down disproportionately, preventing high scores in other factors from masking the deficit.
- Differentiates superior candidates smoothly when multiple crops are fully viable.

---

## 4. Uncertainty, Evidence Confidence & Data Completeness

To preserve clear architectural boundaries, the engine strictly decouples three distinct concepts:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ 1. Suitability Score [0–100]  │ Heuristic agronomic fitness under inputs.   │
├───────────────────────────────┼─────────────────────────────────────────────┤
│ 2. Evidence Confidence Tier   │ Source validity backing the crop parameters │
│                               │ (Verified / Partially Supported / Gaps).    │
├───────────────────────────────┼─────────────────────────────────────────────┤
│ 3. Data Completeness Index    │ Fraction of required/optional inputs        │
│                               │ provided by the user [0.0–1.0].             │
└───────────────────────────────┴─────────────────────────────────────────────┘
```

**Prohibition**: Suitability scores MUST NEVER be described to users as "probabilities of crop success", "likelihood of yield", or "calibrated confidence". Heuristic scores measure ecological rule compliance, not stochastic farm risk.

### 4.1 Data Completeness Index ($DCI \in [0, 1]$)
$$DCI(\mathbf{x}) = \frac{\sum_{k=1}^K w_k \cdot \mathbb{I}(\text{field } k \text{ provided})}{\sum_{k=1}^K w_k}$$

- If $DCI \ge 0.90$: Output flagged as `HIGH_CERTAINTY`.
- If $0.70 \le DCI < 0.90$: Output flagged as `MEDIUM_CERTAINTY` (e.g. soil test estimated).
- If $DCI < 0.70$: Output flagged as `LOW_CERTAINTY` with prominent user warning: *"Recommendations generated using broad regional defaults. Supply soil test and irrigation details for accurate advisory."*

---

## 5. Output Gating, Ranking & Tie-Breaking Rules

### 5.1 Recommendation Quota & Thresholds
1. **Tier 1 Filtering**: Discard all crops with $\mathcal{E}(c, \mathbf{x}) = \text{False}$.
2. **Minimum Viability Threshold**: Discard all crops with $\text{SuitabilityScore}(c, \mathbf{x}) < 40.0$.
3. **Empty Recommendation Condition**: If zero crops pass Tier 1 or all eligible crops have score $< 40.0$, the engine halts and returns an explicit status:
   ```json
   {
     "status": "NO_RECOMMENDATION_SUITABLE",
     "message": "Current agro-climatic conditions do not meet the minimum biological requirements for any of the 19 canonical crops.",
     "primary_limiting_factors": ["Severe drought stress (< 100 mm water)", "Soil pH 9.2 exceeds tolerance"]
   }
   ```
4. **Primary and Alternative Tiers**:
   - **Top 3 Primary Recommendations**: Highest scoring eligible crops ($c_1, c_2, c_3$).
   - **Alternative Contingency Recommendations**: Next 3 eligible crops ($c_4, c_5, c_6$) with suitability $> 50.0$.

### 5.2 Deterministic Tie-Breaking
If two candidate crops have identical suitability scores ($|\Delta S| < 0.05$):
1. **First Tie-Breaker**: Higher Water Use Efficiency (crop with lower minimum water requirement prioritized in water-scarce zones).
2. **Second Tie-Breaker**: Agronomic Evidence Status (`Verified` prioritized over `Partially Supported`).
3. **Third Tie-Breaker**: Alphabetical by `crop_id` (guarantees 100% deterministic reproducibility).
