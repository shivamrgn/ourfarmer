# FieldWise — Phase 3C.6.1.1: Output Contract Compatibility Mapping

**Document Reference**: `FieldWise_main/model/ml_pipeline/reports/phase_3c_6_1_output_contract_mapping.md`  
**Phase**: 3C.6.1.1 Integration Contract and Safety Reconciliation  
**Execution Mode**: READ-ONLY Specification & Compatibility Analysis  
**Date**: November 2026  
**Status**: APPROVED RECONCILED CONTRACT MAPPING  

---

## 1. Executive Summary & Core Semantic Invariants

This document establishes the definitive output compatibility mapping between the legacy FieldWise prediction service (`POST /api/predict`) and the frozen Phase 3C.5 rule-based crop recommendation engine (`CropRecommendationEngine.recommend()`).

### Core Safety Invariants (Reconciled from Design Review)
1. **No Conflation of Suitability and Confidence**:
   - `suitabilityScore` is the **Agronomic Suitability Index (0–100)**, derived from non-compensatory Liebig limiting factors and biophysical scoring.
   - `evidenceConfidenceTier` is a completely independent epistemic quality tier (`HIGH_CONFIDENCE`, `HIGH_CONFIDENCE_ESTIMATED_FERTILITY`, `MODERATE_ESTIMATED`, `PROVISIONAL_EVALUATION`, `INSUFFICIENT_DATA`).
   - The new engine's suitability score must **NEVER** be mapped into the legacy `confidence` field or presented as a probability or model confidence percentage.
2. **No Fabricated Yield Point Estimates**:
   - The Phase 3C.5 engine outputs published **Reference Benchmark Yield Ranges** (`expected_yield_range_t_ha: [min, max]`, e.g. `[3.5, 5.0]` t/ha).
   - The integration layer must **NEVER** calculate an arithmetic midpoint (e.g. 4.25 t/ha) and present it as a single predicted point yield. The actual reference range `[min, max]` must be preserved in the response contract.
3. **Preservation of Legacy Response Semantics**:
   - Existing legacy consumers calling `/api/predict` without version negotiation must receive the exact legacy response shape and semantics when running under the legacy predictor.
   - New-engine consumers will use a versioned endpoint (`POST /api/v2/predict`) or an explicitly discriminated contract, receiving pure Phase 3C.5 semantics.

---

## 2. High-Level Contract Comparison

```mermaid
classDiagram
    class LegacyResponseContract {
        +boolean success
        +number count
        +string state
        +Array~LegacyPrediction~ predictions
    }
    class LegacyPrediction {
        +LegacyCrop crop
        +number confidence
        +number yieldPrediction
        +ScoreBreakdown scoreBreakdown
        +Array~FertilizerRec~ fertilizers
    }
    class Version2ResponseContract {
        +boolean success
        +string api_version
        +ExecutionStatus execution_status
        +QuerySummary query_summary
        +Array~Version2CropRecommendation~ recommendations
        +Array~ExcludedCandidate~ excluded_candidates
        +Object diagnostics
        +string land_reclamation_advisory
    }
    class Version2CropRecommendation {
        +number rank
        +string crop_id
        +string canonical_name
        +string crop_life_cycle
        +number suitabilityScore
        +ConfidenceTier evidenceConfidenceTier
        +Tier1Status tier1Status
        +Tier2Components tier2Components
        +PlantingWindowDefinition activePlantingWindow
        +WaterAssessmentResult waterAssessment
        +Array~number~ expectedYieldRange
        +Array~string~ agronomicAdvisory
        +Array~string~ riskWarnings
        +FertilizerPrescription fertilizerPrescription
    }

    LegacyResponseContract --> LegacyPrediction
    Version2ResponseContract --> Version2CropRecommendation
```

---

## 3. Crop Identity and Taxonomy Reconciliation

The legacy system recognises 16 crops in `FieldWise_main/model/cropDatabase.js`. The frozen Phase 3C.5 engine implements the ICAR/DES-aligned 19-crop canonical taxonomy in `recommendation_engine/catalogue.py`.

| Legacy Crop ID | Legacy Display Name | Canonical Crop ID | Canonical Display Name | Crop Category | Life Cycle | Taxonomy Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `rice` | Rice | `rice` | Rice (Paddy) | Cereal | Annual_Seasonal | Exact ID match; refined display name |
| `wheat` | Wheat | `wheat` | Wheat | Cereal | Annual_Seasonal | Exact ID and name match |
| `maize` | Maize | `maize` | Maize (Corn) | Cereal | Annual_Seasonal | Exact ID match; refined display name |
| `cotton` | Cotton | `cotton` | Cotton | Fiber | Annual_Seasonal | Exact ID and name match |
| `sugarcane` | Sugarcane | `sugarcane` | Sugarcane | Commercial | Long_Duration_Annual | Exact ID and name match |
| `soybean` | Soybean | `soybean` | Soybean | Oilseed | Annual_Seasonal | Exact ID and name match |
| `groundnut` | Groundnut | `groundnut` | Groundnut | Oilseed | Annual_Seasonal | Exact ID and name match |
| `potato` | Potato | `potato` | Potato | Tuber | Annual_Seasonal | Exact ID and name match |
| `chickpea` | Chickpea | `chickpea` | Chickpea | Pulse | Annual_Seasonal | Exact ID and name match |
| `lentil` | Lentil | `lentil` | Lentil | Pulse | Annual_Seasonal | Exact ID and name match |
| `mustard` | Mustard | `mustard` | Mustard | Oilseed | Annual_Seasonal | Exact ID and name match |
| `tomato` | Tomato | `tomato` | Tomato | Vegetable | Multi_Season_Arable | Exact ID and name match |
| `onion` | Onion | `onion` | Onion | Vegetable | Annual_Seasonal | Exact ID and name match |
| `banana` | Banana | `banana` | Banana | Fruit | Long_Duration_Annual | Exact ID and name match |
| `mango` | Mango | `mango` | Mango | Fruit | Perennial_Orchard | Exact ID and name match |
| `jowar` | Jowar | `jowar` | Jowar (Sorghum) | Millets | Annual_Seasonal | Exact ID match; refined display name |
| *None* | *Not supported* | `sunflower` | Sunflower | Oilseed | Multi_Season_Arable | **New canonical crop** |
| *None* | *Not supported* | `barley` | Barley | Cereal | Annual_Seasonal | **New canonical crop** |
| *None* | *Not supported* | `millets` | Millets (Pearl Millet / Bajra) | Millets | Annual_Seasonal | **New canonical crop** |

---

## 4. Eligibility Status, Gate Diagnostics, and Warnings

### 4.1 Legacy Behavior
- In `FieldWise_main/model/predictor.js` line 107, crops are included if `confidence > 35`.
- Rejections are opaque: no explanation is provided when a crop is omitted.

### 4.2 Phase 3C.5 Two-Tier Gating Architecture
- **Tier 1 (Agronomic Gating)**: Evaluates strict physical and agronomic boundary conditions:
  - Temporal planting window match.
  - Sowing and growing thermal tolerances (frost, heat shock).
  - Water deficit screening threshold.
  - Soil texture compatibility and root-aeration constraints.
- **Excluded Candidates Tracking**: Disqualified crops are explicitly returned in `excluded_candidates: List[ExcludedCandidate]`, where each entry provides:
  - `crop_id` & `canonical_name`
  - `tier1_status`: `DISQUALIFIED`
  - `failing_rules`: Array of `{ gate_name, status: "FAIL", reason: "..." }`
- **Active Operational Warnings**: Passing recommendations include:
  - `risk_warnings`: Non-fatal operational flags (e.g. *"Terminal heat stress likely during March grain-fill"*).
  - `agronomic_advisory`: Actionable agronomic guidelines (e.g. *"Ensure pre-sowing irrigation to establish adequate crown root moisture"*).

---

## 5. Suitability Score vs. Confidence Semantics

> [!CAUTION]
> **MANDATORY CONTRACT RULE**: The Agronomic Suitability Index (0–100) must **NEVER** be assigned to a `confidence` field or formatted as a percentage (`XX%`). It must remain in `suitabilityScore` (0–100). The evidence quality must remain in `evidenceConfidenceTier`.

### 5.1 Semantic Comparison Table

| Attribute | Legacy Contract | Phase 3C.5 Version 2 Contract |
| :--- | :--- | :--- |
| **Field Name** | `confidence` | `suitabilityScore` (Agronomic Suitability Index) |
| **Score Units** | Percentage string or number (`5.0` to `99.0%`) | Scalar index (`0.0` to `100.0` / 100) |
| **Evidence Quality** | Conflated into the confidence number | Separate `evidenceConfidenceTier` enum |
| **Underlying Math** | Gaussian continuous distance decay | Non-compensatory Liebig minimum factor penalty |
| **Viability Boundary** | Heuristic 35% cut-off | Strict agronomic viability threshold at **40.0 / 100** |
| **Display Label** | `"Confidence: 88.5%"` | `"Agronomic Suitability: 88 / 100"` |
| **Badge Presentation** | Progress bar (`<Progress value={conf} />`) | Metric card with distinct `Evidence Tier Badge` |

---

## 6. Yield Estimates and Provenance

### 6.1 Legacy Point Estimate
- Formula: `yieldPrediction = Math.round(crop.yieldPerHectare * (0.65 + (confidence/100)*0.45) * 10) / 10`.
- Defect: Artificially calculates an unverified point yield from the Gaussian confidence score.

### 6.2 Phase 3C.5 Benchmark Yield Range
- Output: `expected_yield_range_t_ha: [min, max]` (e.g. `[3.5, 5.0]` t/ha for Wheat).
- **Prohibition on Midpoints**: The integration contract will **NOT** compute `(min + max) / 2` to create a synthetic point estimate. The contract delivers the exact array `expectedYieldRange: [3.5, 5.0]`.
- **Frontend Display**: Renders as `"Expected Yield: 3.5 – 5.0 t/ha (ICAR Regional Benchmark)"`.

---

## 7. Fertilizer Prescriptions and Safety Gating

### 7.1 Legacy Fertilizer Database
- Returns a fixed, static array from `model/fertilizerDatabase.js` with no soil test awareness or stoichiometric balancing.

### 7.2 Phase 3C.5 Stoichiometric Fertilizer Prescription
- Output: `fertilizer_prescription: Optional[FertilizerPrescription]`.
- **Soil Test Safety Gate**:
  - When `has_soil_test=False`: The status is explicitly `WITHHELD_MISSING_SOIL_TEST`. Chemical doses are withheld, accompanied by disclaimers and baseline state RDF reference figures.
  - When `has_soil_test=True`: Produces commercial product quantities with mandatory **DAP Nitrogen credit**:
    - $\text{DAP} = \frac{\text{Adjusted } \text{P}_2\text{O}_5}{0.46}$
    - $\text{Net Urea} = \max\left(0, \frac{\text{Adjusted N} - (\text{DAP} \times 0.18)}{0.46}\right)$
    - $\text{MOP} = \frac{\text{Adjusted } \text{K}_2\text{O}}{0.60}$
- **STCR Calibration Status**: Because the frozen registry contains **zero approved calibrations** (`_APPROVED_CALIBRATIONS = {}`), `status: "VERIFIED_STCR_GENERATED"` is never emitted. Status is either `BASELINE_RDF_ARITHMETIC` (with DAP credit) or `WITHHELD_MISSING_SOIL_TEST`.

---

## 8. Environmental Hostility (`NO_RECOMMENDATION_SUITABLE`)

### 8.1 Legacy Behavior
- Discards crops with confidence $\le 35\%$. If all fail, returns `predictions: []`.

### 8.2 Phase 3C.5 Version 2 Contract
- Triggered when all 19 crops are disqualified in Tier 1 OR the top ranked crop's ASI is below 40.0 / 100.
- **Response Shape**:
  ```json
  {
    "success": true,
    "api_version": "2.0",
    "execution_status": "NO_RECOMMENDATION_SUITABLE",
    "query_summary": { ... },
    "recommendations": [],
    "excluded_candidates": [ ... ],
    "diagnostics": {
      "rejection_reason": "No candidate crop met the minimum agronomic viability threshold (40.0/100).",
      "depressed_candidates": [ ... ]
    },
    "land_reclamation_advisory": "Severe Soil Sodicity (pH 9.2): High exchangeable sodium limits crop emergence. Apply gypsum based on soil gypsum requirement (GR), incorporate green manure (Sesbania aculeata), and ensure proper field drainage."
  }
  ```

---

## 9. Versioned API Contracts

### 9.1 Version 1 (Legacy Endpoint: `POST /api/predict`)
Preserved for legacy callers and fallback execution:
```json
{
  "success": true,
  "count": 6,
  "state": "Punjab",
  "predictions": [
    {
      "crop": { "id": "wheat", "name": "Wheat", ... },
      "confidence": 88.5,
      "yieldPrediction": 3.7,
      "scoreBreakdown": { ... },
      "fertilizers": [ ... ]
    }
  ]
}
```

### 9.2 Version 2 (Dedicated Endpoint: `POST /api/v2/predict`)
Strictly enforces new-engine semantics:
```json
{
  "success": true,
  "api_version": "2.0",
  "engine": "phase_3c_5",
  "engine_version": "2.2.0-CLOSURE",
  "execution_status": "SUCCESS",
  "query_summary": {
    "location": "Punjab",
    "season": "Rabi",
    "planting_system_evaluated": "Timely_Sown",
    "water_regime_evaluated": "Irrigated_Canal",
    "data_completeness_index": 0.85,
    "evidence_confidence_tier": "HIGH_CONFIDENCE"
  },
  "recommendations": [
    {
      "rank": 1,
      "crop_id": "wheat",
      "canonical_name": "Wheat",
      "crop_life_cycle": "Annual_Seasonal",
      "suitabilityScore": 88.5,
      "evidenceConfidenceTier": "HIGH_CONFIDENCE",
      "tier1Status": "ELIGIBLE",
      "tier2Components": {
        "climate_score": 92.0,
        "water_score": 85.0,
        "soil_score": 90.0,
        "nutrient_score": 80.0,
        "ph_score": 95.0,
        "core_suitability": 88.4,
        "liebig_penalty_factor": 0.80
      },
      "activePlantingWindow": {
        "window_id": "WHEAT_NW_PLAINS_TIMELY",
        "planting_system": "Timely_Sown",
        "broad_season": "Rabi",
        "sowing_month_start": 10,
        "sowing_month_end": 11,
        "crop_duration_days": 140,
        "window_evidence_status": "VERIFIED"
      },
      "waterAssessment": {
        "water_gating_status": "PASS_VERIFIED",
        "effective_rainfall_mm": 65.0,
        "net_irrigation_delivered_mm": 280.0,
        "gross_irrigation_applied_mm": 350.0,
        "total_net_water_mm": 345.0,
        "deficit_against_optimal_mm": 0.0,
        "deficit_against_min_mm": 0.0,
        "irrigation_efficiency": 0.80,
        "warnings": []
      },
      "expectedYieldRange": [3.5, 5.0],
      "agronomicAdvisory": [
        "Crown root initiation (CRI) stage irrigation at 21 DAS is critical."
      ],
      "riskWarnings": [],
      "fertilizerPrescription": {
        "status": "BASELINE_RDF_ARITHMETIC",
        "rdf_n_p2o5_k2o_kg_ha": [120.0, 60.0, 40.0],
        "adjusted_dose_kg_ha": [120.0, 60.0, 40.0],
        "commercial_products": {
          "DAP_kg_ha": 130.4,
          "Urea_kg_ha": 209.8,
          "MOP_kg_ha": 66.7
        },
        "stoichiometric_notes": "Urea dose adjusted by deducting 23.5 kg N supplied by 130.4 kg DAP.",
        "disclaimers": []
      }
    }
  ],
  "excluded_candidates": [],
  "diagnostics": {
    "total_evaluated_crops": 19,
    "eligible_crops_count": 4,
    "disqualified_crops_count": 15
  },
  "land_reclamation_advisory": null
}
```

---

## 10. Persistence Contracts (Supabase & LocalStorage)

### 10.1 Browser LocalStorage (`cropswild_crop_recommendation_last`)
Maintains clear discrimination:
```typescript
interface StoredCropRecommendationV2 {
  // Engine attribution
  engine: 'phase_3c_5' | 'legacy_v1_fallback' | 'offline_legacy_engine';
  apiVersion: '2.0';
  executionStatus: string;
  analyzedAt: string;

  // Primary Agronomic Fields (NO conflation)
  topCrop: string;
  cropName: string;
  suitabilityScore: number | null;        // Agronomic Suitability Index (0-100)
  evidenceConfidenceTier: string | null;  // HIGH_CONFIDENCE, PROVISIONAL, etc.
  expectedYieldRange: [number, number] | null; // Benchmark yield range [min, max]

  // Complete V2 payload
  recommendations: Version2CropRecommendation[];
  inputs: Record<string, any>;
  landReclamationAdvisory?: string | null;
}
```

### 10.2 Supabase Cloud Persistence (`crop_predictions` table)
- To preserve existing table schema without migrations during read-only Phase 3C.6.1.1:
  - `recommended_crop`: Stores top candidate canonical name (or `"No Viable Crop Identified"`).
  - `confidence`: Populated with formatted suitability index string: e.g. `"Suitability: 88.5/100 (HIGH_CONFIDENCE)"`. This clearly informs historical viewers that the value is an agronomic suitability score rather than a probability.
  - Core environmental and edaphic fields (`nitrogen`, `phosphorus`, `potassium`, `ph`, `rainfall`, `temperature`, `humidity`) mapped directly from user inputs.
