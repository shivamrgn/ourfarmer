# FieldWise — Phase 3C.4: Fallback & Uncertainty Handling Specification

**Specification Version**: 1.1.0-CONSOLIDATED-CORRECTIONS (Phase 3C.4.1)  
**Phase**: Phase 3C.4 / Phase 3C.4.1 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Executive Summary

A major vulnerability uncovered in Phase 3C.3 was the **Architectural Split-Brain** between the online backend engine (`model/predictor.js`) and the client-side offline fallback engine (`src/lib/predictorEngine.ts`):
- The backend catalog had 16 crops (including Banana, Mango, Jowar; omitting Sunflower, Barley, Millets).
- The frontend catalog had 16 crops (including Sunflower, Barley, Millets; omitting Banana, Mango, Jowar).
- When a user's network connection drops, `src/lib/api.ts` silently switched to the client engine, altering available crops, shifting base yields by up to +75% (Tomato), and changing fertilizer prescriptions.
- Furthermore, neither engine defined explicit policies for missing inputs, silently treating absent data as neutral or allowing undefined variables to propagate as `NaN`.

This document establishes the **Fallback & Uncertainty Handling Specification** for FieldWise, updated to incorporate all Phase 3C.4.1 mandatory corrections. It eliminates the dual-engine split brain by enforcing **100% Single Source of Truth Parity**, defines rigorous missing-data policies without unsupported fixed water or fertilizer multipliers, and clearly delineates the operational boundary between `NO_RECOMMENDATION_SUITABLE` and `INSUFFICIENT_DATA`.

---

## 2. Dual-Engine Parity Architecture (Eliminating the Split-Brain)

To permanently resolve the catalog asymmetry and divergent behavior, the redesign establishes a **Single Source of Truth (SSOT)**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                 SINGLE SOURCE OF TRUTH (SSOT) CONFIGURATION                 │
│                 canonical_crop_catalogue.json (All 19 Crops)                │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                    ┌──────────────────┴──────────────────┐
                    │                                     │
                    ▼                                     ▼
┌───────────────────────────────────────┐ ┌───────────────────────────────────┐
│ ONLINE BACKEND ENGINE                 │ │ OFFLINE CLIENT-SIDE FALLBACK      │
│ (Node.js / Express Backend)           │ │ (Browser TypeScript / React)      │
│                                       │ │                                   │
│  - Imports canonical JSON             │ │  - Imports canonical JSON         │
│  - Executes Tier 1 Eligibility Gates  │ │  - Executes Tier 1 Eligibility    │
│  - Computes Tier 2 Liebig Scores      │ │  - Computes Tier 2 Liebig Scores  │
│  - Returns standardized JSON payload  │ │  - Returns identical JSON payload │
└───────────────────────────────────────┘ └───────────────────────────────────┘
```

### Parity Invariant
For any valid input payload $\mathbf{x}$:

$$\text{Backend}(\mathbf{x}) \equiv \text{FrontendFallback}(\mathbf{x})$$

The ranked list of recommended crops, suitability scores, exclusion explanations, yield projections, and fertilizer prescriptions MUST BE BITWISE IDENTICAL between the online server and offline fallback.

---

## 3. Explicit Missing-Data & Edge-Case Policies (Phase 3C.4.1 Protocol)

The redesign defines explicit, non-compensatory policies for every potential data gap:

| Data Gap Scenario | Engine Behavior | User-Facing Warning / Advisory | Uncertainty Classification |
| :--- | :--- | :--- | :---: |
| **1. Missing Soil Test Values** | 1. Assigns neutral Medium rating ($s_{\text{nutrients}} = 70.0$).<br>2. Decrements Data Completeness Index ($DCI \le 0.90$).<br>3. Does NOT fabricate commercial fertilizer bags; outputs state baseline POP with testing prompt. | *"No soil test provided. Nutrient suitability estimated using regional baseline. Perform a Soil Health Card test for precision advisory."* | `ESTIMATED_FERTILITY` |
| **2. Missing Rainfall Period Type** | 1. Prompts user to confirm if rainfall is crop-season total, monthly average, or annual.<br>2. Does NOT apply arbitrary flat 75% monsoon conversion. | *"Rainfall measurement period unconfirmed. Verify whether your entry represents total crop-season rain or annual rainfall."* | `ASSUMED_PERIOD_PROVISIONAL` |
| **3. Irrigation Access Present but Volume Unmeasured** | 1. **DOES NOT ASSUME FLAT 120 mm OR 600 mm**.<br>2. Evaluates water sufficiency as `UNKNOWN`.<br>3. Sets crop status to `CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK`. | *"Irrigation infrastructure indicated, but delivered volume is unmeasured. Water sufficiency is estimated; verify local discharge before sowing."* | `UNMEASURED_WATER_PROVISIONAL` |
| **4. Completely Unknown Irrigation Access** | 1. **CONSERVATIVE SAFETY DEFAULT**: Sets `irrigation_access = None_Rainfed`.<br>2. Evaluates strictly against rainfed moisture requirements. | *"Irrigation status omitted; defaulted safely to Rainfed. Water-demanding crops flagged with drought cautions."* | `RAINFED_CONSERVATIVE_DEFAULT` |
| **5. Missing Sowing Date with Sowing Month Provided** | 1. Automatically resolves sowing date to the 15th of `sowing_month`.<br>2. Checks region-aware planting window (timely vs late). | *"Sowing date resolved to mid-month for regional window evaluation."* | `MID_MONTH_RESOLVED` |
| **6. Unsupported / Unlisted District** | 1. Validates that `state` is recognized.<br>2. Resolves parameters using State Agro-Climatic Zone Planning averages. | *"District not recognized; state agro-climatic zone defaults applied. Local micro-climates may vary."* | `DISTRICT_ZONE_FALLBACK` |
| **7. Conflicting Agronomic Research Bounds** | 1. Adopts the **more restrictive physiological tolerance bound** (conservative safety margin).<br>2. Cites conflicting guidelines in advisory. | *"Agronomic research bounds differ across trials; conservative physiological threshold applied for crop safety."* | `CONSERVATIVE_BOUND` |
| **8. Physical Out-of-Bounds Inputs** | 1. Gateway schema validator halts execution before recommendation engine runs.<br>2. Returns HTTP 422 with descriptive validation error. | *"Validation Error: Input values fall outside physically possible agricultural limits."* | `INVALID_INPUT_HALT` |

---

## 4. Deterministic Rejection: NO_RECOMMENDATION_SUITABLE vs INSUFFICIENT_DATA

The redesign establishes a sharp, unambiguous separation between environmental hostility and input data inadequacy:

### 4.1 Boundary Matrix

```
┌──────────────────────────────────────┬──────────────────────────────────────┐
│ STATUS: NO_RECOMMENDATION_SUITABLE   │ STATUS: INSUFFICIENT_DATA            │
├──────────────────────────────────────┼──────────────────────────────────────┤
│ 1. All required inputs are VALID     │ 1. Essential inputs are MISSING,     │
│    and complete.                     │    contradictory, or uncalibrated.   │
│ 2. The physical environment is       │ 2. The biological viability of crops │
│    genuinely hostile:                │    CANNOT be determined.             │
│    - Extreme drought / heat (48°C)   │ 3. Sowing timing unknown; or         │
│    - Severe sodicity (pH > 8.8)      │    rainfall low and irrigation access│
│    - Toxic soil acidity (pH < 4.5)   │    completely omitted.               │
│    - Coarse barren sand dunes        │ 4. System halts before scoring;      │
│ 3. All 19 crops disqualified by      │    prompts the farmer for missing    │
│    Tier 1 biological gating or score │    agricultural parameters.          │
│    < 40.0.                           │                                      │
│ 4. System protects farmer from       │                                      │
│    catastrophic investment loss.     │                                      │
└──────────────────────────────────────┴──────────────────────────────────────┘
```

### 4.2 Standard Rejection Payload Contract (`NO_RECOMMENDATION_SUITABLE`)
```json
{
  "status": "NO_RECOMMENDATION_SUITABLE",
  "data_completeness_index": 0.95,
  "message": "Current agro-climatic and soil conditions do not support commercial cultivation for any of the 19 canonical field crops.",
  "primary_limiting_constraints": [
    {
      "factor": "Soil Reaction (pH)",
      "observed_value": 9.2,
      "tolerable_range": [5.0, 8.5],
      "agronomic_advisory": "Severe alkalinity prevents nutrient uptake and root nodulation. Apply agricultural gypsum and organic green manure before cropping."
    },
    {
      "factor": "Water Availability",
      "observed_value": "40 mm (Rainfed)",
      "tolerable_range": [250, 2000],
      "agronomic_advisory": "Rainfall is inadequate for commercial cropping without assured irrigation access."
    }
  ],
  "recommendations": []
}
```

### 4.3 Standard Data Inadequacy Contract (`INSUFFICIENT_DATA`)
```json
{
  "status": "INSUFFICIENT_DATA",
  "data_completeness_index": 0.45,
  "message": "Critical agronomic parameters are missing. A reliable recommendation cannot be generated without essential crop-timing and water context.",
  "missing_parameters": [
    {
      "field": "sowing_month",
      "reason": "Crop suitability cannot be evaluated without knowing the intended planting season."
    },
    {
      "field": "irrigation_access",
      "reason": "Rainfall (120 mm) is below rainfed threshold; irrigation status is required to determine feasibility."
    }
  ],
  "recommendations": []
}
```

---

## 5. UI Uncertainty & Transparency Display Guidelines

The user interface must convey evidence confidence with absolute transparency:
1. **Never Display Fake Precision**: Round suitability scores to one decimal place ($84.2$, not $84.218492\%$).
2. **Never Call Scores Probabilities**: Label scores as **Agronomic Suitability Index (0–100)**.
3. **Display Data Completeness Badges**: Every card must display its Data Completeness Tier (`High Certainty`, `Moderate / Soil Estimated`, `Provisional`).
4. **Surface Irrigation Notices**: When irrigation depth is unmeasured, display an explicit banner prompting the user to verify local borewell/canal water discharge.
