# FieldWise — Phase 3C.4: Fertilizer & Soil-Nutrient Safety Specification

**Specification Version**: 1.0.0-PROPOSED  
**Phase**: Phase 3C.4 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Executive Summary

Phase 3C.3 revealed severe systemic defects in FieldWise's current fertilizer and nutrient architecture:
1. **Semantic Conflation**: The input form prompts for "Soil Nitrogen, Phosphorus, Potassium" but evaluates inputs against Recommended Dose of Fertilizers (RDF), causing high-fertility soils (e.g. Medium Available N = 320 kg/ha) to receive 0 points.
2. **Arbitrary Prescriptions**: Heuristic NPK proximity scores are treated as quantitative fertilizer advice without accounting for soil laboratory extraction methods or regional agronomic guidelines.
3. **Database Divergence**: Backend (`model/fertilizerDatabase.js`) and frontend (`src/lib/predictorEngine.ts`) prescribe conflicting fertilizer dosages (e.g. 250 kg/ha Urea vs 150 kg/ha for Tomato), conflicting nutrient carriers (Boron spray vs Gypsum for Mustard), and differing split application timings.

This document establishes the **Fertilizer & Soil-Nutrient Safety Specification** for FieldWise. It strictly decouples soil laboratory measurements from fertilizer application rates, provides calibrated Soil-Test Crop Response (STCR) adjustments, and guarantees safe commercial fertilizer prescriptions.

---

## 2. Decoupling Soil Test Availability from Crop Fertilizer Requirements

FieldWise formally defines three distinct, non-interchangeable agronomic concepts:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ 1. Measured Available Soil Nutrients (Soil Health Card Laboratory Test)     │
│    - What the soil currently contains and can release to plant roots.      │
│    - Measured in kg/ha or ppm of elemental N, available P2O5, and K2O.      │
├─────────────────────────────────────────────────────────────────────────────┤
│ 2. Crop Recommended Dose of Fertilizers (RDF)                              │
│    - Standard external nutrients required for high yield on medium soil.    │
│    - Expressed in kg/ha of N, P2O5, and K2O (State Package of Practices).   │
├─────────────────────────────────────────────────────────────────────────────┤
│ 3. Commercial Fertilizer Product Prescription                              │
│    - Physical fertilizer bags (Urea, DAP, SSP, MOP) purchased by farmer.   │
│    - Calculated based on nutrient content, split timing, and STCR formula.  │
└─────────────────────────────────────────────────────────────────────────────┘
```

**CRITICAL MANDATE**: The recommendation engine MUST NEVER prescribe fertilizer quantities based on heuristic crop match scores. All fertilizer advisories must follow calibrated Soil-Test Crop Response (STCR) rules backed by ICAR and State Agricultural University packages of practices.

---

## 3. National Soil Health Card (DAC&FW) Standard Rating Limits

When a farmer provides laboratory soil test readings, the engine classifies soil fertility status according to the standard operational rating limits defined by the Ministry of Agriculture & Farmers Welfare, Government of India (2015):

| Parameter | Standard Analytical Method | Low Fertility | Medium Fertility | High Fertility | Units |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **Available Nitrogen (N)** | Subbiah & Asija Alkaline Permanganate ($\text{KMnO}_4$) | $< 280$ | $280 - 560$ | $> 560$ | $\text{kg/ha}$ |
| **Available Phosphorus ($P_2O_5$)** | Olsen's Sodium Bicarbonate ($0.5\text{M } \text{NaHCO}_3$) | $< 23$ | $23 - 56$ | $> 56$ | $\text{kg/ha}$ |
| **Available Potassium ($K_2O$)** | Neutral Normal Ammonium Acetate ($\text{NH}_4\text{OAc}$) | $< 140$ | $140 - 330$ | $> 330$ | $\text{kg/ha}$ |
| **Organic Carbon (OC)** | Walkley & Black Chromic Acid Titration | $< 0.50$ | $0.50 - 0.75$ | $> 0.75$ | $\%$ |
| **Available Sulphur (S)** | $0.15\% \text{ CaCl}_2$ Extraction / Turbidimetric | $< 10.0$ | $10.0 - 20.0$ | $> 20.0$ | $\text{ppm (mg/kg)}$ |
| **Available Zinc (Zn)** | DTPA Extraction Method | $< 0.60$ | $0.60 - 1.20$ | $> 1.20$ | $\text{ppm (mg/kg)}$ |
| **Available Boron (B)** | Hot Water Soluble Method | $< 0.50$ | $0.50 - 1.00$ | $> 1.00$ | $\text{ppm (mg/kg)}$ |

---

## 4. Soil-Test Crop Response (STCR) Fertilizer Adjustment Protocol

To determine the customized fertilizer dosage for a recommended crop $c$, FieldWise applies the standard **STCR Adjustment Protocol**:

$$\text{Dose}_N = \text{RDF}_N(c) \times F_{\text{STCR}}(N_{\text{status}})$$
$$\text{Dose}_P = \text{RDF}_P(c) \times F_{\text{STCR}}(P_{\text{status}})$$
$$\text{Dose}_K = \text{RDF}_K(c) \times F_{\text{STCR}}(K_{\text{status}})$$

where the adjustment factor $F_{\text{STCR}}$ is defined as:

| Soil Fertility Status | Adjustment Factor ($F_{\text{STCR}}$) | Agronomic Justification |
| :--- | :---: | :--- |
| **Low Fertility** | **1.25 (+25%)** | Soil is deficient; extra nutrients required to prevent yield loss and restore soil fertility. |
| **Medium Fertility** | **1.00 (Baseline RDF)** | Soil has adequate fertility; apply standard 100% recommended maintenance dosage. |
| **High Fertility** | **0.75 (-25%)** | Soil is rich; reduce application by 25% to prevent over-fertilization, luxury consumption, and cost. |
| **Very High / Saturated** ($>2\times \text{High}$) | **0.50 (-50%) or 0 basal** | Omit basal phosphorus/potassium to prevent toxicity and environmental leaching. |

### 4.1 Missing Soil Test Handling
If the farmer does not have a soil test (`has_soil_test = false`):
1. The engine assigns $F_{\text{STCR}} = 1.00$ (Standard State Baseline RDF).
2. The user interface displays a prominent advisory banner:
   > ⚠️ **General Fertilizer Package Displayed**: Showing state standard baseline dosage because no soil test was provided. Perform a Soil Health Card laboratory test to optimize fertilizer cost and prevent over-application.

---

## 5. Commercial Fertilizer Product Formulations & Application Splits

Farmers do not buy pure elemental nutrients; they purchase commercial fertilizer products. FieldWise calculates physical fertilizer bag quantities using the following standard nutrient conversions:

| Commercial Fertilizer | Chemical Formula / Grade | Nitrogen (N) | Phosphate ($P_2O_5$) | Potash ($K_2O$) | Secondary Nutrients |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Urea** | $\text{CO(NH}_2)_2$ | **46%** | 0% | 0% | — |
| **Di-Ammonium Phosphate (DAP)** | $(\text{NH}_4)_2\text{HPO}_4$ | **18%** | **46%** | 0% | — |
| **Single Super Phosphate (SSP)** | $\text{Ca(H}_2\text{PO}_4)_2 + \text{CaSO}_4$ | 0% | **16%** | 0% | **11% Sulphur, 19% Calcium** |
| **Muriate of Potash (MOP)** | $\text{KCl}$ | 0% | 0% | **60%** | Chloride ($48\% \text{ Cl}^-$) |
| **Zinc Sulphate (Heptahydrate)** | $\text{ZnSO}_4 \cdot 7\text{H}_2\text{O}$ | 0% | 0% | 0% | **21% Zinc, 10% Sulphur** |
| **Agricultural Gypsum** | $\text{CaSO}_4 \cdot 2\text{H}_2\text{O}$ | 0% | 0% | 0% | **18% Sulphur, 23% Calcium** |

### 5.1 Harmonized 19-Crop Fertilizer Prescriptions & Split Timing

Below is the authoritative, harmonized baseline prescription schedule compiled from ICAR and State Agricultural University packages of practices:

```
+----+-------------+----------------------+--------------------+--------------------+---------------------------------------------------------------+
| #  | Crop ID     | Urea Dosage (kg/ha)  | DAP/SSP (kg/ha)    | MOP Dosage (kg/ha) | Application Split & Micronutrient Management                  |
+----+-------------+----------------------+--------------------+--------------------+---------------------------------------------------------------+
| 1  | rice        | 130–150 kg/ha        | DAP: 60 kg/ha      | MOP: 50 kg/ha      | Split: 50% basal, 25% active tillering, 25% panicle init.     |
|    |             |                      |                    |                    | + Zinc Sulphate: 25 kg/ha basal (mandatory in alkali/calc).   |
| 2  | wheat       | 130–150 kg/ha        | DAP: 65 kg/ha      | MOP: 40 kg/ha      | Split: 50% basal, 25% at Crown Root Init (21d), 25% jointing.  |
| 3  | maize       | 180–200 kg/ha        | DAP: 65 kg/ha      | MOP: 50 kg/ha      | Split: 33% at sowing, 33% knee-high stage, 34% tasseling.     |
| 4  | cotton      | 90–120 kg/ha         | DAP: 50 kg/ha      | MOP: 40 kg/ha      | Split: 33% basal, 33% square formation, 34% early boll set.   |
| 5  | sugarcane   | 250–300 kg/ha        | SSP: 150 kg/ha     | MOP: 100 kg/ha     | Split: 25% at planting, 25% tillering (45d), 50% grand growth.|
| 6  | soybean     | 20–30 kg/ha          | SSP: 125 kg/ha     | MOP: 35 kg/ha      | Full basal application at sowing. SSP provides vital Sulphur. |
| 7  | groundnut   | 20–25 kg/ha          | SSP: 100 kg/ha     | MOP: 40 kg/ha      | Full basal at sowing. + Gypsum: 250 kg/ha at pegging (40-45d).|
| 8  | potato      | 180–220 kg/ha        | SSP: 150 kg/ha     | MOP: 150 kg/ha     | Split: 50% basal, 50% earthing up (30d). High potash crop.   |
| 9  | chickpea    | 15–20 kg/ha          | DAP: 50 kg/ha      | MOP: 25 kg/ha      | Full basal application at sowing with Rhizobium inoculation.  |
| 10 | lentil      | 15–20 kg/ha          | DAP: 40 kg/ha      | MOP: 20 kg/ha      | Full basal application at sowing with Rhizobium inoculation.  |
| 11 | mustard     | 80–100 kg/ha         | SSP: 75 kg/ha      | MOP: 30 kg/ha      | Split: 50% basal, 50% at 1st irrigation (25d). SSP for oil.   |
| 12 | tomato      | 140–160 kg/ha        | SSP: 100 kg/ha     | MOP: 70 kg/ha      | Split: 33% basal, 33% at 30d, 34% at fruit set. + Ca spray.   |
| 13 | onion       | 110–130 kg/ha        | SSP: 75 kg/ha      | MOP: 60 kg/ha      | Split: 50% basal, 25% at 30d, 25% at 45d. Avoid late nitrogen.|
| 14 | banana      | 200–250 g/plant      | SSP: 150 g/plant   | MOP: 300 g/plant   | 4 equal splits at 2nd, 3rd, 4th, and 5th month after planting.|
| 15 | mango       | 500–1000 g/tree      | SSP: 500 g/tree    | MOP: 500 g/tree    | Post-harvest application (Aug-Sept) around canopy drip line.   |
| 16 | jowar       | 70–90 kg/ha          | DAP: 40 kg/ha      | MOP: 30 kg/ha      | Split: 50% basal, 50% knee-high stage (30-35d).                |
| 17 | sunflower   | 60–80 kg/ha          | DAP: 50 kg/ha      | MOP: 30 kg/ha      | Split: 50% basal, 50% ray floret stage. + Boron foliar spray. |
| 18 | barley      | 60–80 kg/ha          | DAP: 35 kg/ha      | MOP: 20 kg/ha      | Split: 66% basal, 34% at 1st irrigation. Keep N low for malt. |
| 19 | millets     | 70–90 kg/ha          | DAP: 40 kg/ha      | MOP: 25 kg/ha      | Split: 50% basal, 50% at 30d after sowing.                     |
+----+-------------+----------------------+--------------------+--------------------+---------------------------------------------------------------+
```

---

## 6. Environmental & Over-Fertilization Safety Rules

The redesign enforces five strict environmental and agronomic safety guards:

1. **Nitrate Leaching Guard in Sandy Soils**:
   - If `soil_texture == 'Sandy'` or `'Red Sandy'`: Nitrogen application must NEVER be applied in a single basal dose $> 30\text{ kg N/ha}$. The engine mandates a 3-to-4 split schedule to prevent nitrate leaching into groundwater.
2. **Late-Nitrogen Bolting & Vegetative Trap**:
   - For `onion` and `garlic`: Zero top-dressed nitrogen is permitted after 45 days of transplanting. Late nitrogen causes thick necks, hollow bulbs, and rapid storage rotting.
3. **Malting Quality Nitrogen Ceiling**:
   - For `barley`: Total nitrogen application must not exceed $60\text{ kg N/ha}$ if intended for malting, to prevent grain protein exceeding the $11.0\%$ brewery rejection threshold.
4. **Legume Nitrogen Inactivation**:
   - For pulses (`chickpea`, `lentil`, `soybean`): Basal nitrogen must not exceed $25\text{ kg N/ha}$. High starter nitrogen inactivates the nitrogenase enzyme and prevents natural *Rhizobium* root nodulation.
5. **Chloride Toxicity in Sensitive Horticultural Crops**:
   - For `potato` and `tobacco`: High rates of Muriate of Potash ($\text{KCl}$) can impair tuber starch quality. The advisory flags Sulfate of Potash ($\text{K}_2\text{SO}_4$) as the preferred alternative when soil chloride is high.
