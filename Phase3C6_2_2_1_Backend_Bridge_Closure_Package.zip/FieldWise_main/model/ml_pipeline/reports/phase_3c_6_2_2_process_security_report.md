# FieldWise — Phase 3C.6.2.2.1: Process Security & Execution Governance Report

**Document Reference**: `FieldWise_main/model/ml_pipeline/reports/phase_3c_6_2_2_process_security_report.md`  
**Phase**: 3C.6.2.2.1 Backend Bridge Contract Closure  
**Execution Timestamp**: November 2026  
**Status**: APPROVED PROCESS SECURITY AUDIT  

---

## 1. Executive Summary

This report documents the security architecture, process lifecycle controls, stream buffer bounds, and failure isolation mechanisms implemented in the Node.js backend bridge (`FieldWise_main/backend/src/services/v2/recommendationBridgeService.js`) and its configuration (`FieldWise_main/backend/src/config/v2/bridgeConfig.js`).

The implementation strictly satisfies zero-trust process execution principles:
1. Complete prevention of command injection via `child_process.spawn` with `{ shell: false }`.
2. Immutable server-controlled paths preventing client executable or script overrides.
3. Independent stream buffer limits for stdout (10MB) and stderr (1MB) with non-retention of excess chunks.
4. Bounded execution timeouts with an actual 1,000 ms SIGTERM-to-SIGKILL grace escalation.
5. Client connection abort propagation via `res.on('close')`.
6. Strict response structure validation preventing manufactured or corrupted engine states.
7. Error sanitization hiding server paths and stack traces from external callers.

---

## 2. Server Environment Variables & Configuration

The backend bridge exposes four standardized environment variables with established defaults and fallbacks:

| Variable Name | Fallback Name | Default Value | Functional Scope |
| :--- | :--- | :---: | :--- |
| `FIELDWISE_PYTHON_PATH` | `PYTHON_PATH` | `'python3'` | Server-controlled path to Python 3 runtime. |
| `FIELDWISE_BRIDGE_TIMEOUT_MS` | `RECOMMENDATION_ENGINE_TIMEOUT_MS` | `10000` (10s) | Process execution timeout cap in milliseconds. |
| `FIELDWISE_BRIDGE_MAX_STDOUT_BYTES` | `RECOMMENDATION_ENGINE_MAX_BUFFER_BYTES` | `10485760` (10MB) | Independent maximum stdout buffer capacity. |
| `FIELDWISE_BRIDGE_MAX_STDERR_BYTES` | None | `1048576` (1MB) | Independent maximum stderr buffer capacity. |

---

## 3. Process Execution Architecture: `spawn` vs `exec`

### 3.1 Prohibition of Shell Execution
Using `child_process.exec` or passing `{ shell: true }` invokes an intermediate shell interpreter (e.g. `/bin/sh`). Shell parsing introduces critical vulnerabilities:
- Shell metacharacter injection (`;`, `&`, `|`, `` ` ``, `$()`).
- Uncontrolled environment variable substitution.
- Spawning of untracked subshells and orphaned processes.

### 3.2 Strict Non-Shell Spawning
The bridge strictly invokes `child_process.spawn` with `{ shell: false }`:
```javascript
const child = spawn(
    pythonPath,
    [adapterCliPath],
    {
        cwd: bridgeConfig.PROJECT_ROOT,
        env,
        shell: false,
        stdio: ['pipe', 'pipe', 'pipe']
    }
);
```
- Direct operating system binary execution via `execve`.
- Input parameters are transferred exclusively across the private `stdin` stream via `child.stdin.write(inputJson)` and ended with `child.stdin.end()`.
- Client inputs are never passed on command-line arguments.

---

## 4. Independent Stream Limits & Chunk Non-Retention

### 4.1 Independent Buffer Caps
The bridge configures and enforces independent buffer caps:
- **Stdout Buffer Cap**: `10 * 1024 * 1024` bytes (10 MB).
- **Stderr Buffer Cap**: `1 * 1024 * 1024` bytes (1 MB).

### 4.2 Non-Retention of Excess Chunks
To protect against memory exhaustion from runaway processes:
```javascript
child.stdout.on('data', (chunk) => {
    stdoutLen += chunk.length;
    if (stdoutLen > maxStdoutBytes) {
        if (!stdoutOversized && !stderrOversized) {
            stdoutOversized = true;
            console.error(`[Bridge] Child stdout exceeded buffer limit (${maxStdoutBytes} bytes). Terminating.`);
            try { child.kill('SIGTERM'); } catch (_) {}
        }
        // Do not retain chunks beyond the stdout limit
    } else {
        stdoutChunks.push(chunk);
    }
});

child.stderr.on('data', (chunk) => {
    stderrLen += chunk.length;
    if (stderrLen > maxStderrBytes) {
        if (!stderrOversized && !stdoutOversized) {
            stderrOversized = true;
            console.error(`[Bridge] Child stderr exceeded buffer limit (${maxStderrBytes} bytes). Terminating.`);
            try { child.kill('SIGTERM'); } catch (_) {}
        }
        // Do not retain chunks beyond the stderr limit
    } else {
        stderrChunks.push(chunk);
    }
});
```
1. When either stream exceeds its cap, the child process is immediately terminated via `SIGTERM`.
2. Excess chunks are discarded immediately, preventing memory blowup.
3. On close, the bridge rejects with `OversizedOutputError` identifying the offending stream (`details.stream: 'stdout'` or `'stderr'`).

---

## 5. Process Lifecycle & Timeout Governance

### 5.1 Timeout and Signal Escalation
- Execution is bounded to `TIMEOUT_MS` (default: 10,000 ms).
- When the timeout fires, `SIGTERM` is delivered to initiate clean shutdown.
- **Actual SIGTERM-to-SIGKILL Grace Period**: Exactly **1,000 ms (1.0 second)**. If the child process does not exit within 1,000 ms, an uncatchable `SIGKILL` is delivered:
```javascript
forceKillTimer = setTimeout(() => {
    try {
        console.warn('[Bridge] Process did not exit cleanly after SIGTERM. Sending SIGKILL.');
        child.kill('SIGKILL');
    } catch (_) {}
}, 1000);
```

### 5.2 Client Disconnect Abort Propagation
- The Express controller listens to `res.on('close')`.
- If the client disconnects before `res.writableEnded`, the `AbortController` triggers `abortSignal`.
- The child process is immediately killed with `SIGTERM`, preventing wasted server resources.

---

## 6. Python Response Validation Before Returning Success

After JSON parsing of stdout, `validateEngineOutput` validates the result against the frozen adapter output contract before resolving:
1. **Plain Object Requirement**: Reject `null`, arrays, primitives, and empty objects (`{}`).
2. **Status Requirement**: `status` must be exactly one of:
   - `SUCCESS`
   - `INSUFFICIENT_DATA`
   - `NO_RECOMMENDATION_SUITABLE`
3. **Required Fields**:
   - `engine_version` (non-empty string)
   - `execution_timestamp` (non-empty string)
   - `query_summary` (plain object)
   - `recommendations` (array of valid recommendation objects)
   - `excluded_candidates` (array)
4. **Recommendation Object Invariants**:
   - `crop_id` (string)
   - `canonical_name` (string)
   - `suitability_score` (strict finite number)
   - `rank` (integer)
5. **Zero Fabrication**: The bridge never defaults missing statuses or manufactures empty recommendation arrays. Any contract violation rejects with `InvalidEngineOutputError`, returning HTTP 502 Bad Gateway.

---

## 7. Error Sanitization & Information Leakage Prevention

- Full stderr tracebacks and diagnostic messages are logged to server console (`console.error`) for operator inspection.
- Client responses contain sanitized messages with all absolute repository paths (`/Users/...`) stripped and replaced with `[REPO_ROOT]` or `[PATH]`.
- Internal tracebacks and database connection details are strictly suppressed.

---

## 8. Verification Results

| Test ID | Security Invariant Verified | Outcome |
| :---: | :--- | :---: |
| **Unit 8** | Execution timeout aborts child process (`SIGTERM`) | **PASS** |
| **Unit 9** | Independent stdout overflow (> 10MB) terminates child and rejects | **PASS** |
| **Unit 10** | Independent stderr overflow (> 1MB) terminates child and rejects | **PASS** |
| **Unit 11** | Non-retention of chunks drops excess data without memory blowup | **PASS** |
| **Unit 13** | Premature client disconnect aborts child process cleanly | **PASS** |
| **Unit 14** | `child_process.spawn` enforces `shell: false` strictly | **PASS** |
| **Unit 15** | Client payload cannot override Python or script paths | **PASS** |
| **Unit 16.1-16.11** | Output contract validation rejects `{}`, `null`, arrays, missing status, unknown status | **PASS** |
| **Unit 17.1** | Immutable defaults: stdout=10MB, stderr=1MB, grace period=1000ms | **PASS** |
| **Integ 4.1-4.7** | Strict JSON numeric type validation rejects strings, booleans, objects, arrays, NaN, Inf | **PASS** |
