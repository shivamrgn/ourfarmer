/**
 * CropPredict AI — Express Server Entry Point
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');

// Initialize DB (creates file + tables if they don't exist)
require('./config/database');

const authRoutes = require('./routes/auth');
const predictRoutes = require('./routes/predict');
const predictV2Routes = require('./routes/v2/predict');
const schemesRoutes = require('./routes/schemes');
const expertSupportRoutes = require('./routes/expertSupport');

const app = express();

// ─── Middleware ──────────────────────────────────────────────────────────────

app.use(cors({
    origin: (origin, callback) => {
        const allowedOrigins = (process.env.FRONTEND_URL || 'http://localhost:5173,http://localhost:5174,http://localhost:8080')
            .split(',')
            .map(s => s.trim());
        if (!origin || allowedOrigins.includes(origin) || origin.startsWith('http://localhost:')) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Routes ─────────────────────────────────────────────────────────────────

app.get('/api/health', (req, res) => {
    res.json({ success: true, message: 'CropPredict API is running 🌾', timestamp: new Date().toISOString() });
});

app.use('/api/auth', authRoutes);
app.use('/api/predict', predictRoutes);
app.use('/api/v2/predict', predictV2Routes);
app.use('/api/schemes', schemesRoutes);
app.use('/api/expert-support', expertSupportRoutes);

// ─── 404 Handler ─────────────────────────────────────────────────────────────

app.use((req, res) => {
    res.status(404).json({ success: false, message: `Route ${req.method} ${req.path} not found.` });
});

// ─── Global Error Handler ─────────────────────────────────────────────────────

app.use((err, req, res, next) => {
    if (err.status === 400 || err.statusCode === 400) {
        return res.status(400).json({
            success: false,
            error: {
                code: 'INVALID_REQUEST',
                message: err.message || 'Malformed JSON payload.',
            },
        });
    }
    console.error('[Unhandled Error]', err);
    res.status(500).json({ success: false, message: 'Internal server error.' });
});

// ─── Start ───────────────────────────────────────────────────────────────────

if (require.main === module) {
    const PORT = process.env.PORT || 3001;
    app.listen(PORT, () => {
        console.log(`🚀 CropPredict API running at http://localhost:${PORT}`);
        console.log(`   Health check: http://localhost:${PORT}/api/health`);
    });
}

module.exports = app;
