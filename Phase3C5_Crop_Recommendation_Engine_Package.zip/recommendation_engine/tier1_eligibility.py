"""
FieldWise Phase 3C.5: Tier 1 Agronomic Eligibility & Safety Gating Module
========================================================================
Evaluates candidate crops against the five biological survival gates:
  1. Temporal & Regional Planting Window Gate
  2. Thermal Emergence & Germination Gate
  3. Edaphic Soil Texture Compatibility Gate
  4. Soil Reaction (pH) Physiological Survival Gate
  5. Water Sufficiency & Delivery Gate

Safety Invariants Enforced:
  - Rainfed screening thresholds NEVER independently produce Tier 1 FAIL.
  - Unmeasured irrigation returns UNKNOWN, maintaining conditional eligibility.
  - Sodic / alkaline soils (pH > 9.0) trigger universal arable crop failure.
  - Hard exclusions are restricted to true physiological lethality.
"""

from typing import Dict, List, Optional, Tuple
from .schemas import (
    CropCatalogueEntry,
    PlantingWindowDefinition,
    RecommendationQuery,
    Tier1Status,
    Tier1GateResult,
    Tier1EvaluationResult,
    WaterGatingStatus,
    WaterAssessmentResult,
)
from .planting_window import PlantingWindowResolver
from .water_assessment import WaterAssessmentModule


class Tier1EligibilityEvaluator:
    """
    Evaluates whether a candidate crop qualifies biologically to enter Tier 2 scoring.
    """

    @classmethod
    def evaluate(
        cls,
        crop: CropCatalogueEntry,
        query: RecommendationQuery,
        water_result: WaterAssessmentResult,
        active_window: Optional[PlantingWindowDefinition],
        window_status: str,
        window_reason: str,
    ) -> Tier1EvaluationResult:
        """
        Executes all five biological survival gates.
        """
        gate_results: Dict[str, Tier1GateResult] = {}
        failing_rules: List[Dict[str, str]] = []
        warnings: List[str] = list(water_result.warnings)

        # ---------------------------------------------------------------------
        # Gate 1: Temporal & Planting Window Gate
        # ---------------------------------------------------------------------
        if window_status == "PASS":
            gate_results["G_season"] = Tier1GateResult("G_season", "PASS", window_reason)
        elif window_status == "UNKNOWN":
            gate_results["G_season"] = Tier1GateResult("G_season", "UNKNOWN", window_reason)
        else:
            gate_results["G_season"] = Tier1GateResult("G_season", "FAIL", window_reason)
            failing_rules.append({
                "rule_id": f"RULE-{crop.crop_id.upper()}-SEAS-01",
                "dimension": "planting_window",
                "reason": window_reason
            })

        # ---------------------------------------------------------------------
        # Gate 2: Thermal Emergence Gate
        # ---------------------------------------------------------------------
        t_mean = query.climate_and_water.temperature_mean
        if t_mean is None:
            gate_results["G_thermal"] = Tier1GateResult("G_thermal", "UNKNOWN", "Mean temperature not provided.")
        elif t_mean < crop.sowing_temp_min_c:
            reason = (
                f"{crop.canonical_name}: Mean temperature ({t_mean}°C) is below minimum lethal "
                f"germination threshold ({crop.sowing_temp_min_c}°C). Severe chilling/frost emergence failure."
            )
            gate_results["G_thermal"] = Tier1GateResult("G_thermal", "FAIL", reason)
            failing_rules.append({
                "rule_id": f"RULE-{crop.crop_id.upper()}-TEMP-01",
                "dimension": "thermal_emergence",
                "reason": reason
            })
        elif t_mean > crop.sowing_temp_max_c:
            reason = (
                f"{crop.canonical_name}: Mean temperature ({t_mean}°C) exceeds maximum lethal "
                f"emergence threshold ({crop.sowing_temp_max_c}°C). Extreme seedling heat scorch and desiccation."
            )
            gate_results["G_thermal"] = Tier1GateResult("G_thermal", "FAIL", reason)
            failing_rules.append({
                "rule_id": f"RULE-{crop.crop_id.upper()}-TEMP-01",
                "dimension": "thermal_emergence",
                "reason": reason
            })
        else:
            gate_results["G_thermal"] = Tier1GateResult(
                "G_thermal", "PASS",
                f"{crop.canonical_name}: Mean temperature ({t_mean}°C) within survival limits [{crop.sowing_temp_min_c}, {crop.sowing_temp_max_c}]°C."
            )

        # ---------------------------------------------------------------------
        # Gate 3: Edaphic Soil Texture Gate
        # ---------------------------------------------------------------------
        soil_tex = query.edaphic.soil_texture
        if not soil_tex:
            gate_results["G_soil"] = Tier1GateResult("G_soil", "UNKNOWN", "Soil texture not provided.")
        else:
            # Check if texture is strictly restricted (lethal physical impedance)
            is_restricted = any(tex.lower() == soil_tex.lower() for tex in crop.restricted_soil_textures)
            if is_restricted:
                reason = (
                    f"{crop.canonical_name}: Soil texture '{soil_tex}' is in restricted class "
                    f"({', '.join(crop.restricted_soil_textures)}). Incompatible physical aeration/drainage."
                )
                gate_results["G_soil"] = Tier1GateResult("G_soil", "FAIL", reason)
                failing_rules.append({
                    "rule_id": f"RULE-{crop.crop_id.upper()}-SOIL-01",
                    "dimension": "soil_texture",
                    "reason": reason
                })
            else:
                gate_results["G_soil"] = Tier1GateResult(
                    "G_soil", "PASS",
                    f"{crop.canonical_name}: Soil texture '{soil_tex}' compatible."
                )

        # ---------------------------------------------------------------------
        # Gate 4: Soil Reaction (pH) Survival Gate
        # ---------------------------------------------------------------------
        soil_ph = query.edaphic.soil_ph
        if soil_ph is None:
            gate_results["G_ph"] = Tier1GateResult("G_ph", "UNKNOWN", "Soil pH not provided.")
        elif soil_ph >= 9.0:
            # Severe soil sodicity / alkalinity disaster (TEST-04)
            reason = f"{crop.canonical_name}: Soil pH ({soil_ph}) indicates severe alkali/sodic toxicity (pH >= 9.0). Biological survival failed."
            gate_results["G_ph"] = Tier1GateResult("G_ph", "FAIL", reason)
            failing_rules.append({
                "rule_id": f"RULE-{crop.crop_id.upper()}-PH-01",
                "dimension": "soil_ph",
                "reason": reason
            })
        elif soil_ph < (crop.soil_ph_min - 0.5):
            reason = f"{crop.canonical_name}: Soil pH ({soil_ph}) below lethal survival limit ({crop.soil_ph_min - 0.5}). Severe aluminum/manganese toxicity."
            gate_results["G_ph"] = Tier1GateResult("G_ph", "FAIL", reason)
            failing_rules.append({
                "rule_id": f"RULE-{crop.crop_id.upper()}-PH-01",
                "dimension": "soil_ph",
                "reason": reason
            })
        elif soil_ph > (crop.soil_ph_max + 0.5):
            reason = f"{crop.canonical_name}: Soil pH ({soil_ph}) exceeds lethal survival limit ({crop.soil_ph_max + 0.5}). Severe micronutrient fixation and sodicity."
            gate_results["G_ph"] = Tier1GateResult("G_ph", "FAIL", reason)
            failing_rules.append({
                "rule_id": f"RULE-{crop.crop_id.upper()}-PH-01",
                "dimension": "soil_ph",
                "reason": reason
            })
        else:
            gate_results["G_ph"] = Tier1GateResult(
                "G_ph", "PASS",
                f"{crop.canonical_name}: Soil pH ({soil_ph}) within biological tolerance [{crop.soil_ph_min - 0.5}, {crop.soil_ph_max + 0.5}]."
            )

        # ---------------------------------------------------------------------
        # Gate 5: Water Survival Gate
        # ---------------------------------------------------------------------
        # Strictly enforces Phase 3C.4.2.2.1:
        # Rainfed screening thresholds NEVER cause hard exclusion or Tier 1 FAIL.
        w_status = water_result.water_gating_status
        if w_status == WaterGatingStatus.CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK:
            gate_results["G_water"] = Tier1GateResult(
                "G_water", "UNKNOWN",
                f"{crop.canonical_name}: Irrigation access confirmed but delivered volume unmeasured."
            )
        elif w_status == WaterGatingStatus.TEMPORAL_MISMATCH_PROVISIONAL:
            gate_results["G_water"] = Tier1GateResult(
                "G_water", "UNKNOWN",
                f"{crop.canonical_name}: Irrigation measurement period incompatible with crop duration."
            )
        elif w_status == WaterGatingStatus.CONDITIONALLY_ELIGIBLE_WITH_HIGH_WATER_RISK:
            gate_results["G_water"] = Tier1GateResult(
                "G_water", "PASS",  # Passed Tier 1 gating with soft penalty downstream
                f"{crop.canonical_name}: Water deficit flagged; eligible with high water risk and Tier 2 penalty."
            )
        else:
            gate_results["G_water"] = Tier1GateResult(
                "G_water", "PASS",
                f"{crop.canonical_name}: Water assessment criteria satisfied ({w_status.value})."
            )

        # ---------------------------------------------------------------------
        # Synthesize Overall Tier 1 Status
        # ---------------------------------------------------------------------
        has_fail = any(g.status == "FAIL" for g in gate_results.values())
        has_unknown = any(g.status == "UNKNOWN" for g in gate_results.values())

        if has_fail:
            overall = Tier1Status.DISQUALIFIED
        elif has_unknown or w_status in [
            WaterGatingStatus.CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_WATER_RISK,
            WaterGatingStatus.CONDITIONALLY_ELIGIBLE_WITH_HIGH_WATER_RISK,
            WaterGatingStatus.CONDITIONALLY_ELIGIBLE_WITH_PROVISIONAL_WATER_BALANCE,
            WaterGatingStatus.TEMPORAL_MISMATCH_PROVISIONAL,
        ]:
            overall = Tier1Status.CONDITIONALLY_ELIGIBLE
        else:
            overall = Tier1Status.ELIGIBLE

        return Tier1EvaluationResult(
            overall_status=overall,
            gate_results=gate_results,
            failing_rules=failing_rules,
            warnings=warnings,
        )
