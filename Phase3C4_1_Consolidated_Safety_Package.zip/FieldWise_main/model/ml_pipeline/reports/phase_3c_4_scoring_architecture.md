# FieldWise — Phase 3C.4: Scoring Architecture Specification

**Specification Version**: 1.1.0-CONSOLIDATED-CORRECTIONS (Phase 3C.4.1)  
**Phase**: Phase 3C.4 / Phase 3C.4.1 (Recommendation Engine Safety Redesign Specification)  
**Status**: DESIGN-ONLY SPECIFICATION (Read-Only Application Preservation Enforced)  
**Target Integration**: Future Phase 3C.5 Implementation  

---

## 1. Executive Summary

Phase 3C.3 proved that FieldWise's current scoring engine (`model/predictor.js` and `src/lib/predictorEngine.ts`) suffers from a **critical additive scoring pathology**: by summing 8 independent continuous features into a 110-point scale, the system allows favorable scores from unrelated factors (e.g. nitrogen, phosphorus, humidity) to override fatal biological constraints (e.g. severe drought, extreme frost, or lethal soil alkalinity). In empirical stress tests, cool-season winter pulses (Lentil, Chickpea) were recommended in a 38°C desert summer with 50%–55% confidence, and Wheat was recommended in a 1200 mm submerged wetland with 51.7% confidence.

This document establishes the **Two-Tier Hybrid Scoring Architecture** for FieldWise, updated to incorporate all mandatory Phase 3C.4.1 corrections. It preserves the approved mathematical formulation (Boolean Gating followed by Liebig-weighted geometric aggregation), while providing formal clarifications on `UNKNOWN` gating outcomes, missing data handling, score non-comparability, confidence segregation, and the definitive boundary between `NO_RECOMMENDATION_SUITABLE` and `INSUFFICIENT_DATA`.

---

## 2. Comparative Evaluation of Candidate Architectures

To identify the optimal recommendation engine structure, four alternative architectures were evaluated:

| Architecture | Mathematical Formulation | Agronomic Strengths | Critical Vulnerabilities | Evaluation Verdict |
| :--- | :--- | :--- | :--- | :---: |
| **Option 1: Existing Additive Scoring** | $S = \sum_{i=1}^M w_i s_i(\mathbf{x})$ | Simple to compute; continuous decay via Gaussian functions. | **Violates Liebig's Law of the Minimum**. Fatal deficits on critical variables are compensated by surplus in unrelated features. | ❌ **REJECTED (Dangerous)** |
| **Option 2: Gated Additive Scoring** | $S = \mathcal{E}(\mathbf{x}) \cdot \sum_{i=1}^M w_i s_i(\mathbf{x})$ where $\mathcal{E} \in \{0, 1\}$ | Prevents completely lethal crops from being recommended. | Within the eligible set, compensatory pathology persists: severe moisture stress can still be masked by high phosphorus fertility. | ⚠️ **INSUFFICIENT** |
| **Option 3: Pure Multiplicative (Cobb-Douglas / Liebig Min)** | $S = \prod_{i=1}^M s_i^{w_i}$ or $S = \min_i s_i$ | Strictly respects limiting factors; any factor dropping to 0 zeroes the entire score. | Hyper-sensitive to single noisy sensor readings or missing secondary inputs; poor ranking differentiation among near-optimal crops. | ⚠️ **UNBALANCED** |
| **Option 4: Two-Tier Hybrid Architecture (Recommended)** | **Tier 1**: Boolean Eligibility Filter $\mathcal{E}(c, \mathbf{x}) \in \{0, 1\}$<br>**Tier 2**: Liebig-Weighted Geometric Suitability Ranking | **Guarantees zero fatal recommendations** via Tier 1 hard gating; smooth multi-criteria ranking in Tier 2 with non-compensatory penalty. | Requires structured input contract with explicit irrigation and seasonal context. | ✅ **RECOMMENDED (Approved)** |

---

## 3. Mathematical Formalization of the Two-Tier Hybrid Architecture

```
[User Input Query: Location, Timing, Water Regime, Climate, Soil, Nutrients]
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ TIER 1: AGRONOMIC ELIGIBILITY & SAFETY GATING                                 │
│                                                                               │
│  For each crop c in 19 Canonical Crops:                                       │
│    E_season   = Input.season in c.supported_seasons                           │
│    E_thermal  = Input.sowing_temp between c.sowing_temp_limits                │
│    E_soil     = Input.soil_texture in c.compatible_soils                      │
│    E_ph       = Input.soil_ph between (c.ph_min - 0.5) and (c.ph_max + 0.5)   │
│    E_water    = WaterSufficiency(c, Input.water_regime)                       │
│                                                                               │
│    Outcomes: ELIGIBLE, INELIGIBLE, CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_RISK   │
└───────────────────────────────────────┬───────────────────────────────────────┘
                                        │
                    ┌───────────────────┼───────────────────┐
                    │                   │                   │
         E(c, x) = INELIGIBLE      E(c, x) = UNKNOWN    E(c, x) = ELIGIBLE
                    │                   │                   │
                    ▼                   ▼                   ▼
    ┌─────────────────────────┐ ┌─────────────────┐ ┌─────────────────────────┐
    │ STATUS: INELIGIBLE      │ │ STATUS:         │ │ TIER 2: LIEBIG-WEIGHTED │
    │ Suitability Score = 0.0 │ │ PROVISIONAL     │ │ SUITABILITY RANKING     │
    │ Log specific failing    │ │ Flag high water │ │ Compute component scores│
    │ biological rules        │ │ or season risk  │ │   s_clim, s_wat, s_soil,│
    │                         │ │ Max conf=MEDIUM │ │   s_nutr, s_ph in [0,100│
    └─────────────────────────┘ └────────┬────────┘ └───────────┬─────────────┘
                                         │                      │
                                         └──────────┬───────────┘
                                                    │
                                                    ▼
                                    ┌───────────────────────────────┐
                                    │ GEOMETRIC AGGREGATION         │
                                    │ Final Suitability Index (0-100│
                                    │ Displayed with DCI & Conf Tier│
                                    └───────────────────────────────┘
```

### 3.1 Tier 1: Biological Eligibility Gating
Let $\mathcal{C} = \{c_1, c_2, \dots, c_{19}\}$ be the 19 canonical crops. For an input query $\mathbf{x}$, each candidate crop $c$ is evaluated across five biological survival gates:

1. **Season Gate**:
   $$\mathcal{G}_{\text{season}}(c, \mathbf{x}) = \begin{cases} \text{PASS} & \text{if } \mathbf{x}.\text{cultivation\_season} \in c.\text{supported\_seasons} \\ \text{FAIL} & \text{otherwise} \end{cases}$$
2. **Thermal Emergence Gate**:
   Evaluates sowing-stage temperature against germination survival bounds:
   $$\mathcal{G}_{\text{thermal}}(c, \mathbf{x}) = \begin{cases} \text{PASS} & \text{if } c.T_{\text{sow\_min}} \le \mathbf{x}.T_{\text{sow\_mean}} \le c.T_{\text{sow\_max}} \\ \text{FAIL} & \text{otherwise} \end{cases}$$
   *(Note: Flowering heat thresholds such as Rice >38°C or Maize >40°C are evaluated as Tier 2 soft penalties or UI warnings, NOT as sowing-stage hard exclusions).*
3. **Soil Texture Whitelist Gate**:
   $$\mathcal{G}_{\text{soil}}(c, \mathbf{x}) = \begin{cases} \text{PASS} & \text{if } \mathbf{x}.\text{soil\_texture} \in c.\text{compatible\_soils} \\ \text{FAIL} & \text{otherwise} \end{cases}$$
4. **Soil pH Survival Gate**:
   $$\mathcal{G}_{\text{pH}}(c, \mathbf{x}) = \begin{cases} \text{PASS} & \text{if } (c.\text{pH}_{\min} - 0.5) \le \mathbf{x}.\text{soil\_ph} \le (c.\text{pH}_{\max} + 0.5) \\ \text{FAIL} & \text{otherwise} \end{cases}$$
5. **Water Sufficiency Gate**:
   - If rainfed (`irrigation_access = 'None_Rainfed'`):
     $$\mathcal{G}_{\text{water}}(c, \mathbf{x}) = \begin{cases} \text{PASS} & \text{if } \mathbf{x}.R_{\text{seasonal}} \ge c.\text{min\_seasonal\_water\_mm} \\ \text{FAIL} & \text{otherwise} \end{cases}$$
   - If irrigation access exists and volume is measured:
     $$\mathcal{G}_{\text{water}}(c, \mathbf{x}) = \begin{cases} \text{PASS} & \text{if } (\mathbf{x}.R_{\text{seasonal}} + \mathbf{x}.I_{\text{quantity\_mm}}) \ge c.\text{min\_seasonal\_water\_mm} \\ \text{FAIL} & \text{otherwise} \end{cases}$$
   - If irrigation access exists but volume is unmeasured:
     $$\mathcal{G}_{\text{water}}(c, \mathbf{x}) = \begin{cases} \text{PASS} & \text{if } \mathbf{x}.R_{\text{seasonal}} \ge c.\text{min\_seasonal\_water\_mm} \\ \text{UNKNOWN} & \text{otherwise} \end{cases}$$

---

## 4. Rigorous Clarifications on Scoring Behavior (Phase 3C.4.1)

### 4.1 How UNKNOWN Eligibility Affects Recommendation Status
When a rule evaluates to **`UNKNOWN`** (e.g. water sufficiency cannot be established because rainfall is low and irrigation depth is unmeasured):
1. **Never Assume Pass or Fail**: The system MUST NOT guess that the crop passes or fails.
2. **Eligibility Classification**: The crop is assigned status **`CONDITIONALLY_ELIGIBLE_WITH_UNKNOWN_RISK`** or **`PROVISIONAL_EVALUATION`**.
3. **Certainty Restriction**: The crop is disqualified from receiving a `HIGH_CONFIDENCE` recommendation badge. Its maximum allowable confidence tier is `MODERATE_ESTIMATED` or `PROVISIONAL`.
4. **Transparent Audit Logging**: The UI and API must explicitly surface the unverified parameter so the extension worker or farmer knows exactly what ground verification is required.

### 4.2 How Missing Components Affect Geometric Scoring
When an optional or conditional input is missing (e.g. farmer does not have a laboratory Soil Health Card test):
1. **Neutral Baseline Assignment**: The missing component is assigned a neutral baseline score ($s_{\text{nutrients}} = 70.0$, representing average regional soil fertility).
2. **Data Completeness Index (DCI)**: The engine computes a formal Data Completeness Index tracking the proportion of weight derived from measured data:
   $$DCI = \frac{\sum_{i \in \text{Measured}} w_i}{\sum_{j \in \text{All}} w_j} \in (0, 1]$$
   - When all inputs (Climate, Measured Water, Soil Texture, pH, Laboratory NPK) are present: $DCI = 1.00$.
   - When Soil Health Card NPK is missing: $DCI = 0.90$.
   - When both NPK and diurnal temperature range are missing: $DCI = 0.80$.
   - When irrigation volume is unmeasured: $DCI$ is capped at $0.75$.

### 4.3 Absolute Non-Comparability of Scores with Missing Inputs
**CRITICAL GOVERNANCE PRINCIPLE**: Scores generated with different sets of missing inputs are **NOT directly comparable**!
- A crop evaluated with complete laboratory soil tests and measured rainfall has a score reflecting true, verified agronomic suitability.
- A crop evaluated with missing soil nutrients receives an imputed score floor ($s_{\text{nutrients}} = 70.0$), which artificially props up its geometric mean.
- Sorting a fully-measured candidate against an imputed candidate on a single naive score ladder produces invalid rankings.
- **Architectural Remedy**: The UI and API must segregate recommendations by Data Completeness Tier or display the 2D tuple `[Suitability Score, Evidence Confidence Tier]` rather than presenting a collapsed, misleading single leaderboard.

### 4.4 Displaying Evidence Confidence Separately from Suitability
The redesigned interface enforces strict two-dimensional reporting:
1. **Agronomic Suitability Index (0–100)**: Evaluates the physiological match of the crop to the environmental parameters.
2. **Evidence Confidence Tier**: Displayed as an independent, prominent status badge:
   - `HIGH_CONFIDENCE`: $DCI \ge 0.90$, all Tier 1 gates definitively verified with primary ICAR/FAO experimental data.
   - `MODERATE_ESTIMATED`: $0.70 \le DCI < 0.90$, secondary regional package of practices or qualitative soil assessment used.
   - `PROVISIONAL_UNMEASURED`: $DCI < 0.70$ or critical water volume unmeasured.

### 4.5 Boundary: NO_RECOMMENDATION_SUITABLE versus INSUFFICIENT_DATA
The engine establishes a sharp, deterministic distinction between why a recommendation cannot be made:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ 1. NO_RECOMMENDATION_SUITABLE                                               │
│    - Trigger: Valid, complete data was provided by the user.                │
│    - Cause: All 19 canonical crops failed Tier 1 biological gating or       │
│      fell below the minimum viability threshold (Score < 40.0).             │
│    - Agronomic Meaning: Hostile agricultural environment (e.g. 48°C desert  │
│      summer drought with 30 mm rain; sodic soil pH 9.5; toxic acidity pH 3.8│
│    - System Behavior: Refuses to recommend any crop; protects the farmer    │
│      from catastrophic financial loss; outputs land reclamation advice.     │
├─────────────────────────────────────────────────────────────────────────────┤
│ 2. INSUFFICIENT_DATA                                                        │
│    - Trigger: Missing, contradictory, or uninterpretable input values.      │
│    - Cause: Mandatory parameters missing (e.g. missing sowing month;        │
│      low rainfall with completely unstated irrigation access).              │
│    - Agronomic Meaning: Engine cannot determine biological feasibility.     │
│    - System Behavior: Execution halted at the validation gateway; prompts   │
│      the user to provide the necessary agricultural parameters.             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.6 Prohibition of Calling Heuristic Scores "Calibrated Probabilities"
The geometric suitability score is an agronomic multi-criteria index calculated from Liebig limiting factors and Gaussian environmental distances.
- It is **NOT** a posterior probability distribution $P(\text{Crop } c \mid \mathbf{x})$.
- It **MUST NEVER** be labeled as "Probability of Success: 85%" or "Calibrated Model Confidence: 92%".
- In all user interfaces, API documentation, and reports, it must strictly be designated:
  $$\textbf{Agronomic Suitability Index (0–100)}$$

---

## 5. Mathematical Aggregation Formulae (Preserved)

For crops passing Tier 1 gating, suitability is computed across five component scores:
1. **Climate Suitability ($s_{\text{climate}} \in [0, 100]$)**:
   $$s_{\text{climate}}(c, \mathbf{x}) = 60 \cdot \exp\left(-\frac{\Delta_T^2}{2\sigma_T^2}\right) + 40 \cdot \exp\left(-\frac{\Delta_H^2}{2\sigma_H^2}\right)$$
2. **Water Adequacy ($s_{\text{water}} \in [0, 100]$)**:
   $$s_{\text{water}}(c, \mathbf{x}) = \begin{cases} 
   100 & \text{if } W \ge c.\text{optimal\_water\_mm} \\
   100 \cdot \left(\frac{W - c.\text{min\_water\_mm}}{c.\text{optimal\_water\_mm} - c.\text{min\_water\_mm}}\right)^{0.75} & \text{if } c.\text{min\_water} \le W < c.\text{optimal\_water}
   \end{cases}$$
3. **Edaphic Texture Suitability ($s_{\text{soil}} \in [0, 100]$)**:
   - Primary optimal texture: $100\text{ points}$.
   - Secondary acceptable texture: $75\text{ points}$.
   - Marginal texture: $50\text{ points}$.
4. **Soil Fertility Alignment ($s_{\text{nutrients}} \in [0, 100]$)**:
   - Evaluated against DAC&FW Low/Medium/High fertility limits.
   - Missing soil test fallback: $70.0\text{ points}$ with $DCI$ reduction.
5. **Soil Reaction ($s_{\text{ph}} \in [0, 100]$)**:
   - Within preferred range $[c.\text{pH}_{\min}, c.\text{pH}_{\max}]$: $100\text{ points}$.
   - Within buffer $[c.\text{pH}_{\min}-0.5, c.\text{pH}_{\min})$ or $(c.\text{pH}_{\max}, c.\text{pH}_{\max}+0.5]$: Linear decay from $100$ down to $50\text{ points}$.

### 5.1 Non-Compensatory Liebig Aggregation
$$\text{CoreSuitability}(c, \mathbf{x}) = s_{\text{climate}}^{0.30} \cdot s_{\text{water}}^{0.30} \cdot s_{\text{soil}}^{0.20} \cdot s_{\text{nutrients}}^{0.10} \cdot s_{\text{ph}}^{0.10}$$

$$\text{LiebigPenaltyFactor}(c, \mathbf{x}) = \left( \frac{\min(s_{\text{climate}}, s_{\text{water}}, s_{\text{soil}}, s_{\text{ph}})}{100} \right)^{0.25}$$

$$\text{SuitabilityIndex}(c, \mathbf{x}) = \text{CoreSuitability}(c, \mathbf{x}) \times \text{LiebigPenaltyFactor}(c, \mathbf{x})$$

The Liebig factor ensures that if any physical component is marginal (e.g. $s_{\text{water}} = 40$), the overall suitability is penalized non-linearly, preventing high fertility or ideal temperature from masking acute moisture deficit.
