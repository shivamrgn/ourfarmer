#!/usr/bin/env python3
"""
Comprehensive Builder for Phase 3C.4 Deliverables
Generates:
  - reports/phase_3c_4_eligibility_rules.csv
  - reports/phase_3c_4_canonical_crop_catalogue.csv
  - reports/phase_3c_4_source_evidence_gaps.csv
  - reports/phase_3c_4_acceptance_test_matrix.csv
"""

import csv
import json
from pathlib import Path

REPORTS_DIR = Path('/Users/shivamkumar/farmingFinal/FieldWise_main/model/ml_pipeline/reports')

# ==============================================================================
# 1. ELIGIBILITY RULES
# ==============================================================================
def build_eligibility_rules():
    fieldnames = [
        "crop_id",
        "canonical_name",
        "constraint_dimension",
        "rule_identifier",
        "rule_description",
        "rule_type",
        "threshold_operator",
        "threshold_value",
        "unit",
        "evidence_classification",
        "source_id",
        "action_on_violation",
        "override_permitted"
    ]

    rules = [
        # --- RICE ---
        ("rice", "Rice (Paddy)", "cultivation_season", "RULE-RICE-SEAS-01", "Cultivation season must be Kharif (main crop) or Boro/Summer (with standing water)", "Hard Exclusion", "in", "['Kharif', 'Annual', 'Zaid']", "Season Category", "A", "SRC-IIRR-02", "Exclude Candidate", "False"),
        ("rice", "Rice (Paddy)", "thermal_limits", "RULE-RICE-TEMP-01", "Mean temperature must exceed 18°C for germination and active tillering", "Hard Exclusion", ">=", "18.0", "°C", "A", "SRC-IIRR-02", "Exclude Candidate", "False"),
        ("rice", "Rice (Paddy)", "thermal_limits", "RULE-RICE-TEMP-02", "Floret sterility induced when flowering temperature exceeds 38°C", "Soft Penalty", "<=", "38.0", "°C", "A", "SRC-IIRR-02", "Penalize Score 30%", "True"),
        ("rice", "Rice (Paddy)", "water_availability", "RULE-RICE-WAT-01", "Minimum effective seasonal water requirement for puddled transplanting is 800 mm", "Hard Exclusion", ">=", "800.0", "mm", "A", "SRC-FAO56-20", "Exclude Candidate", "False"),
        ("rice", "Rice (Paddy)", "soil_texture", "RULE-RICE-SOIL-01", "Coarse unpuddled sand causes excessive percolation loss and seedling desiccation", "Hard Exclusion", "not in", "['Sandy']", "Texture Class", "A", "SRC-IIRR-02", "Exclude Candidate", "False"),
        ("rice", "Rice (Paddy)", "soil_ph", "RULE-RICE-PH-01", "Extreme sodic or acidic soils inhibit rice root development and nutrient uptake", "Hard Exclusion", "between", "[4.8, 8.5]", "pH", "A", "SRC-ICAR-01", "Exclude Candidate", "False"),
        ("rice", "Rice (Paddy)", "irrigation_requirement", "RULE-RICE-IRR-01", "Rainfed cultivation requires minimum 1000 mm rainfall; otherwise assured irrigation is mandatory", "Hard Exclusion", "conditional", "Rainfall >= 1000 or Irrigation == Assured", "Water Regime", "A", "SRC-IIRR-02", "Exclude Candidate", "False"),

        # --- WHEAT ---
        ("wheat", "Wheat", "cultivation_season", "RULE-WHEAT-SEAS-01", "Wheat is strictly a Rabi winter cereal; sowing in Kharif monsoon heat results in zero vernalization", "Hard Exclusion", "in", "['Rabi']", "Season Category", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),
        ("wheat", "Wheat", "thermal_limits", "RULE-WHEAT-TEMP-01", "Sowing temperature must not exceed 28°C; excessive heat destroys seedling emergence", "Hard Exclusion", "<=", "28.0", "°C", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),
        ("wheat", "Wheat", "thermal_limits", "RULE-WHEAT-TEMP-02", "Vegetative growth requires minimum temperature above 5°C to avoid severe freezing injury", "Hard Exclusion", ">=", "5.0", "°C", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),
        ("wheat", "Wheat", "water_availability", "RULE-WHEAT-WAT-01", "Minimum effective crop water requirement across winter cycle is 250 mm", "Hard Exclusion", ">=", "250.0", "mm", "A", "SRC-FAO56-20", "Exclude Candidate", "False"),
        ("wheat", "Wheat", "soil_texture", "RULE-WHEAT-SOIL-01", "Poorly drained heavy clay prone to waterlogging causes foot rot and root asphyxiation", "Soft Penalty", "not in", "['Heavy Clay']", "Texture Class", "A", "SRC-IIWBR-03", "Penalize Score 40%", "True"),
        ("wheat", "Wheat", "soil_ph", "RULE-WHEAT-PH-01", "Highly acidic soils cause aluminum toxicity; wheat requires pH between 5.5 and 8.3", "Hard Exclusion", "between", "[5.5, 8.3]", "pH", "A", "SRC-ICAR-01", "Exclude Candidate", "False"),
        ("wheat", "Wheat", "irrigation_requirement", "RULE-WHEAT-IRR-01", "In NW plains (rainfall < 150mm), at least 3-4 irrigations are required for viable commercial yield", "Hard Exclusion", "conditional", "Rainfall >= 250 or Irrigation in ['Partially_Irrigated_Protective', 'Assured_Irrigation']", "Water Regime", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),

        # --- MAIZE ---
        ("maize", "Maize (Corn)", "cultivation_season", "RULE-MAIZE-SEAS-01", "Cultivated primarily in Kharif, but also Rabi (Bihar/Karnataka) and Spring (Punjab)", "Hard Exclusion", "in", "['Kharif', 'Rabi', 'Zaid']", "Season Category", "A", "SRC-IIMR-04", "Exclude Candidate", "False"),
        ("maize", "Maize (Corn)", "thermal_limits", "RULE-MAIZE-TEMP-01", "Pollen desiccation and silk drying occur when temperature exceeds 40°C during flowering", "Hard Exclusion", "<=", "40.0", "°C", "A", "SRC-IIMR-04", "Exclude Candidate", "False"),
        ("maize", "Maize (Corn)", "thermal_limits", "RULE-MAIZE-TEMP-02", "Germination ceases below 10°C; frost susceptible", "Hard Exclusion", ">=", "10.0", "°C", "A", "SRC-IIMR-04", "Exclude Candidate", "False"),
        ("maize", "Maize (Corn)", "water_availability", "RULE-MAIZE-WAT-01", "Minimum effective seasonal water requirement is 400 mm", "Hard Exclusion", ">=", "400.0", "mm", "A", "SRC-FAO56-20", "Exclude Candidate", "False"),
        ("maize", "Maize (Corn)", "soil_texture", "RULE-MAIZE-SOIL-01", "Maize cannot tolerate standing water; water stagnation in heavy clay kills plants within 48h", "Soft Penalty", "in", "['Sandy Loam', 'Loamy', 'Alluvial', 'Clay Loam']", "Texture Class", "A", "SRC-IIMR-04", "Penalize Score 40%", "True"),
        ("maize", "Maize (Corn)", "soil_ph", "RULE-MAIZE-PH-01", "Soil pH must be between 5.5 and 7.8", "Hard Exclusion", "between", "[5.5, 7.8]", "pH", "A", "SRC-ICAR-01", "Exclude Candidate", "False"),

        # --- COTTON ---
        ("cotton", "Cotton", "cultivation_season", "RULE-COTTON-SEAS-01", "Cotton is a long-duration Kharif crop (150-180 days)", "Hard Exclusion", "in", "['Kharif']", "Season Category", "A", "SRC-CICR-05", "Exclude Candidate", "False"),
        ("cotton", "Cotton", "thermal_limits", "RULE-COTTON-TEMP-01", "Vegetative growth ceases below 16°C; frost is immediately lethal", "Hard Exclusion", ">=", "16.0", "°C", "A", "SRC-CICR-05", "Exclude Candidate", "False"),
        ("cotton", "Cotton", "water_availability", "RULE-COTTON-WAT-01", "Minimum seasonal water requirement for rainfed/irrigated cotton is 500 mm", "Hard Exclusion", ">=", "500.0", "mm", "A", "SRC-CICR-05", "Exclude Candidate", "False"),
        ("cotton", "Cotton", "soil_texture", "RULE-COTTON-SOIL-01", "Thrives in deep black Vertisols, alluvial and deep loamy soils; unsuited to shallow desert sands", "Hard Exclusion", "not in", "['Sandy']", "Texture Class", "A", "SRC-CICR-05", "Exclude Candidate", "False"),
        ("cotton", "Cotton", "soil_ph", "RULE-COTTON-PH-01", "Cotton tolerates moderate alkalinity up to pH 8.5 in black soils; acid soils < 5.8 require liming", "Hard Exclusion", "between", "[5.8, 8.5]", "pH", "A", "SRC-CICR-05", "Exclude Candidate", "False"),

        # --- SUGARCANE ---
        ("sugarcane", "Sugarcane", "cultivation_season", "RULE-SUGAR-SEAS-01", "Sugarcane is an Annual/Perennial crop occupying fields for 10-18 months", "Hard Exclusion", "in", "['Annual', 'Kharif', 'Rabi']", "Season Category", "A", "SRC-IISR-06", "Exclude Candidate", "False"),
        ("sugarcane", "Sugarcane", "thermal_limits", "RULE-SUGAR-TEMP-01", "Bud sprouting stops below 14°C; severe frost destroys terminal growing point", "Hard Exclusion", ">=", "14.0", "°C", "A", "SRC-IISR-06", "Exclude Candidate", "False"),
        ("sugarcane", "Sugarcane", "water_availability", "RULE-SUGAR-WAT-01", "CRITICAL WATER REQUIREMENT: Minimum 1200 mm effective water across 12-month duration", "Hard Exclusion", ">=", "1200.0", "mm", "A", "SRC-IISR-06", "Exclude Candidate", "False"),
        ("sugarcane", "Sugarcane", "soil_texture", "RULE-SUGAR-SOIL-01", "Requires deep fertile soils (loam, clay loam, heavy black, alluvial) with high water retention", "Hard Exclusion", "not in", "['Sandy', 'Red Sandy']", "Texture Class", "A", "SRC-IISR-06", "Exclude Candidate", "False"),
        ("sugarcane", "Sugarcane", "soil_ph", "RULE-SUGAR-PH-01", "Optimal pH 6.5–7.8; tolerates 6.0–8.2", "Hard Exclusion", "between", "[6.0, 8.2]", "pH", "A", "SRC-IISR-06", "Exclude Candidate", "False"),
        ("sugarcane", "Sugarcane", "irrigation_requirement", "RULE-SUGAR-IRR-01", "Sugarcane CANNOT be grown under pure rainfed conditions in semi-arid zones (< 1000mm rain)", "Hard Exclusion", "conditional", "Rainfall >= 1400 or Irrigation == Assured", "Water Regime", "A", "SRC-IISR-06", "Exclude Candidate", "False"),

        # --- SOYBEAN ---
        ("soybean", "Soybean", "cultivation_season", "RULE-SOY-SEAS-01", "Soybean is strictly a Kharif monsoon crop in Central India", "Hard Exclusion", "in", "['Kharif']", "Season Category", "A", "SRC-IISR-SOY-07", "Exclude Candidate", "False"),
        ("soybean", "Soybean", "thermal_limits", "RULE-SOY-TEMP-01", "Germination delayed below 15°C; flower abortion and pod drop exceed 50% at temperatures > 38°C", "Hard Exclusion", "between", "[15.0, 38.0]", "°C", "A", "SRC-IISR-SOY-07", "Exclude Candidate", "False"),
        ("soybean", "Soybean", "water_availability", "RULE-SOY-WAT-01", "Minimum seasonal rainfall requirement is 450 mm", "Hard Exclusion", ">=", "450.0", "mm", "A", "SRC-IISR-SOY-07", "Exclude Candidate", "False"),
        ("soybean", "Soybean", "soil_texture", "RULE-SOY-SOIL-01", "Grown predominantly on deep black Vertisols and well-drained loams; fails on coarse sand", "Hard Exclusion", "not in", "['Sandy']", "Texture Class", "A", "SRC-IISR-SOY-07", "Exclude Candidate", "False"),
        ("soybean", "Soybean", "soil_ph", "RULE-SOY-PH-01", "Symbiotic nitrogen fixation via Bradyrhizobium japonicum collapses below pH 5.8 or above 8.2", "Hard Exclusion", "between", "[5.8, 8.2]", "pH", "A", "SRC-IISR-SOY-07", "Exclude Candidate", "False"),

        # --- GROUNDNUT ---
        ("groundnut", "Groundnut (Peanut)", "cultivation_season", "RULE-GND-SEAS-01", "Cultivated in Kharif (rainfed) or Rabi/Summer (irrigated)", "Hard Exclusion", "in", "['Kharif', 'Rabi', 'Zaid']", "Season Category", "A", "SRC-DGR-08", "Exclude Candidate", "False"),
        ("groundnut", "Groundnut (Peanut)", "thermal_limits", "RULE-GND-TEMP-01", "Soil temperature must exceed 20°C for effective pod development and pegging", "Hard Exclusion", ">=", "18.0", "°C", "A", "SRC-DGR-08", "Exclude Candidate", "False"),
        ("groundnut", "Groundnut (Peanut)", "water_availability", "RULE-GND-WAT-01", "Minimum water requirement is 400 mm", "Hard Exclusion", ">=", "400.0", "mm", "A", "SRC-DGR-08", "Exclude Candidate", "False"),
        ("groundnut", "Groundnut (Peanut)", "soil_texture", "RULE-GND-SOIL-01", "CRITICAL TEXTURE RULE: Requires loose friable sandy loam; heavy clay causes peg breakage and harvest loss", "Hard Exclusion", "in", "['Sandy Loam', 'Red Sandy', 'Loamy', 'Alluvial']", "Texture Class", "A", "SRC-DGR-08", "Exclude Candidate", "False"),
        ("groundnut", "Groundnut (Peanut)", "soil_ph", "RULE-GND-PH-01", "Alkaline sodic soil (pH > 8.0) causes complete lime-induced iron chlorosis and pod rot", "Hard Exclusion", "between", "[5.5, 8.0]", "pH", "A", "SRC-DGR-08", "Exclude Candidate", "False"),

        # --- POTATO ---
        ("potato", "Potato", "cultivation_season", "RULE-POT-SEAS-01", "Winter Rabi crop in plains; spring/summer in temperate hills", "Hard Exclusion", "in", "['Rabi']", "Season Category", "A", "SRC-CPRI-09", "Exclude Candidate", "False"),
        ("potato", "Potato", "thermal_limits", "RULE-POT-TEMP-01", "CRITICAL TUBERIZATION LIMIT: Tuber formation severely inhibited at night temp > 20°C and ceases > 25°C", "Hard Exclusion", "<=", "25.0", "°C", "A", "SRC-CPRI-09", "Exclude Candidate", "False"),
        ("potato", "Potato", "water_availability", "RULE-POT-WAT-01", "Requires 350-500 mm water through frequent light irrigations", "Hard Exclusion", ">=", "300.0", "mm", "A", "SRC-CPRI-09", "Exclude Candidate", "False"),
        ("potato", "Potato", "soil_texture", "RULE-POT-SOIL-01", "Heavy compact clay obstructs tuber enlargement, causing misshapen tubers and poor aeration", "Hard Exclusion", "not in", "['Clay', 'Heavy Clay']", "Texture Class", "A", "SRC-CPRI-09", "Exclude Candidate", "False"),
        ("potato", "Potato", "soil_ph", "RULE-POT-PH-01", "Prefers slightly acidic soil (pH 5.0–6.5); alkaline pH > 7.5 triggers common scab (Streptomyces scabies)", "Soft Penalty", "between", "[5.0, 7.5]", "pH", "A", "SRC-CPRI-09", "Penalize Score 50%", "True"),

        # --- CHICKPEA ---
        ("chickpea", "Chickpea (Gram)", "cultivation_season", "RULE-CHK-SEAS-01", "Winter Rabi pulse; cannot be sown in Kharif monsoon", "Hard Exclusion", "in", "['Rabi']", "Season Category", "A", "SRC-IIPR-10", "Exclude Candidate", "False"),
        ("chickpea", "Chickpea (Gram)", "thermal_limits", "RULE-CHK-TEMP-01", "Flowering heat stress > 32°C causes excessive pod drop and flower abortion", "Hard Exclusion", "<=", "32.0", "°C", "A", "SRC-IIPR-10", "Exclude Candidate", "False"),
        ("chickpea", "Chickpea (Gram)", "water_availability", "RULE-CHK-WAT-01", "Excess water causes collar rot and root rot; seasonal water should be 200–450 mm", "Soft Penalty", "<=", "500.0", "mm", "A", "SRC-IIPR-10", "Penalize Score 40%", "True"),
        ("chickpea", "Chickpea (Gram)", "soil_texture", "RULE-CHK-SOIL-01", "Well-drained soils; sensitive to waterlogging", "Hard Exclusion", "not in", "['Waterlogged Clay']", "Texture Class", "A", "SRC-IIPR-10", "Exclude Candidate", "False"),
        ("chickpea", "Chickpea (Gram)", "soil_ph", "RULE-CHK-PH-01", "Alkaline sodic soil (pH > 8.5) stops Rhizobium nodulation", "Hard Exclusion", "between", "[5.8, 8.4]", "pH", "A", "SRC-IIPR-10", "Exclude Candidate", "False"),

        # --- LENTIL ---
        ("lentil", "Lentil (Masoor)", "cultivation_season", "RULE-LNT-SEAS-01", "Strictly Rabi winter pulse", "Hard Exclusion", "in", "['Rabi']", "Season Category", "A", "SRC-IIPR-10", "Exclude Candidate", "False"),
        ("lentil", "Lentil (Masoor)", "thermal_limits", "RULE-LNT-TEMP-01", "Cold hardy (tolerates down to 5°C); heat sensitive > 28°C", "Hard Exclusion", "<=", "28.0", "°C", "A", "SRC-IIPR-10", "Exclude Candidate", "False"),
        ("lentil", "Lentil (Masoor)", "water_availability", "RULE-LNT-WAT-01", "Drought tolerant (180–350 mm); highly sensitive to waterlogging and flooding", "Hard Exclusion", "<=", "450.0", "mm", "A", "SRC-IIPR-10", "Exclude Candidate", "False"),
        ("lentil", "Lentil (Masoor)", "soil_ph", "RULE-LNT-PH-01", "Acid soils < 5.8 cause molybdenum deficiency; alkaline > 8.2 cause iron chlorosis", "Hard Exclusion", "between", "[5.8, 8.2]", "pH", "A", "SRC-IIPR-10", "Exclude Candidate", "False"),

        # --- MUSTARD ---
        ("mustard", "Mustard (Rapeseed)", "cultivation_season", "RULE-MUST-SEAS-01", "Strictly Rabi winter oilseed (sown Sept 25 - Oct 20)", "Hard Exclusion", "in", "['Rabi']", "Season Category", "A", "SRC-DRMR-11", "Exclude Candidate", "False"),
        ("mustard", "Mustard (Rapeseed)", "thermal_limits", "RULE-MUST-TEMP-01", "Sowing temp > 28°C causes seedling mortality; frost at podding destroys siliqua", "Hard Exclusion", "<=", "28.0", "°C", "A", "SRC-DRMR-11", "Exclude Candidate", "False"),
        ("mustard", "Mustard (Rapeseed)", "water_availability", "RULE-MUST-WAT-01", "Water requirement 250–400 mm; sensitive to water stagnation", "Hard Exclusion", "<=", "500.0", "mm", "A", "SRC-DRMR-11", "Exclude Candidate", "False"),
        ("mustard", "Mustard (Rapeseed)", "soil_ph", "RULE-MUST-PH-01", "Optimal pH 6.0–7.5; tolerates 5.5–8.2", "Hard Exclusion", "between", "[5.5, 8.2]", "pH", "A", "SRC-DRMR-11", "Exclude Candidate", "False"),

        # --- TOMATO ---
        ("tomato", "Tomato", "cultivation_season", "RULE-TOM-SEAS-01", "Multi-season vegetable in frost-free regions; winter in plains", "Hard Exclusion", "in", "['Rabi', 'Zaid', 'Kharif', 'Annual']", "Season Category", "A", "SRC-IIHR-12", "Exclude Candidate", "False"),
        ("tomato", "Tomato", "thermal_limits", "RULE-TOM-TEMP-01", "Fruit set completely fails above 34°C day temp or below 12°C night temp", "Hard Exclusion", "between", "[12.0, 34.0]", "°C", "A", "SRC-IIHR-12", "Exclude Candidate", "False"),
        ("tomato", "Tomato", "water_availability", "RULE-TOM-WAT-01", "Requires regular, uniform moisture (400–600 mm); water stress induces blossom-end rot", "Hard Exclusion", ">=", "350.0", "mm", "A", "SRC-IIHR-12", "Exclude Candidate", "False"),
        ("tomato", "Tomato", "soil_texture", "RULE-TOM-SOIL-01", "Requires well-drained loams rich in organic matter; root rot in waterlogged clay", "Soft Penalty", "in", "['Sandy Loam', 'Loamy', 'Red Sandy', 'Alluvial', 'Clay Loam']", "Texture Class", "A", "SRC-IIHR-12", "Penalize Score 40%", "True"),
        ("tomato", "Tomato", "soil_ph", "RULE-TOM-PH-01", "Prefers slightly acidic to neutral soil (pH 6.0–7.0); tolerates 5.5–7.8", "Hard Exclusion", "between", "[5.5, 7.8]", "pH", "A", "SRC-IIHR-12", "Exclude Candidate", "False"),

        # --- ONION ---
        ("onion", "Onion", "cultivation_season", "RULE-ONI-SEAS-01", "Grown in Rabi (main crop), Kharif, and Late Kharif", "Hard Exclusion", "in", "['Rabi', 'Kharif', 'Annual']", "Season Category", "A", "SRC-IIHR-12", "Exclude Candidate", "False"),
        ("onion", "Onion", "thermal_limits", "RULE-ONI-TEMP-01", "Bulbing requires 20–30°C; heat > 35°C accelerates premature bolting and sunscald", "Hard Exclusion", "<=", "34.0", "°C", "A", "SRC-IIHR-12", "Exclude Candidate", "False"),
        ("onion", "Onion", "water_availability", "RULE-ONI-WAT-01", "Requires 350–550 mm water via frequent light irrigations; water stagnation rots bulbs", "Hard Exclusion", ">=", "300.0", "mm", "A", "SRC-IIHR-12", "Exclude Candidate", "False"),
        ("onion", "Onion", "soil_texture", "RULE-ONI-SOIL-01", "Heavy clay causes deformed, split bulbs and difficult harvesting", "Soft Penalty", "in", "['Sandy Loam', 'Loamy', 'Alluvial', 'Clay Loam']", "Texture Class", "A", "SRC-IIHR-12", "Penalize Score 40%", "True"),
        ("onion", "Onion", "soil_ph", "RULE-ONI-PH-01", "Highly sensitive to acidity; fails completely at pH < 5.8", "Hard Exclusion", "between", "[5.8, 7.8]", "pH", "A", "SRC-IIHR-12", "Exclude Candidate", "False"),

        # --- BANANA ---
        ("banana", "Banana", "cultivation_season", "RULE-BAN-SEAS-01", "Perennial/Annual crop (11-14 months duration); tropical/subtropical only", "Hard Exclusion", "in", "['Annual', 'Kharif']", "Season Category", "A", "SRC-NRCB-13", "Exclude Candidate", "False"),
        ("banana", "Banana", "thermal_limits", "RULE-BAN-TEMP-01", "Chilling injury occurs below 14°C; frost is immediately fatal; growth ceases > 38°C", "Hard Exclusion", "between", "[14.0, 38.0]", "°C", "A", "SRC-NRCB-13", "Exclude Candidate", "False"),
        ("banana", "Banana", "water_availability", "RULE-BAN-WAT-01", "CRITICAL WATER CONSUMER: Minimum 1400 mm effective water across growth cycle", "Hard Exclusion", ">=", "1400.0", "mm", "A", "SRC-NRCB-13", "Exclude Candidate", "False"),
        ("banana", "Banana", "soil_texture", "RULE-BAN-SOIL-01", "Requires deep fertile alluvial, clay loam or loamy soil with minimum 1m rooting depth", "Hard Exclusion", "not in", "['Sandy', 'Shallow Rocky']", "Texture Class", "A", "SRC-NRCB-13", "Exclude Candidate", "False"),
        ("banana", "Banana", "soil_ph", "RULE-BAN-PH-01", "Optimal pH 6.0–7.5; highly sensitive to salinity and sodicity (pH > 8.0)", "Hard Exclusion", "between", "[5.8, 8.0]", "pH", "A", "SRC-NRCB-13", "Exclude Candidate", "False"),
        ("banana", "Banana", "irrigation_requirement", "RULE-BAN-IRR-01", "Cannot be grown rainfed outside humid tropical belts (>1800mm rain); requires assured irrigation", "Hard Exclusion", "conditional", "Rainfall >= 1800 or Irrigation == Assured", "Water Regime", "A", "SRC-NRCB-13", "Exclude Candidate", "False"),

        # --- MANGO ---
        ("mango", "Mango", "cultivation_season", "RULE-MNG-SEAS-01", "Perennial orchard fruit tree (long-term investment)", "Hard Exclusion", "in", "['Annual', 'Zaid', 'Summer']", "Season Category", "A", "SRC-CISH-14", "Exclude Candidate", "False"),
        ("mango", "Mango", "thermal_limits", "RULE-MNG-TEMP-01", "Frost sensitive; young trees killed at < 2°C; flowering requires 15–25°C", "Hard Exclusion", ">=", "5.0", "°C", "A", "SRC-CISH-14", "Exclude Candidate", "False"),
        ("mango", "Mango", "water_availability", "RULE-MNG-WAT-01", "Annual rainfall 750–1500 mm; rain during flowering triggers blossom anthracnose", "Soft Penalty", "between", "[500.0, 2000.0]", "mm", "A", "SRC-CISH-14", "Penalize Score 30%", "True"),
        ("mango", "Mango", "soil_texture", "RULE-MNG-SOIL-01", "Deep well-drained loamy/alluvial soil with water table below 2.5m; hard pan prevents taproot", "Hard Exclusion", "not in", "['Hard Pan Clay', 'Waterlogged Clay']", "Texture Class", "A", "SRC-CISH-14", "Exclude Candidate", "False"),
        ("mango", "Mango", "soil_ph", "RULE-MNG-PH-01", "Optimal pH 5.5–7.5; severe micronutrient necrosis and dieback in sodic soils > 8.2", "Hard Exclusion", "between", "[5.5, 8.2]", "pH", "A", "SRC-CISH-14", "Exclude Candidate", "False"),

        # --- JOWAR ---
        ("jowar", "Jowar (Sorghum)", "cultivation_season", "RULE-JOW-SEAS-01", "Grown in Kharif (monsoon grain) and Rabi (post-monsoon grain/fodder on Vertisols)", "Hard Exclusion", "in", "['Kharif', 'Rabi']", "Season Category", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),
        ("jowar", "Jowar (Sorghum)", "thermal_limits", "RULE-JOW-TEMP-01", "Drought and heat tolerant; germination ceases below 15°C; vegetative optimum 26–32°C", "Hard Exclusion", ">=", "15.0", "°C", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),
        ("jowar", "Jowar (Sorghum)", "water_availability", "RULE-JOW-WAT-01", "Drought hardy; minimum water requirement is 350 mm", "Hard Exclusion", ">=", "350.0", "mm", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),
        ("jowar", "Jowar (Sorghum)", "soil_texture", "RULE-JOW-SOIL-01", "Thrives on deep black Vertisols, clay loam, and alluvial soils", "Hard Exclusion", "not in", "['Coarse Desert Sand']", "Texture Class", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),
        ("jowar", "Jowar (Sorghum)", "soil_ph", "RULE-JOW-PH-01", "Tolerates moderate salinity and sodicity up to pH 8.3", "Hard Exclusion", "between", "[5.8, 8.3]", "pH", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),

        # --- SUNFLOWER ---
        ("sunflower", "Sunflower", "cultivation_season", "RULE-SUN-SEAS-01", "Day-neutral crop; can be cultivated across Kharif, Rabi, and Spring/Zaid", "Hard Exclusion", "in", "['Kharif', 'Rabi', 'Zaid', 'Annual']", "Season Category", "A", "SRC-IIOR-16", "Exclude Candidate", "False"),
        ("sunflower", "Sunflower", "thermal_limits", "RULE-SUN-TEMP-01", "High heat > 38°C during flowering causes sterile disc florets and low oil content", "Soft Penalty", "<=", "38.0", "°C", "A", "SRC-IIOR-16", "Penalize Score 30%", "True"),
        ("sunflower", "Sunflower", "water_availability", "RULE-SUN-WAT-01", "Minimum water requirement is 350 mm; sensitive at buttoning and flowering", "Hard Exclusion", ">=", "350.0", "mm", "A", "SRC-IIOR-16", "Exclude Candidate", "False"),
        ("sunflower", "Sunflower", "soil_texture", "RULE-SUN-SOIL-01", "Deep loamy, black Vertisols, and sandy loam; highly sensitive to water stagnation", "Soft Penalty", "in", "['Loamy', 'Black Vertisol', 'Sandy Loam', 'Alluvial']", "Texture Class", "A", "SRC-IIOR-16", "Penalize Score 40%", "True"),
        ("sunflower", "Sunflower", "soil_ph", "RULE-SUN-PH-01", "Tolerates pH 6.0–8.0; optimal 6.5–7.5", "Hard Exclusion", "between", "[6.0, 8.0]", "pH", "A", "SRC-IIOR-16", "Exclude Candidate", "False"),

        # --- BARLEY ---
        ("barley", "Barley", "cultivation_season", "RULE-BAR-SEAS-01", "Rabi winter cereal", "Hard Exclusion", "in", "['Rabi']", "Season Category", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),
        ("barley", "Barley", "thermal_limits", "RULE-BAR-TEMP-01", "Cool winter crop; high heat > 30°C terminates grain filling prematurely", "Hard Exclusion", "<=", "30.0", "°C", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),
        ("barley", "Barley", "water_availability", "RULE-BAR-WAT-01", "Most drought-tolerant winter cereal; minimum effective water is 200 mm", "Hard Exclusion", ">=", "200.0", "mm", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),
        ("barley", "Barley", "soil_texture", "RULE-BAR-SOIL-01", "Sandy loam, loamy, light alluvial", "Hard Exclusion", "not in", "['Waterlogged Clay']", "Texture Class", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),
        ("barley", "Barley", "soil_ph", "RULE-BAR-PH-01", "HIGHEST SALINITY/SODICITY TOLERANCE: Can grow in alkaline soils up to pH 8.8", "Hard Exclusion", "between", "[6.0, 8.8]", "pH", "A", "SRC-IIWBR-03", "Exclude Candidate", "False"),

        # --- MILLETS / BAJRA ---
        ("millets", "Bajra / Pearl Millet", "cultivation_season", "RULE-MIL-SEAS-01", "Kharif crop in arid/semi-arid zones; summer crop under irrigation", "Hard Exclusion", "in", "['Kharif', 'Zaid']", "Season Category", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),
        ("millets", "Bajra / Pearl Millet", "thermal_limits", "RULE-MIL-TEMP-01", "HIGHEST HEAT TOLERANCE: Vegetative growth thrives at 28–38°C; tolerates up to 42°C", "Hard Exclusion", ">=", "18.0", "°C", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),
        ("millets", "Bajra / Pearl Millet", "water_availability", "RULE-MIL-WAT-01", "Exceptional drought hardy; minimum effective water is 250 mm", "Hard Exclusion", ">=", "250.0", "mm", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),
        ("millets", "Bajra / Pearl Millet", "soil_texture", "RULE-MIL-SOIL-01", "Thrives on light sandy soils, desert soils, and red sandy loams; poorly adapted to heavy clay", "Soft Penalty", "in", "['Sandy', 'Sandy Loam', 'Red Sandy', 'Loamy']", "Texture Class", "A", "SRC-MILLET-15", "Penalize Score 30%", "True"),
        ("millets", "Bajra / Pearl Millet", "soil_ph", "RULE-MIL-PH-01", "Tolerates wide pH range (5.5 to 8.2)", "Hard Exclusion", "between", "[5.5, 8.2]", "pH", "A", "SRC-MILLET-15", "Exclude Candidate", "False"),
    ]

    out_path = REPORTS_DIR / "phase_3c_4_eligibility_rules.csv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(fieldnames)
        writer.writerows(rules)

    print(f"Generated {len(rules)} eligibility rules in {out_path.name}")
    return rules


# ==============================================================================
# 2. CANONICAL CROP CATALOGUE
# ==============================================================================
def build_canonical_catalogue():
    fieldnames = [
        "crop_id",
        "canonical_name",
        "accepted_aliases",
        "scientific_name",
        "family",
        "category",
        "supported_seasons",
        "supported_regions",
        "base_yield_irrigated_t_ha",
        "base_yield_rainfed_t_ha",
        "min_seasonal_water_mm",
        "optimal_seasonal_water_mm",
        "sowing_temp_min_c",
        "sowing_temp_max_c",
        "thermal_optimum_min_c",
        "thermal_optimum_max_c",
        "ph_min",
        "ph_max",
        "compatible_soils",
        "rdf_n_kg_ha",
        "rdf_p2o5_kg_ha",
        "rdf_k2o_kg_ha",
        "evidence_status",
        "recommendable_status"
    ]

    crops = [
        ("rice", "Rice (Paddy)", "Paddy; Dhan; Chawal", "Oryza sativa", "Poaceae", "Cereal", "Kharif; Boro; Summer", "West Bengal; Uttar Pradesh; Punjab; Andhra Pradesh; Tamil Nadu; Bihar; Odisha; Assam", 4.5, 2.2, 800, 1500, 20.0, 35.0, 22.0, 32.0, 5.0, 7.5, "Clay; Clay Loam; Alluvial; Heavy Loam", 120, 60, 60, "Verified", "Recommendable"),
        ("wheat", "Wheat", "Gehun; Kanak", "Triticum aestivum", "Poaceae", "Cereal", "Rabi", "Uttar Pradesh; Punjab; Haryana; Madhya Pradesh; Rajasthan; Bihar", 4.5, 1.8, 250, 450, 10.0, 25.0, 15.0, 22.0, 6.0, 7.8, "Loamy; Clay Loam; Sandy Loam; Alluvial", 120, 60, 40, "Verified", "Recommendable"),
        ("maize", "Maize (Corn)", "Corn; Makka; Bhutta", "Zea mays", "Poaceae", "Cereal", "Kharif; Rabi; Zaid", "Karnataka; Madhya Pradesh; Bihar; Tamil Nadu; Telangana; Rajasthan", 4.5, 2.5, 400, 650, 18.0, 32.0, 21.0, 30.0, 5.5, 7.5, "Sandy Loam; Loamy; Alluvial; Clay Loam", 150, 60, 50, "Verified", "Recommendable"),
        ("cotton", "Cotton", "Kapas; Rui", "Gossypium hirsutum", "Malvaceae", "Commercial Fiber", "Kharif", "Gujarat; Maharashtra; Telangana; Andhra Pradesh; Rajasthan; Haryana; Punjab", 2.2, 1.2, 500, 850, 21.0, 35.0, 24.0, 32.0, 6.0, 8.2, "Black Vertisol; Alluvial; Red Sandy; Clay Loam", 90, 45, 45, "Verified", "Recommendable"),
        ("sugarcane", "Sugarcane", "Ganna; Eekh", "Saccharum officinarum", "Poaceae", "Commercial Sugar", "Annual", "Uttar Pradesh; Maharashtra; Karnataka; Tamil Nadu; Bihar; Gujarat", 75.0, 45.0, 1200, 2000, 20.0, 35.0, 24.0, 32.0, 6.5, 7.8, "Loamy; Clay Loam; Alluvial; Deep Black", 200, 80, 80, "Verified", "Recommendable"),
        ("soybean", "Soybean", "Bhat; Soyabean", "Glycine max", "Fabaceae", "Oilseed / Legume", "Kharif", "Madhya Pradesh; Maharashtra; Rajasthan; Karnataka; Telangana", 2.2, 1.4, 450, 650, 20.0, 32.0, 22.0, 30.0, 6.0, 7.5, "Black Vertisol; Loamy; Clay Loam", 25, 60, 40, "Verified", "Recommendable"),
        ("groundnut", "Groundnut (Peanut)", "Mungfali; Peanut", "Arachis hypogaea", "Fabaceae", "Oilseed / Legume", "Kharif; Zaid", "Gujarat; Rajasthan; Tamil Nadu; Andhra Pradesh; Karnataka", 2.2, 1.2, 400, 600, 22.0, 32.0, 25.0, 30.0, 5.8, 7.2, "Sandy Loam; Red Sandy; Loamy; Alluvial", 20, 50, 40, "Verified", "Recommendable"),
        ("potato", "Potato", "Aloo; Batata", "Solanum tuberosum", "Solanaceae", "Tuber Vegetable", "Rabi", "Uttar Pradesh; West Bengal; Bihar; Gujarat; Punjab; Assam", 25.0, 12.0, 350, 550, 15.0, 24.0, 16.0, 20.0, 5.0, 6.8, "Sandy Loam; Loamy; Alluvial", 150, 80, 120, "Verified", "Recommendable"),
        ("chickpea", "Chickpea (Gram)", "Chana; Bengal Gram; Kabuli Chana", "Cicer arietinum", "Fabaceae", "Pulse", "Rabi", "Madhya Pradesh; Rajasthan; Maharashtra; Uttar Pradesh; Karnataka", 1.8, 1.0, 250, 400, 15.0, 28.0, 18.0, 24.0, 6.0, 7.8, "Loamy; Clay Loam; Black Vertisol; Sandy Loam", 25, 50, 25, "Verified", "Recommendable"),
        ("lentil", "Lentil (Masoor)", "Masoor; Red Lentil", "Lens culinaris", "Fabaceae", "Pulse", "Rabi", "Madhya Pradesh; Uttar Pradesh; Bihar; West Bengal; Rajasthan", 1.4, 0.8, 200, 350, 12.0, 25.0, 15.0, 22.0, 6.0, 7.8, "Loamy; Alluvial; Clay Loam", 20, 40, 20, "Verified", "Recommendable"),
        ("mustard", "Mustard (Rapeseed)", "Sarson; Rai; Toria", "Brassica juncea", "Brassicaceae", "Oilseed", "Rabi", "Rajasthan; Haryana; Madhya Pradesh; Uttar Pradesh; West Bengal", 1.8, 1.0, 250, 400, 10.0, 25.0, 15.0, 22.0, 6.0, 7.8, "Loamy; Sandy Loam; Alluvial", 80, 40, 30, "Verified", "Recommendable"),
        ("tomato", "Tomato", "Tamatar", "Solanum lycopersicum", "Solanaceae", "Vegetable", "Rabi; Zaid; Kharif", "Andhra Pradesh; Madhya Pradesh; Karnataka; Gujarat; Odisha; Maharashtra", 35.0, 15.0, 400, 600, 18.0, 30.0, 20.0, 26.0, 6.0, 7.2, "Sandy Loam; Loamy; Red Sandy; Alluvial; Clay Loam", 120, 80, 80, "Verified", "Recommendable"),
        ("onion", "Onion", "Pyaz; Kanda", "Allium cepa", "Amaryllidaceae", "Bulb Vegetable", "Rabi; Kharif", "Maharashtra; Madhya Pradesh; Karnataka; Gujarat; Rajasthan; Bihar", 22.0, 10.0, 350, 550, 15.0, 30.0, 18.0, 26.0, 6.0, 7.5, "Sandy Loam; Loamy; Alluvial; Clay Loam", 100, 50, 80, "Verified", "Recommendable"),
        ("banana", "Banana", "Kela; Vazhai", "Musa acuminata", "Musaceae", "Fruit / Perennial", "Annual", "Andhra Pradesh; Gujarat; Maharashtra; Tamil Nadu; Kerala; Karnataka", 45.0, 20.0, 1400, 2200, 22.0, 35.0, 25.0, 30.0, 6.0, 7.5, "Clay Loam; Alluvial; Deep Loam", 200, 60, 250, "Verified", "Recommendable"),
        ("mango", "Mango", "Aam", "Mangifera indica", "Anacardiaceae", "Orchard Fruit", "Annual", "Uttar Pradesh; Andhra Pradesh; Karnataka; Bihar; Gujarat; Maharashtra", 12.0, 6.0, 750, 1500, 24.0, 36.0, 26.0, 32.0, 5.5, 7.5, "Alluvial; Deep Red Sandy; Deep Loam", 100, 50, 100, "Partially Supported", "Recommendable"),
        ("jowar", "Jowar (Sorghum)", "Sorghum; Great Millet", "Sorghum bicolor", "Poaceae", "Millet / Cereal", "Kharif; Rabi", "Maharashtra; Karnataka; Rajasthan; Tamil Nadu; Madhya Pradesh", 2.8, 1.4, 350, 550, 20.0, 34.0, 26.0, 30.0, 6.0, 8.0, "Black Vertisol; Clay Loam; Loamy; Alluvial", 70, 35, 35, "Verified", "Recommendable"),
        ("sunflower", "Sunflower", "Surajmukhi", "Helianthus annuus", "Asteraceae", "Oilseed", "Kharif; Rabi; Zaid", "Karnataka; Odisha; Maharashtra; Bihar; Haryana; Andhra Pradesh", 2.0, 1.1, 350, 550, 18.0, 32.0, 22.0, 28.0, 6.5, 7.8, "Loamy; Black Vertisol; Sandy Loam; Alluvial", 60, 50, 35, "Verified", "Recommendable"),
        ("barley", "Barley", "Jau", "Hordeum vulgare", "Poaceae", "Cereal", "Rabi", "Rajasthan; Uttar Pradesh; Madhya Pradesh; Haryana; Punjab", 3.5, 1.6, 200, 350, 12.0, 25.0, 15.0, 22.0, 6.0, 8.5, "Sandy Loam; Loamy; Alluvial; Light Clay Loam", 55, 30, 20, "Verified", "Recommendable"),
        ("millets", "Bajra / Pearl Millet", "Bajra; Pearl Millet; Sajjalu", "Pennisetum glaucum", "Poaceae", "Nutri-Cereal", "Kharif; Zaid", "Rajasthan; Uttar Pradesh; Gujarat; Haryana; Maharashtra", 2.2, 1.2, 250, 450, 22.0, 38.0, 28.0, 35.0, 5.8, 8.0, "Sandy; Sandy Loam; Red Sandy; Loamy", 70, 35, 25, "Verified", "Recommendable"),
    ]

    out_path = REPORTS_DIR / "phase_3c_4_canonical_crop_catalogue.csv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(fieldnames)
        writer.writerows(crops)

    print(f"Generated {len(crops)} canonical crops in {out_path.name}")
    return crops


# ==============================================================================
# 3. SOURCE EVIDENCE GAPS
# ==============================================================================
def build_source_evidence_gaps():
    fieldnames = [
        "gap_id",
        "crop_id",
        "parameter_or_dimension",
        "current_status",
        "evidence_classification",
        "source_citation",
        "documented_discrepancy_or_gap",
        "risk_severity",
        "proposed_resolution_in_3c_4",
        "blocking_status_for_implementation"
    ]

    gaps = [
        ("GAP-01", "all_crops", "rainfall_semantics", "Defective Unit & Scale", "D", "SRC-FAO56-20", "FieldWise compressed 350-2500 mm crop water requirement into 30-300 mm monthly brackets.", "Critical", "De-couple monthly rainfall from seasonal water requirement. Parameterize Total Effective Water (Weff = R_seasonal + I_capacity).", "Resolved in Spec (Ready for Code)"),
        ("GAP-02", "all_crops", "cultivation_season", "Omitted from Scoring Logic", "D", "SRC-ICAR-01", "Season metadata exists in database but predictCrops() never accepts or evaluates season.", "Critical", "Mandate sowing_month / cultivation_season in canonical input contract. Enforce Tier 1 Boolean gate.", "Resolved in Spec (Ready for Code)"),
        ("GAP-03", "all_crops", "npk_measurement_basis", "Conflation of RDF and Soil Test", "D", "SRC-SHC-19", "Input prompts for soil nutrients but ranges check against fertilizer application doses (RDF).", "High", "Map soil test inputs to Soil Health Card rating limits (Low/Medium/High). Decouple soil test from RDF.", "Resolved in Spec (Ready for Code)"),
        ("GAP-04", "all_crops", "soil_ph_toxicity", "Bonus Scoring Only", "D", "SRC-ICAR-01", "pH only adds 0-10 bonus points; zero penalty for lethal alkaline (pH 9.5) or acid (pH 3.5) extremes.", "High", "Implement absolute tolerance window in Tier 1. Exclude crops outside [pH_min - 0.5, pH_max + 0.5].", "Resolved in Spec (Ready for Code)"),
        ("GAP-05", "catalog", "split_brain_asymmetry", "Disjoint Crop Lists (16 vs 16)", "C", "Phase 3C.3 Consistency Audit", "Backend has banana, mango, jowar; Frontend has sunflower, barley, millets.", "High", "Consolidate into single canonical 19-crop JSON configuration shared identically by backend and frontend.", "Resolved in Spec (Ready for Code)"),
        ("GAP-06", "sugarcane", "cultivation_season", "Conflicting Season Tag", "C", "SRC-IISR-06", "Backend labels Sugarcane as 'Kharif'; Frontend labels 'Annual'. True duration is 10-18 months.", "High", "Harmonize canonical season to 'Annual' with multi-season planting windows (Spring/Autumn).", "Resolved in Spec (Ready for Code)"),
        ("GAP-07", "tomato", "base_yield_divergence", "Discrepant Yield Baseline", "C", "Phase 3C.3 Consistency Audit", "Backend base yield is 20 t/ha; Frontend base yield is 35 t/ha (+75% delta).", "High", "Standardize canonical base yield to 35 t/ha for commercial hybrid irrigated tomato; 15 t/ha for rainfed.", "Resolved in Spec (Ready for Code)"),
        ("GAP-08", "mustard_tomato_onion", "fertilizer_prescriptions", "Discrepant Recipes & Splits", "C", "SRC-IIHR-12, SRC-DRMR-11", "Dosages, nutrient carriers, and foliar sprays differ between fertilizerDatabase.js and predictorEngine.ts.", "Medium", "Harmonize commercial fertilizer prescriptions according to ICAR package of practices.", "Resolved in Spec (Ready for Code)"),
        ("GAP-09", "all_crops", "district_level_varietal_data", "Missing Micro-climate Data", "B", "ICAR AICRP Bulletins", "Current data is national/state general; lacks local varietal maturity classes (early vs late).", "Medium", "Accept district input; apply state-level defaults with explicit uncertainty warning.", "Blocked Pending Future Research"),
        ("GAP-10", "mango", "orchard_nutrient_unit_basis", "Tree vs Field Unit Ambiguity", "B", "SRC-CISH-14", "Orchard nutrient requirements are specified per mature tree (g/tree), not per hectare.", "Low", "Document tree-to-hectare planting density conversion factors (100 trees/ha at 10m x 10m).", "Resolved in Spec (Ready for Code)"),
    ]

    out_path = REPORTS_DIR / "phase_3c_4_source_evidence_gaps.csv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(fieldnames)
        writer.writerows(gaps)

    print(f"Generated {len(gaps)} source evidence gaps in {out_path.name}")
    return gaps


# ==============================================================================
# 4. ACCEPTANCE TEST MATRIX
# ==============================================================================
def build_acceptance_test_matrix():
    fieldnames = [
        "test_id",
        "test_name",
        "test_category",
        "input_payload_json",
        "expected_tier1_eligibility_status",
        "expected_excluded_crops",
        "expected_eligible_crops",
        "expected_top_recommendation",
        "expected_warnings",
        "allow_recommendation_boolean",
        "uncertainty_flag",
        "pass_criteria"
    ]

    tests = [
        (
            "TEST-01-S1",
            "Arid Desert Drought (Jaisalmer)",
            "Regression (Phase 3C.3 Scenario S1)",
            json.dumps({"state": "Rajasthan", "sowing_month": 7, "cultivation_season": "Kharif", "irrigation_capacity": "Rainfed_Zero_Irrigation", "rainfall_amount": 40.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 38.0, "relative_humidity": 25.0, "soil_texture": "Sandy", "soil_ph": 8.2, "has_soil_test": False}),
            "PARTIAL_PASS",
            "['rice', 'wheat', 'cotton', 'sugarcane', 'soybean', 'groundnut', 'potato', 'chickpea', 'lentil', 'mustard', 'tomato', 'onion', 'banana', 'mango']",
            "['millets']",
            "millets",
            "['Extreme arid conditions; only drought-hardy millets eligible under rainfed conditions']",
            "True",
            "HIGH_DROUGHT_RISK",
            "Assert Chickpea, Lentil, Wheat, Rice, Sugarcane, Banana, Tomato EXCLUDED in Tier 1; Millets eligible."
        ),
        (
            "TEST-02-S2",
            "Monsoon High Rainfall Wetland (Assam)",
            "Regression (Phase 3C.3 Scenario S2)",
            json.dumps({"state": "Assam", "sowing_month": 6, "cultivation_season": "Kharif", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 1200.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 29.0, "relative_humidity": 88.0, "soil_texture": "Clay", "soil_ph": 6.0, "has_soil_test": True, "soil_nitrogen": 290.0, "soil_phosphorus": 24.0, "soil_potassium": 180.0, "nutrient_basis": "SHC_Available_kg_ha"}),
            "PARTIAL_PASS",
            "['wheat', 'barley', 'chickpea', 'lentil', 'mustard', 'potato']",
            "['rice', 'banana', 'sugarcane']",
            "rice",
            "[]",
            "True",
            "LOW",
            "Assert Wheat, Mustard, Chickpea, Lentil EXCLUDED (Season & Waterlogging); Rice ranked #1."
        ),
        (
            "TEST-03-S3",
            "Peak Kharif Summer Heat (Punjab July)",
            "Regression (Phase 3C.3 Scenario S3)",
            json.dumps({"state": "Punjab", "sowing_month": 7, "cultivation_season": "Kharif", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 180.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 35.0, "relative_humidity": 75.0, "soil_texture": "Loamy", "soil_ph": 7.0, "has_soil_test": True, "soil_nitrogen": 320.0, "soil_phosphorus": 28.0, "soil_potassium": 210.0, "nutrient_basis": "SHC_Available_kg_ha"}),
            "PARTIAL_PASS",
            "['wheat', 'barley', 'mustard', 'chickpea', 'lentil', 'potato']",
            "['rice', 'maize', 'cotton', 'sugarcane']",
            "rice",
            "[]",
            "True",
            "LOW",
            "Assert Wheat and Onion (Rabi) EXCLUDED in Tier 1; Rice and Maize recommended."
        ),
        (
            "TEST-04-S4",
            "Severe Soil Alkalinity (pH 9.2)",
            "Regression (Phase 3C.3 Scenario S4)",
            json.dumps({"state": "Haryana", "sowing_month": 11, "cultivation_season": "Rabi", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 90.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 20.0, "relative_humidity": 60.0, "soil_texture": "Sandy Loam", "soil_ph": 9.2, "has_soil_test": False}),
            "FAIL_ALL",
            "['rice', 'wheat', 'maize', 'cotton', 'sugarcane', 'soybean', 'groundnut', 'potato', 'chickpea', 'lentil', 'mustard', 'tomato', 'onion', 'banana', 'mango', 'jowar', 'sunflower', 'barley', 'millets']",
            "[]",
            "None",
            "['Soil pH 9.2 is severely alkaline; exceeds biological tolerance of all canonical crops. Gypsum reclamation required.']",
            "False",
            "LETHAL_SOIL_TOXICITY",
            "Assert ALL crops EXCLUDED due to lethal pH > 8.8; Return explicit NO_RECOMMENDATION status."
        ),
        (
            "TEST-05-S5",
            "Soil Health Card Medium Fertility Plain",
            "Regression (Phase 3C.3 Scenario S5)",
            json.dumps({"state": "Uttar Pradesh", "sowing_month": 7, "cultivation_season": "Kharif", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 220.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 28.0, "relative_humidity": 75.0, "soil_texture": "Clay Loam", "soil_ph": 6.8, "has_soil_test": True, "soil_nitrogen": 320.0, "soil_phosphorus": 28.0, "soil_potassium": 210.0, "nutrient_basis": "SHC_Available_kg_ha"}),
            "PARTIAL_PASS",
            "['wheat', 'barley', 'chickpea', 'lentil', 'mustard']",
            "['rice', 'sugarcane', 'maize', 'banana']",
            "rice",
            "[]",
            "True",
            "LOW",
            "Assert N=320 and K=210 score MAXIMUM (100% nutrient credit) under SHC Medium rating."
        ),
        (
            "TEST-06",
            "Missing Season Input with Sowing Month Provided",
            "Temporal Context Validation",
            json.dumps({"state": "Madhya Pradesh", "sowing_month": 11, "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 50.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 19.0, "relative_humidity": 55.0, "soil_texture": "Black Vertisol", "soil_ph": 7.2, "has_soil_test": False}),
            "PARTIAL_PASS",
            "['rice', 'cotton', 'soybean', 'maize']",
            "['wheat', 'chickpea', 'lentil', 'mustard', 'jowar']",
            "wheat",
            "['Cultivation season automatically inferred as Rabi from sowing month November']",
            "True",
            "LOW",
            "Assert season successfully derived as Rabi from month=11; Kharif crops excluded."
        ),
        (
            "TEST-07",
            "Missing Irrigation Capacity Input",
            "Missing Value Policy",
            json.dumps({"state": "Rajasthan", "sowing_month": 7, "cultivation_season": "Kharif", "rainfall_amount": 250.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 32.0, "relative_humidity": 45.0, "soil_texture": "Sandy Loam", "soil_ph": 7.5, "has_soil_test": False}),
            "PARTIAL_PASS",
            "['banana', 'sugarcane', 'rice']",
            "['millets', 'jowar', 'groundnut']",
            "millets",
            "['Irrigation capacity omitted; defaulted conservatively to Rainfed_Zero_Irrigation. High water crops excluded.']",
            "True",
            "HIGH_UNCERTAINTY",
            "Assert defaults to Rainfed_Zero_Irrigation; Sugarcane, Banana, Rice excluded."
        ),
        (
            "TEST-08",
            "Annual Rainfall Entered Where Seasonal Required",
            "Unit Semantic Normalization",
            json.dumps({"state": "West Bengal", "sowing_month": 6, "cultivation_season": "Kharif", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 1400.0, "rainfall_period_type": "Annual_Normal", "temperature_mean": 29.0, "relative_humidity": 80.0, "soil_texture": "Alluvial", "soil_ph": 6.5, "has_soil_test": False}),
            "PARTIAL_PASS",
            "['wheat', 'mustard', 'chickpea']",
            "['rice', 'jowar', 'maize']",
            "rice",
            "['Annual rainfall 1400 mm converted to Kharif seasonal estimate: 1050 mm']",
            "True",
            "MEDIUM",
            "Assert 1400 mm annual rainfall scaled by 0.75 for Kharif = 1050 mm; Rice eligible."
        ),
        (
            "TEST-09",
            "Soil Nutrients Entered with Unknown Units",
            "Unit Safety & Ambiguity Handling",
            json.dumps({"state": "Bihar", "sowing_month": 11, "cultivation_season": "Rabi", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 40.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 18.0, "relative_humidity": 65.0, "soil_texture": "Alluvial", "soil_ph": 7.0, "has_soil_test": True, "soil_nitrogen": 45.0, "soil_phosphorus": 15.0, "soil_potassium": 25.0, "nutrient_basis": "Unknown_Unspecified"}),
            "PARTIAL_PASS",
            "['rice', 'cotton', 'soybean']",
            "['wheat', 'lentil', 'chickpea', 'mustard', 'potato']",
            "wheat",
            "['Nutrient units unspecified; nutrient scoring assigned neutral default (Medium) with uncertainty penalty']",
            "True",
            "NUTRIENT_UNIT_UNCERTAIN",
            "Assert nutrient values not blindly evaluated against RDF or SHC; neutral tier assigned."
        ),
        (
            "TEST-10",
            "Extreme Acidic Soil (pH 3.8)",
            "Toxicity Threshold",
            json.dumps({"state": "Kerala", "sowing_month": 6, "cultivation_season": "Kharif", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 800.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 27.0, "relative_humidity": 90.0, "soil_texture": "Red Sandy", "soil_ph": 3.8, "has_soil_test": False}),
            "FAIL_ALL",
            "['rice', 'wheat', 'maize', 'cotton', 'sugarcane', 'soybean', 'groundnut', 'potato', 'chickpea', 'lentil', 'mustard', 'tomato', 'onion', 'banana', 'mango', 'jowar', 'sunflower', 'barley', 'millets']",
            "[]",
            "None",
            "['Soil pH 3.8 is strongly acidic (acid sulfate soil); below survival limit of all canonical crops. Liming mandatory.']",
            "False",
            "EXTREME_ACID_TOXICITY",
            "Assert ALL crops EXCLUDED due to lethal pH < 4.8; Return NO_RECOMMENDATION."
        ),
        (
            "TEST-11",
            "Unsupported / Unknown District Entered",
            "Location Fallback",
            json.dumps({"state": "Karnataka", "district": "NonExistentDistrictName", "sowing_month": 7, "cultivation_season": "Kharif", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 600.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 26.0, "relative_humidity": 75.0, "soil_texture": "Red Sandy", "soil_ph": 6.5, "has_soil_test": False}),
            "PARTIAL_PASS",
            "['wheat', 'mustard', 'barley']",
            "['maize', 'groundnut', 'cotton', 'jowar', 'sunflower']",
            "maize",
            "['District NonExistentDistrictName not recognized; state-level agro-climatic defaults applied']",
            "True",
            "DISTRICT_FALLBACK_APPLIED",
            "Assert state-level agro-climatic parameters applied safely with user-facing warning."
        ),
        (
            "TEST-12",
            "Backend vs Frontend Engine Parity Verification",
            "Dual-Engine Equivalence",
            json.dumps({"state": "Maharashtra", "sowing_month": 7, "cultivation_season": "Kharif", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 750.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 27.0, "relative_humidity": 80.0, "soil_texture": "Black Vertisol", "soil_ph": 7.5, "has_soil_test": True, "soil_nitrogen": 300.0, "soil_phosphorus": 25.0, "soil_potassium": 220.0, "nutrient_basis": "SHC_Available_kg_ha"}),
            "IDENTICAL",
            "[]",
            "['cotton', 'soybean', 'sugarcane', 'jowar', 'maize']",
            "cotton",
            "[]",
            "True",
            "NONE",
            "Assert exact 100% equivalence in eligible list and ranking between backend and offline fallback."
        ),
        (
            "TEST-13",
            "No Eligible Crop Scenario (Extreme Desert Sand)",
            "System Rejection Boundary",
            json.dumps({"state": "Rajasthan", "sowing_month": 5, "cultivation_season": "Zaid", "irrigation_capacity": "Rainfed_Zero_Irrigation", "rainfall_amount": 5.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 47.0, "relative_humidity": 12.0, "soil_texture": "Sandy", "soil_ph": 8.6, "has_soil_test": False}),
            "FAIL_ALL",
            "['rice', 'wheat', 'maize', 'cotton', 'sugarcane', 'soybean', 'groundnut', 'potato', 'chickpea', 'lentil', 'mustard', 'tomato', 'onion', 'banana', 'mango', 'jowar', 'sunflower', 'barley', 'millets']",
            "[]",
            "None",
            "['No viable crop found for extreme May heat (47°C) and arid rainfed sand (5 mm rain). Commercial cropping not recommended.']",
            "False",
            "ZERO_FEASIBLE_CROPS",
            "Assert 0 crops pass Tier 1; System returns explicit, helpful rejection message."
        ),
        (
            "TEST-14",
            "Out-of-Bounds Physical Input",
            "Input Validation Gate",
            json.dumps({"state": "Punjab", "sowing_month": 11, "cultivation_season": "Rabi", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": -50.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 65.0, "relative_humidity": 115.0, "soil_texture": "Loamy", "soil_ph": 14.5, "has_soil_test": False}),
            "SCHEMA_REJECT",
            "[]",
            "[]",
            "None",
            "['Input validation error: Negative rainfall (-50 mm), unphysical temperature (65°C), relative humidity > 100%, and pH > 14 are invalid.']",
            "False",
            "INVALID_PHYSICAL_INPUTS",
            "Assert schema validator halts execution immediately with HTTP 422 / client validation error."
        ),
        (
            "TEST-15",
            "Conflicting Evidence Reconciliation (Sugarcane & Tomato)",
            "Catalogue Reconciliation",
            json.dumps({"state": "Maharashtra", "sowing_month": 10, "cultivation_season": "Rabi", "irrigation_capacity": "Assured_Irrigation", "rainfall_amount": 100.0, "rainfall_period_type": "Crop_Season_Total", "temperature_mean": 24.0, "relative_humidity": 65.0, "soil_texture": "Black Vertisol", "soil_ph": 7.2, "has_soil_test": False}),
            "PARTIAL_PASS",
            "['rice', 'soybean', 'cotton']",
            "['sugarcane', 'chickpea', 'jowar', 'wheat', 'tomato']",
            "sugarcane",
            "['Sugarcane evaluated under autumn planting window with assured irrigation across 12-month duration']",
            "True",
            "LOW",
            "Assert Sugarcane recognized as Annual with Autumn planting; Tomato evaluated with 35 t/ha base."
        ),
    ]

    out_path = REPORTS_DIR / "phase_3c_4_acceptance_test_matrix.csv"
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(fieldnames)
        writer.writerows(tests)

    print(f"Generated {len(tests)} acceptance tests in {out_path.name}")
    return tests


if __name__ == "__main__":
    build_eligibility_rules()
    build_canonical_catalogue()
    build_source_evidence_gaps()
    build_acceptance_test_matrix()
