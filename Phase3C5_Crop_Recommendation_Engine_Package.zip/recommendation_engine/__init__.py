"""
FieldWise Phase 3C.5: Recommendation Engine Package
===================================================
Production-grade, rule-based crop recommendation engine adhering to the
Phase 3C.4.2.2.1 approved agronomic specification.
"""

from .schemas import (
    LifeCycle,
    BroadSeason,
    PlantingWindowEvidenceStatus,
    IrrigationAccess,
    SoilMoistureEpistemicTier,
    ConfidenceTier,
    Tier1Status,
    WaterGatingStatus,
    ExecutionStatus,
    LocationInput,
    TemporalInput,
    ClimateWaterInput,
    EdaphicInput,
    RecommendationQuery,
    PlantingWindowDefinition,
    CropCatalogueEntry,
    WaterAssessmentResult,
    Tier1GateResult,
    Tier1EvaluationResult,
    Tier2Components,
    FertilizerPrescription,
    CropRecommendation,
    ExcludedCandidate,
    DCIResult,
    QuerySummary,
    RecommendationResult,
)
from .catalogue import CanonicalCropCatalogue
from .engine import CropRecommendationEngine

__version__ = "2.2.0-CLOSURE"
__all__ = [
    "CropRecommendationEngine",
    "CanonicalCropCatalogue",
    "RecommendationQuery",
    "LocationInput",
    "TemporalInput",
    "ClimateWaterInput",
    "EdaphicInput",
    "RecommendationResult",
    "CropRecommendation",
    "ExcludedCandidate",
    "ExecutionStatus",
    "ConfidenceTier",
    "Tier1Status",
    "WaterGatingStatus",
]
